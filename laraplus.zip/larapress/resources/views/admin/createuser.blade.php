@extends('admin.master.master')

@section('title', 'Create User')

@section('headcode')
	{{ Html::style('assets/common/css/pagination.css') }}
	{{ Html::style('assets/common/js/datatables/dataTables.bootstrap.css') }}
	{{ Html::style('assets/common/js/datepicker/datepicker.css') }}
@endsection

@section('breadcambs', '<i class="fa fa-dashboard"></i> Create User')

@section('bodycode')
<div class="box-header">
    <a href="{{ route('userlist') }}" class="btn btn-default btn-flat">Users List</a>
</div>

<div class="row">
	<div class="col-md-2">
		<div class="small-box bg-yellow">
            <div class="inner">
	              <p>User Avatar Gose Here</p>
            </div>
            <div class="icon">
              	<i class="ion ion-person-add"></i>
            </div>
            <a class="small-box-footer" href="#">
              	Change Avatar <i class="fa fa-edit"></i>
            </a>
        </div>
	</div>
	<div class="col-md-10">
		{{ Form::open(array('route'=>'createuserprocess', 'method'=>'post')) }}
		<div class="box">
			<div class="box-header with-border">
				<div class="row">
					<div class="col-md-12">
						<h3 class="box-title">Creat User</h3>
					</div>
				</div>
            </div><!-- /.box-header -->
            <div class="box-body">
            	<div class="row">
            		<div class="col-md-6">
            			<table class="table table-striped">
							<caption>
								User Login Details
							</caption>
							<tr>
								<td class="col-xs-3 col-sm-6">First Name</td>
								<td>
									<input type="text" name="fname" placeholder="Enter First Name" class="form-control input-sm" value="<?php if(old('fname')!=''){echo old('fname');}?>">
								</td>
							</tr>
							<tr>
								<td>Last Name</td>
								<td>
									<input type="text" name="lname" placeholder="Enter Last Name" class="form-control input-sm" value="<?php if(old('lname')!=''){echo old('lname');}?>">
								</td>
							</tr>
							<tr>
								<td>Username</td>
								<td>
									<input type="text" name="username" placeholder="Enter Username" class="form-control input-sm" value="<?php if(old('username')!=''){echo old('username');}elseif(isset($autousername) && $autousername!=''){echo $autousername;} ?>">
								</td>
							</tr>
							<tr>
								<td>Email</td>
								<td>
									<input type="text" name="email" placeholder="Enter Email" class="form-control input-sm" value="<?php if(old('email')!=''){echo old('email');}?>">
								</td>
							</tr>
							<tr>
								<td>Password</td>
								<td>
									<input type="text" name="password" placeholder="Choose Password" class="form-control input-sm" value="<?php if(old('password')!=''){echo old('password');}elseif(isset($autopassword) && $autopassword!=''){echo $autopassword;} ?>">
								</td>
							</tr>
							<tr>
								<td>Role</td>
								<td>
									<select class="form-control" style="width: 100%;" name="role">
                                        <?php
                                            $a =role($lang='en');
                                        ?>
                                        @foreach($a as $key => $val)
                                        	@if($logged_role > $key && $key!=0 && $key!= -1)
                                            <option value="{{$key}}" <?php if(old('role')!= '' && old('role')==$key){
                                            	echo ' selected';
                                            	}?>>{{$val}}</option>
                                            @endif
                                        @endforeach
                                    </select>
								</td>
							</tr>
							<tr>
								<td>Email Verification</td>
								<td>
									<select class="form-control" style="width: 100%;" name="verified">
                                        <?php
                                            $a = isemailverified(null,'en');
                                        ?>
                                        @foreach($a as $key => $val)
                                            <option value="{{$key}}" <?php if(old('verified')!= '' && old('verified')==$key){
                                            	echo ' selected';
                                            	}?>>{{$val}}</optiosn>
                                        @endforeach
                                    </select>
								</td>
							</tr>
						</table>
            		</div>
            		<div class="col-md-6">
            			<table class="table table-striped">
							<caption>
								User Personal Details
							</caption>
							<tr>
								<td class="col-xs-5 col-sm-6">Addres Line 1</td>
								<td>
									<input type="text" name="street1" placeholder="Enter Address Line 1" class="form-control input-sm" value="<?php if(old('street1')!=''){echo old('street1');} ?>">
								</td>
							</tr>
							<tr>
								<td>Addres Line 2</td>
								<td>
									<input type="text" name="street2" placeholder="Enter Address Line 2" class="form-control input-sm" value="<?php if(old('street2')!=''){echo old('street2');} ?>">
								</td>
							</tr>
							<tr>
								<td>City</td>
								<td>
									<input type="text" name="city" placeholder="Enter City" class="form-control input-sm" value="<?php if(old('city')!=''){echo old('city');} ?>">
								</td>
							</tr>
							<tr>
								<td>State</td>
								<td>
									<input type="text" name="state" placeholder="Enter State" class="form-control input-sm" value="<?php if(old('state')!=''){echo old('state');} ?>">
								</td>
							</tr>
							<tr>
								<td>Zip</td>
								<td>
									<input type="text" name="zip" placeholder="Enter Zip" class="form-control input-sm" value="<?php if(old('zip')!=''){echo old('zip');} ?>">
								</td>
							</tr>
							<tr>
								<td>Country</td>
								<td>
									<select class="form-control" style="width: 100%;" name="country">
                                        <?php
                                            $a = country(null,'en');
                                        ?>
                                        @foreach($a as $key => $val)
                                            <option value="{{$key}}" <?php if(old('country')!= '' && old('country')==$key){
                                            	echo ' selected';
                                            	}?>>{{$val}}</option>
                                        @endforeach
                                    </select>
								</td>
							</tr>
							<tr>
								<td>Sex</td>
								<td>
									<select class="form-control" name="sex">
                                        <?php
                                            $a = gender(null,'en');
                                        ?>
                                        @foreach($a as $key => $val)
                                            <option value="{{$key}}" <?php if(old('sex')!= '' && old('sex')==$key){
                                            	echo ' selected';
                                            	}?>>{{$val}}</option>
                                        @endforeach
                                    </select>
								</td>
							</tr>
							<tr>
								<td>Contact No.</td>
								<td>
									<input type="tel" name="contact" placeholder="Enter Contact No" class="form-control input-sm" value="<?php if(old('contact')!=''){echo old('contact');} ?>">
								</td>
							</tr>
							<tr>
								<td>Description</td>
								<td>
									<textarea name="description" rows="3" class="form-control" placeholder="Enter Description"><?php if(old('description')!=''){echo old('description');} ?></textarea>
								</td>
							</tr>
							<tr>
								<td>Date Of Birth</td>
								<td>
									<input type="tel" name="dob" placeholder="Enter Date of Birth" class="form-control input-sm datepicker" value="<?php if(old('dob')!=''){echo old('dob');} ?>">
								</td>
							</tr>
						</table>
            		</div>
            	</div>
				
            </div><!-- /.box-body -->
			<div class="box-footer clearfix">
				<input type="submit" class="btn btn-primary btn-flat pull-right" value="Create Account">
			</div>
        </div><!-- /.box -->
        {{ Form::close() }}
	</div>
</div>
@endsection

@section('jscode')
	{{ Html::script('assets/common/js/datepicker/datepicker.js') }}
	<script type="text/javascript">
		//Init jquery Date Picker
        $('.datepicker').datepicker({
             format: 'yyyy-mm-dd',
             autoclose: true,
             orientation: 'bottom'
         });
	</script>
@endsection