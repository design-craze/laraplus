@extends('admin.master.master')

@section('title', 'Edit User')

@section('headcode')
	{{ Html::style('assets/common/css/pagination.css') }}
	{{ Html::style('assets/common/js/datatables/dataTables.bootstrap.css') }}
	{{ Html::style('assets/common/js/datepicker/datepicker.css') }}
@endsection

@section('breadcambs', '<i class="fa fa-dashboard"></i> Edit User')

@section('bodycode')
<div class="box-header">
    <a href="{{ route('createuser') }}" class="btn btn-default btn-flat">Create a New User</a>
    <a href="{{ route('userlist') }}" class="btn btn-default btn-flat">Users List</a>
</div>

<div class="row">
	@if($dataerror==0)
		@if($logged_role > $user->role || $logged_id == $user->id)
		<div class="col-md-2">
			<div class="small-box bg-yellow">
	        	<div class="inner text-center">
	        	@if(isset($userinfo) && !empty($userinfo->avatar) && !is_int($userinfo->avatar))
				<img src="{{ asset(path_profile().$userinfo->avatar) }}" alt="{{$userinfo->avatar}}" class="img-responsive img-circle">
				@elseif($userinfo->sex == 'f')
				<img src="{{ asset(path_profile().'female.jpg') }}" alt="female.jpg" class="img-responsive img-circle">
				@else
				<img src="{{ asset(path_profile().'male.jpg') }}" alt="male.jpg" class="img-responsive img-circle">
				@endif
				</div>
	            <!-- Button trigger modal -->
	            @if(isset($user) && $user->id == Auth::user()->id)
	            <div class="small-box-footer">
	            	<ul class="list-unstyled list-inline">
	            		<li>
	            			<a href="#" class="text-info" data-toggle="modal" data-target="#myModal">Change Avatar <i class="fa fa-edit"></i></a>
	            		</li>
	            		@if(!empty($userinfo->avatar) && $user->id == Auth::user()->id)
	            		<li>
	            			<a href="{{ route('removprofileimage',['imgval'=>$userinfo->avatar]) }}" class="text-danger confirmation" data-alert="Do You Want To Remove This Avatar?" data-toggle="tooltip" title="Remove This Avatar">remove</a>
	            		</li>
	            		@endif
	            	</ul>
	            </div>
				@endif
	        </div>
		</div>
		<div class="col-md-10">
			{{ Form::open(array('route'=>['edituserprocess','id'=>$user->id], 'method'=>'post')) }}
			<div class="box">
				<div class="box-header with-border">
					<div class="row">
						<div class="col-md-12">
							<h3 class="box-title">Edit User Information</h3>
						</div>
					</div>
	            </div><!-- /.box-header -->
	            <div class="box-body">
	            	<div class="row">
	            		<div class="col-md-6">
	            			<table class="table table-striped">
								<caption>
									User Login Details
								</caption>
								<tr>
									<td class="col-xs-3 col-sm-6">User ID</td>
									<td> : <em>{{$user->id}}</em></td>
								</tr>
								<tr>
									<td>First Name</td>
									<td>
										<input type="text" name="fname" placeholder="Enter First Name" class="form-control input-sm" value="<?php if(old('fname')!=''){echo old('fname');} else{ echo $user->fname;} ?>">
									</td>
								</tr>
								<tr>
									<td>Last Name</td>
									<td>
										<input type="text" name="lname" placeholder="Enter Last Name" class="form-control input-sm" value="<?php if(old('lname')!=''){echo old('lname');} else{ echo $user->lname;} ?>">
									</td>
								</tr>
								<tr>
									<td>Username</td>
									<td> : <em>{{$user->username}}</em></td>
								</tr>
								<tr>
									<td>Email</td>
									<td> : <a href="mailto:{{$user->email}}"><em>{{$user->email}}</em></a></td>
								</tr>
								<tr>
									<td>Role</td>
									<td>
										@if($logged_id != $user->id)
										<select class="form-control" style="width: 100%;" name="role">
                                            <?php
                                                $a =role($lang='en');
                                            ?>
                                            @foreach($a as $key => $val)
                                            	@if($logged_role > $key && $key!=0 && $key!= -1)
                                                <option value="{{$key}}" <?php if(old('role')!= '' && old('role')==$key){
                                                	echo ' selected';
                                                	}elseif(old('role')== '' && $user->role == $key){ echo ' selected';}?>>{{$val}}</option>
                                                @endif
                                            @endforeach
                                        </select>
                                        @else
                                        : <em>{{roleaccess($user->role)}}</em>
                                        @endif
									</td>
								</tr>
								<tr>
									<td>Email Verification</td>
									<td>
										@if($logged_role > $user->role)
										<select class="form-control" style="width: 100%;" name="verified">
                                            <?php
                                                $a = isemailverified(null,'en');
                                            ?>
                                            @foreach($a as $key => $val)
                                                <option value="{{$key}}" <?php if(old('verified')!= '' && old('verified')==$key){
                                                	echo ' selected';
                                                	}elseif(old('verified')== '' && $user->verified == $key){ echo ' selected';}?>>{{$val}}</option>
                                            @endforeach
                                        </select>
                                        @else
                                        : <em>{{isemailverified($user->verified)}}</em>
                                        @endif
									</td>
								</tr>
								<tr>
									<td>Status</td>
									<td>
									 	<?php
                                            $a = activelevel(null,'en');
											$maxlevel = role($lang='en');
                                            $maxval = (count($maxlevel)-1) - $logged_role;
                                        ?>
										@if($logged_role > $user->role && $user->active >= $maxval)
										<select class="form-control" style="width: 100%;" name="active">
                                           
                                            @foreach($a as $key => $val)
												@if($key>=$maxval)
													<option value="{{$key}}" <?php if(old('active')!= '' && old('active')==$key){
                                                	echo ' selected';
                                                	}elseif(old('active')== '' && $user->active == $key){ echo ' selected';}?>>{{$val}}</option>
												@endif
                                            @endforeach
                                        </select>
                                        @else
                                        : 
											@if($user->active==1)
						                    	<span class="label label-danger">{{activelevel($user->active)}}</span>	
						                    @elseif($user->active==2)
						                    	<span class="label label-warning">{{activelevel($user->active)}}</span>	
						                    @elseif($user->active==3)
						                    	<span class="label label-info">{{activelevel($user->active)}}</span>
						                    @elseif($user->active==4)
						                    	<span class="label label-success">{{activelevel($user->active)}}</span>
						                    @endif
                                        @endif
									</td>
								</tr>
							</table>
	            		</div>
	            		<div class="col-md-6">
	            			<table class="table table-striped">
								<caption>
									User Personal Details
								</caption>
								<tr>
									<td class="col-xs-5 col-sm-6">Addres Line 1</td>
									<td>
										<input type="text" name="street1" placeholder="Enter Address Line 1" class="form-control input-sm" value="<?php if(old('street1')!=''){echo old('street1');} elseif(old('street1')=='' && isset($userinfo)){ echo $userinfo->street1;} ?>">
									</td>
								</tr>
								<tr>
									<td>Addres Line 2</td>
									<td>
										<input type="text" name="street2" placeholder="Enter Address Line 2" class="form-control input-sm" value="<?php if(old('street2')!=''){echo old('street2');} elseif(old('street2')=='' && isset($userinfo)){ echo $userinfo->street2;} ?>">
									</td>
								</tr>
								<tr>
									<td>City</td>
									<td>
										<input type="text" name="city" placeholder="Enter City" class="form-control input-sm" value="<?php if(old('city')!=''){echo old('city');} elseif(old('city')=='' && isset($userinfo)){ echo $userinfo->city;} ?>">
									</td>
								</tr>
								<tr>
									<td>State</td>
									<td>
										<input type="text" name="state" placeholder="Enter State" class="form-control input-sm" value="<?php if(old('state')!=''){echo old('state');} elseif(old('state')=='' && isset($userinfo)){ echo $userinfo->state;} ?>">
									</td>
								</tr>
								<tr>
									<td>Zip</td>
									<td>
										<input type="text" name="zip" placeholder="Enter Zip" class="form-control input-sm" value="<?php if(old('zip')!=''){echo old('zip');} elseif(old('zip')=='' && isset($userinfo)){ echo $userinfo->zip;} ?>">
									</td>
								</tr>
								<tr>
									<td>Country</td>
									<td>
										<select class="form-control" style="width: 100%;" name="country">
                                            <?php
                                                $a = country(null,'en');
                                            ?>
                                            @foreach($a as $key => $val)
                                                <option value="{{$key}}" <?php if(old('country')!= '' && old('country')==$key){
                                                	echo ' selected';
                                                	}elseif(old('country')== '' && isset($userinfo) && $userinfo->country == $key){ echo ' selected';}?>>{{$val}}</option>
                                            @endforeach
                                        </select>
									</td>
								</tr>
								<tr>
									<td>Sex</td>
									<td>
										<select class="form-control" name="sex">
                                            <?php
                                                $a = gender(null,'en');
                                            ?>
                                            @foreach($a as $key => $val)
                                                <option value="{{$key}}" <?php if(old('sex')!= '' && old('sex')==$key){
                                                	echo ' selected';
                                                	}elseif(old('sex')== '' && isset($userinfo) && $userinfo->sex == $key){ echo ' selected';}?>>{{$val}}</option>
                                            @endforeach
                                        </select>
									</td>
								</tr>
								<tr>
									<td>Contact No.</td>
									<td>
										<input type="tel" name="contact" placeholder="Enter Contact No" class="form-control input-sm" value="<?php if(old('contact')!=''){echo old('contact');} elseif(old('contact')=='' && isset($userinfo)){ echo $userinfo->contact;} ?>">
									</td>
								</tr>
								<tr>
									<td>Description</td>
									<td>
										<textarea name="description" rows="3" class="form-control" placeholder="Enter Description"><?php if(old('description')!=''){echo old('description');} elseif(old('description')=='' && isset($userinfo)){ echo $userinfo->description;} ?></textarea>
									</td>
								</tr>
								<tr>
									<td>Date Of Birth</td>
									<td>
										<input type="tel" name="dob" placeholder="Enter Date of Birth" class="form-control input-sm datepicker" value="<?php if(old('dob')!=''){echo old('dob');} elseif(old('dob')=='' && isset($userinfo)){ echo $userinfo->dob;} ?>">
									</td>
								</tr>
							</table>
	            		</div>
	            	</div>
					
	            </div><!-- /.box-body -->
				<div class="box-footer clearfix">
					<input type="submit" class="btn btn-primary btn-flat pull-right" value="Save Changes">
				</div>
	        </div><!-- /.box -->
	        {{ Form::close() }}
		</div>
		@else
		<div class="col-md-12">
			<div class="box">
				<div class="box-body">
					<h4 class="text-center">
						You are not eligable to edit this user.
					</h4>
				</div>
			</div>
		</div>
		@endif
	@else
	<div class="col-md-12">
		<div class="box">
			<div class="box-body">
				<h4 class="text-center">
					No user found to Edit.
				</h4>
			</div>
		</div>
	</div>
	@endif
</div>

<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
    {{ Form::open(array('route'=>'uloadprofileimage', 'method'=>'post', 'files' => true)) }}
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Change Photo</h4>
      </div>
      <div class="modal-body">
        <div class="form-group">
		    <label for="profileimg">Upload Profile Image</label>
		    <input type="file" name="profileimg" id="profileimg">
		    <p class="help-block">Current profile image will be deleted automatically.</p>
		 </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" name="imageupload" value="Upload">
      </div>
      {{ Form::close() }}
    </div>
  </div>
</div>
@endsection

@section('jscode')
	{{ Html::script('assets/common/js/datepicker/datepicker.js') }}
	<script type="text/javascript">
		//Init jquery Date Picker
        $('.datepicker').datepicker({
             format: 'yyyy-mm-dd',
             autoclose: true,
             orientation: 'bottom'
         });
	</script>
@endsection