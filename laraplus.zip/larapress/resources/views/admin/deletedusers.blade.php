@extends('admin.master.master')

@section('title', 'Deleted Users')

@section('headcode')
	{{ Html::style('assets/common/css/pagination.css') }}
	{{ Html::style('assets/common/js/datatables/dataTables.bootstrap.css') }}
@endsection

@section('breadcambs', '<i class="fa fa-dashboard"></i> Deleted Users')

@section('bodycode')
<div class="box admin-table">
    <div class="box-header">
        <a href="#" class="btn btn-default btn-flat">Create a User</a>
        <a href="#" class="btn btn-default btn-flat">Users List</a>
    </div>
    <div class="box-body">
  		<table id="pagetable" class="table table-bordered table-striped">
            <thead>
          		<tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Status</th>
                    <th>Manage</th>
              	</tr>
            </thead>
            <tbody>
            	@if($users)
					@foreach($users as $page)
	              	<tr>
	                    <td>{{$page->id}}</td>
	                    <td>{{$page->fname}} {{$page->lname}}</td>
	                    <td>{{$page->username}}</td>
	                    <td>{{$page->email}}</td>
	                    <td>{{roleaccess($page->role)}}</td>
	                    <td>
	                    @if($page->active==1)
	                    	<strong style="color:#f00">{{activelevel($page->active)}}</strong>	
	                    @elseif($page->active==2)
	                    	<strong style="color:#ff8800">{{activelevel($page->active)}}</strong>	
	                    @elseif($page->active==3)
	                    	<strong class="text-info">{{activelevel($page->active)}}</strong>
	                    @elseif($page->active==4)
	                    	<strong class="text-green">{{activelevel($page->active)}}</strong>
	                    @endif
	                    </td>
	                    <td>
	                    	<ul class="menu-manager">
	                    		<li><a href="#" data-toggle="tooltip" title="View User Info"><i class="fa fa-pencil-square-o"></i></a></li>
	                    		<li><a href="#" data-toggle="tooltip" title="Edit User Info"><i class="fa fa-pencil-square-o"></i></a></li>
	                    		<li><a href="#" class="confirmation" data-alert="Do You Want To Delete This User?" data-toggle="tooltip" title="Delete This User Account"><i class="fa fa-th"></i></a></li>
	                    	</ul>
	                    </td>
	              	</tr>
					@endforeach
				@endif
            </tbody>
            <tfoot>
              	<tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Status</th>
                    <th>Manage</th>
              	</tr>
            </tfoot>
  		</table>
    </div><!-- /.box-body -->
</div><!-- /.box -->
	<div class="common-pagination">
		<?php 
			$pagifpname = 'First'; $pagippname = 'prev'; $pagilpname = 'Last'; $paginpname = 'Next';
			if($users->currentPage() == '1'){
				$pagifp = '<span>'.$pagifpname.'</span>'; $pagipp = '<span>'.$pagippname.'</span>';
			}
			else{
				$pagifp = '<a href="'.route('userlist').'?';
				// foreach($getelements as $key => $val){
	   //          	$pagifp .= $key.'='.$val.'&';
		  //       }
				$pagifp .= 'page=1'.'">'.$pagifpname.'</a>'; $pagipp = '<a href="'.$users->previousPageUrl().'">'.$pagippname.'</a>';
			}
			if($users->lastPage() == $users->currentPage()){
				$pagilp = '<span>'.$pagilpname.'</span>'; $paginp = '<span>'.$paginpname.'</span>';
			}
			else{
				$pagilp = '<a href="'.route('userlist').'?';
				// foreach($getelements as $key => $val){
	   //          	$pagilp .= $key.'='.$val.'&';
		  //       }
				$pagilp .= 'page='.$users->lastPage().'">'.$pagilpname.'</a>'; $paginp = '<a href="'.$users->nextPageUrl().'">'.$paginpname.'</a>';
			}
		?>
		@if($users->total()>$users->count())
			<ul class="prevsec">
				<li>{!!$pagifp!!}</li>
				<li>{!!$pagipp!!}</li>
			</ul>
			{{$users->links()}}
			<ul class="nextsec">
				<li>{!!$paginp!!}</li>
				<li>{!!$pagilp!!}</li>
			</ul>
			<div style="clear:both"></div>
		@endif
	</div>
</div>
@endsection

@section('jscode')
	{{ Html::script('assets/common/js/datatables/jquery.dataTables.min.js') }}
	{{ Html::script('assets/common/js/datatables/dataTables.bootstrap.min.js') }}
	<script>
	    $(function () {
	      	$("#pagetable").DataTable({
	      		"paging": false,
	      		"info": false,
	      	});
	    });
		$(function () {
		  	$('[data-toggle="tooltip"]').tooltip()
		})
    </script>
@endsection