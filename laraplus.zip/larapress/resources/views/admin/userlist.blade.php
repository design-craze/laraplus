@extends('admin.master.master')

@section('title', 'User Manager')

@section('headcode')
	{{ Html::style('assets/common/css/pagination.css') }}
	{{ Html::style('assets/common/js/datatables/dataTables.bootstrap.css') }}
@endsection

@section('breadcambs', '<i class="fa fa-dashboard"></i> User Manager')

@section('bodycode')
<div class="box admin-table">
    <div class="box-header">
        <a href="{{ route('createuser') }}" class="btn btn-default btn-flat">Create a New User</a>
    </div>
    <div class="col-md-8">
            {{ Form::open(array('route'=>'userlist', 'method'=>'get','class'=>'form-inline')) }}
                Sort By :
                <div class="form-group">
                    <select class="form-control input-sm" name="r">
                            <option value="">All</option>
                            @foreach(role() as $key => $val )
                            @if($key!='0' && $key!='-1')
                            <option value="{{$key}}" <?php if(isset($_GET['r']) && $_GET['r']==$key){echo ' selected';} ?>>{{$val}}</option>
                            @endif
                            @endforeach
                    </select>
                </div>
                <div class="form-group">
                    <select class="form-control input-sm" name="v">
                            <option value="">All</option>
                            @foreach(isemailverified() as $key => $val )
                            <option value="{{$key}}" <?php if(isset($_GET['v']) && $_GET['v']==$key){echo ' selected';} ?>>{{$val}}</option>
                            @endforeach
                    </select>
                </div>
                <div class="form-group">
                    <select class="form-control input-sm" name="a">
                            <option value="">All</option>
                            @foreach(activelevel() as $key => $val )
                            <option value="{{$key}}" <?php if(isset($_GET['a']) && $_GET['a']==$key){echo ' selected';} ?>>{{$val}}</option>
                            @endforeach
                    </select>
                </div>
                
                <div class="form-group">
                    <select class="form-control input-sm" name="s">
                        <option value="asc" <?php if(isset($_GET['s']) && $_GET['s']=='asc'){echo ' selected';} ?>>Ascending</option>
                        <option value="desc" <?php if(isset($_GET['s']) && $_GET['s']=='desc'){echo ' selected';} ?>>Descending</option>
                    </select>
                </div>
                    
                <div class="form-group">
                    <button type="submit" class="btn btn-primary btn-sm" name='search'>Go</button>
                </div>
            {{ Form::close() }}
    </div>
    <div class="box-body">
  		<table id="pagetable" class="table table-bordered table-striped">
            <thead>
          		<tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Email Verification</th>
                    <th>Status</th>
                    <th>Manage</th>
              	</tr>
            </thead>
            <tbody>
            	@if(isset($users) && !empty($users))
					@foreach($users as $page)
	              	<tr>
	                    <td>{{$page->id}}</td>
	                    <td>{{$page->fname}} {{$page->lname}}</td>
	                    <td>{{$page->username}}</td>
	                    <td><a href="mailto:{{$page->email}}">{{$page->email}}</a></td>
	                    <td>{{roleaccess($page->role)}}</td>
	                    <td>
	                    	@if($page->verified==1)
		                    	<span class="label label-danger">{{isemailverified($page->verified)}}</span>
		                    @elseif($page->verified==2)
		                    	<span class="label label-success">{{isemailverified($page->verified)}}</span>
		                    @endif
	                    </td>
	                    <td>
	                    @if($page->active==1)
	                    	<span class="label label-danger">{{activelevel($page->active)}}</span>	
	                    @elseif($page->active==2)
	                    	<span class="label label-warning">{{activelevel($page->active)}}</span>	
	                    @elseif($page->active==3)
	                    	<span class="label label-info">{{activelevel($page->active)}}</span>
	                    @elseif($page->active==4)
	                    	<span class="label label-success">{{activelevel($page->active)}}</span>
	                    @endif
	                    </td>
	                    <td>
	                    	<ul class="menu-manager">
	                    		<li><a href="{{ route('viewuserinfo',['id'=>$page->id]) }}" data-toggle="tooltip" title="View User Info"><i class="fa fa-eye"></i></a></li>
	                    		@if($logged_role > $page->role || $logged_id == $page->id)
	                    		<li><a href="{{ route('edituserinfo', ['id'=>$page->id]) }}" data-toggle="tooltip" title="Edit User Info"><i class="fa fa-pencil-square-o"></i></a></li>
	                    		@endif
	                    	</ul>
	                    </td>
	              	</tr>
					@endforeach
				@endif
            </tbody>
            <tfoot>
              	<tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Email Verification</th>
                    <th>Status</th>
                    <th>Manage</th>
              	</tr>
            </tfoot>
  		</table>
    </div><!-- /.box-body -->
</div><!-- /.box -->
	<div class="common-pagination">
		<?php 
			$pagifpname = 'First'; $pagippname = 'prev'; $pagilpname = 'Last'; $paginpname = 'Next';
			if($users->currentPage() == '1'){
				$pagifp = '<span>'.$pagifpname.'</span>'; $pagipp = '<span>'.$pagippname.'</span>';
			}
			else{
				$pagifp = '<a href="'.route('userlist').'?';
				if(isset($getelements)){
					foreach($getelements as $key => $val){
		            	$pagifp .= $key.'='.$val.'&';
			        }
				}
				$pagifp .= 'page=1'.'">'.$pagifpname.'</a>'; $pagipp = '<a href="'.$users->previousPageUrl().'">'.$pagippname.'</a>';
			}
			if($users->lastPage() == $users->currentPage()){
				$pagilp = '<span>'.$pagilpname.'</span>'; $paginp = '<span>'.$paginpname.'</span>';
			}
			else{
				$pagilp = '<a href="'.route('userlist').'?';
				if(isset($getelements)){
					foreach($getelements as $key => $val){
		            	$pagilp .= $key.'='.$val.'&';
			        }
				}
				$pagilp .= 'page='.$users->lastPage().'">'.$pagilpname.'</a>'; $paginp = '<a href="'.$users->nextPageUrl().'">'.$paginpname.'</a>';
			}
		?>
		@if($users->total()>$users->count())
			<ul class="prevsec">
				<li>{!!$pagifp!!}</li>
				<li>{!!$pagipp!!}</li>
			</ul>
			{{$users->links()}}
			<ul class="nextsec">
				<li>{!!$paginp!!}</li>
				<li>{!!$pagilp!!}</li>
			</ul>
			<div style="clear:both"></div>
		@endif
	</div>
</div>
@endsection

@section('jscode')
	{{ Html::script('assets/common/js/datatables/jquery.dataTables.min.js') }}
	{{ Html::script('assets/common/js/datatables/dataTables.bootstrap.min.js') }}
	<script>
	    $(function () {
	      	$("#pagetable").DataTable({
	      		"paging": false,
	      		"info": false,
	      		'ordering':false
	      	});
	    });
		$(function () {
		  	$('[data-toggle="tooltip"]').tooltip()
		})
    </script>
@endsection