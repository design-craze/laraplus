@extends('admin.master.master')

@section('title', 'Menu Manager')

@section('headcode')
	{{ Html::style('assets/admin/vendor/select2/select2.min.css') }}
@endsection

@section('breadcambs', '<i class="fa fa-dashboard"></i> Menu Manager')

@section('bodycode')
	<div class="row">
		<div class="col-sm-6">
			<div class="box box-primary">
	            <div class="box-header with-border">
	            	<h3 class="box-title">Create Menu</h3>
	            </div><!-- /.box-header -->
	            {{ Form::open(array('route'=>'createdeletenav', 'method'=>'post')) }}
		            <div class="box-body">	            	
			            <div class="form-group">
		                    <!-- <label for="alllinks">Link</label> -->
			            	<input type="text" class="form-control" name="name" placeholder="menu name">
		                </div>
		            </div>
					<div class="box-footer">
						<input class="btn btn-primary" type="submit" name="submitcreate" value="Create Menu">
					</div>
				{{ Form::close() }}
	        </div>
        </div>
		<div class="col-sm-6">
			<div class="box box-primary">
	            <div class="box-header with-border">
	            	<h3 class="box-title">Delete Menu</h3>
	            </div><!-- /.box-header -->
	            <!-- form start -->
	            {{ Form::open(array('route'=>'createdeletenav', 'method'=>'post')) }}
					<div class="box-body">
						<div class="form-group">
						    <select name="deletemenu" class="form-control select2" style="width: 100%;" >
								@foreach($selectnavs as $selectitem)
									<option value="{{$selectitem->id}}"<?php if($selectitem->selected==1){echo ' selected';} ?>>{{$selectitem->name}}</option>
								@endforeach
							</select>
						</div>
					</div><!-- /.box-body -->

	                <div class="box-footer">
	                	<input type="submit" name="submitdelete" class="btn btn-primary" value="Delete Menu">
	                </div>
	            {{ Form::close() }}
	        </div>
        </div>
    </div>
	{{ Form::open(array('route'=>'createdeletenav', 'method'=>'post')) }}
		<div class="row">
			<div class="col-sm-12">
				<div class="box box-primary">
					<div class="box-header with-border">
		            	<h3 class="box-title">Manage Menu-Places</h3>
		            </div>
		            <div class="box-body">
			            <div class="form-group">
						<input type="submit" name="submitmenuplace" class="btn btn-primary" value="Update Menu Places">
						</div>
					</div>
					<div style="padding:15px">
					    <div class="row">
							@foreach($navplaces as $navplace)
							<div class="col-lg-2 col-md-3 col-sm-4 col-xs-6">
								<div class="box box-primary">
									<div class="box-header with-border">
						            	<h4 class="box-title extra-title">{{$navplace->slug}}</h4>
						            </div>
						            <div class="box-body">
							            <div class="form-group">
											<select name="menu_id{{$navplace->id}}" class="form-control select2" style="width: 100%;">
												<option value="0"<?php if($navplace->menu_id==0){echo ' selected';} ?>>None</option>
												@foreach($selectnavs as $selectitem)
													<option value="{{$selectitem->id}}"<?php if($navplace->menu_id==$selectitem->id){echo ' selected';} ?>>{{$selectitem->name}}</option>
												@endforeach
											</select>
										</div>
									</div>
								</div>
							</div>
							@endforeach
						</div>
					</div>
	            </div>
            </div>
		</div>
	{{ Form::close() }}


	{{ Form::open(array('route'=>'createdeletenav', 'method'=>'post')) }}
		<div class="row">
			<div class="col-sm-12">
				<div class="box box-primary">
					<div class="box-header with-border">
		            	<h3 class="box-title">Menu name and Class</h3>
		            </div>
		            <div class="box-body">
			            <div class="form-group">
			            <input type="submit" name="updatemenuitems" class="btn btn-primary" value="Update Menu Info">
						</div>
					</div>
					<div style="padding:15px">
					    <div class="row">
							@foreach($selectnavs as $selectitem)
							<div class="col-lg-2 col-md-3 col-sm-4 col-xs-6">
								<div class="box box-primary">
									<div class="box-header with-border">
						            	<h4 class="box-title extra-title">{{$selectitem->name}}</h4>
						            </div>
						            <div class="box-body">
							            <div class="form-group">
							            	<input type="text" class="form-control" name="editmenuname{{$selectitem->id}}" value="{{$selectitem->name}}" placeholder="Insert Name">
										</div>
							            <div class="form-group">
							            	<input type="text" class="form-control" name="editmenuclass{{$selectitem->id}}" value="{{$selectitem->class}}" placeholder="Insert Class">
										</div>
									</div>
								</div>
							</div>
							@endforeach
						</div>
					</div>
	            </div>
            </div>
		</div>
	{{ Form::close() }}
@endsection

@section('jscode')
	{{ Html::script('assets/admin/vendor/select2/select2.full.min.js') }}

	<script>
		$(function () {
	        //Initialize Select2 Elements
	        $(".select2").select2();
	    })
	</script>
@endsection