@extends('admin.master.master')

@section('title', 'Suspneded Page')

@section('headcode')
	{{ Html::style('assets/common/css/pagination.css') }}
	{{ Html::style('assets/common/js/datatables/dataTables.bootstrap.css') }}
@endsection

@section('breadcambs', '<i class="fa fa-dashboard"></i> Suspneded Page')

@section('bodycode')
	<div class="row">
		<div class="col-md-6 col-md-offset-3">
			<h3 class="text-center">Hi! {{ Auth::user()->fname }}</h3>
			@if(Auth::user()->verified ==1)
				<p class="text-center">
					Your email address is unverified. <a href="{{route('resendverifymail')}}">Click here</a> to verify your email address.
				</p>
			@else
				@if(Auth::user()->active == 2)
					<p class="text-center">
						Your Account is Suspended. Use the following form  to contact us for make your account active.
					</p>
				@elseif(Auth::user()->active == 3)
					<p class="text-center">
						Your Account is Inactive. Use the following form  to contact us for make your account active. 
					</p>
				@endif
				{{ Form::open(array('route'=>'suspendedmessageprocess', 'method'=>'post')) }}
					<div class="form-group">
					    <label>Your Message</label>
					    <textarea name="usermessage" cols="30" rows="10" class="form-control"></textarea>
					</div>
					<button type="submit" class="btn btn-default">Contact</button>
				{{ Form::close() }}
			@endif				
		</div>
	</div>
@endsection

@section('jscode')
	{{ Html::script('assets/common/js/datatables/jquery.dataTables.min.js') }}
	{{ Html::script('assets/common/js/datatables/dataTables.bootstrap.min.js') }}
	<script>
	    $(function () {
	      	$("#pagetable").DataTable({
	      		"paging": false,
	      		"info": false,
	      		'ordering':false
	      	});
	    });
		$(function () {
		  	$('[data-toggle="tooltip"]').tooltip()
		})
    </script>
@endsection