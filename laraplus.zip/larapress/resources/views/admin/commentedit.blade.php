@extends('admin.master.master')

@section('title', 'Edit Comment')

@section('headcode')
    {{ Html::style('assets/common/js/tags/tagmanager.css') }}
@endsection

@section('breadcambs', '<i class="fa fa-dashboard"></i> Edit Comment')

@section('bodycode')
    <div class="row">
        <div class="col-md-12">
            <a href="{{route('managecomment')}}" class="btn btn-default btn-flat">Go To Comment lists</a>
        </div>
    </div>
    <!-- <strong>Show Page : </strong> <a href="" target="_blank">Pagelink</a> -->
    
    {{ Form::open(array('route'=>['commenteditprocess', 'id' => $comment->id], 'method'=>'post')) }}
        <div class="row">
            <div class="col-md-8">
                <div class="panel-body page-editor">
                    <div class="form-horizontal">
                        <div class="form-group">
                            <label>Author:</label>
                            <p class="form-control">
                                <em>{{ $comment->user->fname}} {{$comment->user->lname}}</em>
                            </p>
                        </div>
                        <div class="form-group">
                            <label>In Respon To:</label>
                            <p class="form-control">
                                <em>{{ $comment->blog['name']}}</em>
                            </p>
                        </div>
                        <div class="form-group">
                            <label>Comment:</label>
                            <textarea name="description" class="form-control" placeholder="Content goes here..."><?php if(old('description')!=''){echo old('description');} else{echo $comment->description;} ?></textarea>
                        </div>

                        <div class="form-group">
                            <label>Status:</label>
                            <select class="form-control" name="is_approved">
                            @foreach(commentstatus() as $val=>$status)
                                <option value="{{$val}}"<?php if($comment->is_approved == $val){echo ' selected';} ?>>{{ $status }}</option>
                            @endforeach
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 ">
                <div class="page-editor">
                    <div class="panel">
                        <div class="panel-body">
                            <div class="form-horizontal">
                                <div class="form-group">
                                    <div class="col-md-12">
                                        <input type="submit" class="btn btn-primary btn-flat" value="Update Category">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    {{ Form::close() }}
@endsection


@section('jscode')
    {{ Html::script('assets/common/js/tags/jquery.validate.min.js') }}
@endsection