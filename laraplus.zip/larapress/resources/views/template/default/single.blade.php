@include('template.'.$settinghelper['template'].'.includes.header')
@section('templatesection')
	@if($dataerror==0)
        @if(Auth::user() && $logged_role > 6)
			<div class="row">
		        <div class="col-md-12 profile-aside">
		           	<ul class="list-unstyled list-inline">
		        		<li><a href="{{ route('blogs') }}" class="btn btn-primary btn-lg">View All Posts</a></li>
		        		<li><a href="{{ route('createblog') }}" class="btn btn-primary btn-lg">Create Post</a></li>
		        		<li><a href="{{ route('myblogs') }}" class="btn btn-primary btn-lg">My Posts</a></li>
		        	</ul>
		        </div>
		    </div>
        @endif

    <div class="row">
        
        <div class="col-md-12">
        	@if((isset($singlepost) && !empty($singlepost) && $singlepost->access_level == 0) || 
        		(Auth::user() && $singlepost->access_level == Auth::user()->role) || (isset($singlepost) && !empty($singlepost) && Auth::user() && $singlepost->user_id == Auth::user()->id) || (isset($singlepost) && !empty($singlepost) && Auth::user() && Auth::user()->role == 12))

        		@if(isset($singlepost->thumb) && !empty($singlepost->thumb))
    			<p>
        			<img src="{{$singlepost->thumb}}" alt="{{$singlepost->thumb}}" class="img-responsive">
               	</p>
               	@endif
				<h2 style="margin-top:0;">
					@if(isset($singlepost->name) && !empty($singlepost->name))
						{{$singlepost->name}}
					@endif
				</h2>
				<p class="small">
					 Post by : <a href="{{ route('profile',['logcode'=>$singlepost->user->logcode]) }}">{{$singlepost->user->fname}} {{$singlepost->user->lname}}</a> | Posted At : {{ getDateFormat($singlepost->created_at)}} | comments : {{count($singlepost->comments)}}
				</p>
				<div>
					@if(isset($singlepost->description) && !empty($singlepost->description))
						{!! strip_tags(str_replace('<a ','<a target="_blank" ', $singlepost->description), '<h1><h2><h3><h4><h5><h6><p><a><ul><ol><li><img><br><hr><strong><b><i><em><u><ins><sub><sup>') !!}
					@endif
				</div>
				<div>
					@if((Auth::user() && Auth::user()->id == $singlepost->user_id && Auth::user()->role > 6) || (Auth::user() && Auth::user()->role > 7 && Auth::user()->role > $singlepost->user->role))
					<a href="{{ route('editpost',['id'=>$singlepost->id]) }}">
						Edit Post
					</a>
					@endif
				</div>
				<hr>
				<div class="small clearfix">
					<span class="pull-left">
					@if(count($singlepost->categories) > 0)
					Posted In:
					@foreach($singlepost->categories as $cat)
                		<a href="{{route('blogcategory', ['slug'=>$cat->ctgslug])}}">{{$cat->name}}</a> |
					@endforeach
					@endif
					</span>

					@if($singlepost->metatag != null)
					<span class="pull-right">
						Tags:
						<?php $meta = explode(',', $singlepost->metatag); ?>
						@foreach($meta as $tag)
                		<a href="{{taglink($tag)}}">{{$tag}}</a> |
						@endforeach
					</span>
					@endif
				</div>

				<hr>
				<h4>Previous Comments</h4>
				<hr>
						@if($singlepost->comments)
							@foreach($singlepost->comments as $comments)
								@if($comments->parent_id == 0)
									<div class="dc-comment-box">
										<div class="main-comment">
											<div class="comment-avatar">

												@if(isset($comments->userinfo) && !empty($comments->userinfo->avatar) && !is_int($comments->userinfo->avatar))
												<img src="{{ asset(path_profile().$comments->userinfo->avatar) }}" alt="{{$comments->userinfo->avatar}}" class="img-responsive img-rounded">
												@elseif($comments->userinfo->sex == 'f')
												<img src="{{ asset(path_profile().'female.jpg') }}" alt="female.jpg" class="img-responsive img-rounded">
												@else
												<img src="{{ asset(path_profile().'male.jpg') }}" alt="male.jpg" class="img-responsive img-rounded">
												@endif
											</div>
											<div class="comment-main-box">
												<div class="list-unstyled list-inline clearfix">
													<li>{{ $comments->user->lname }}</li>
													<li><span class="small">{{ time_elapsed_string($comments->updated_at) }}</span></li>
												</div>
												<div class="comment dc_comment_text" id="dc_comment_text_{{$comments->id}}">
													{!! strip_tags(str_replace('<a ','<a target="_blank" ', $comments->description), '<a><br><strong><b><i><em><u>') !!}
												</div>
												@if(Auth::user() && Auth::user()->id == $comments->user_id)
													<div class="edit-comment dc_edit_comment_box" id="dc_edit_comment_box_{{$comments->id}}">
														{{ Form::open(array('route'=>['updatecomment','blogid'=>$singlepost->id,'comid'=>$comments->id], 'method'=>'post')) }}
														<div class="edit-textarea">
															<textarea name="editcomment" class="editcomment form-control dc_edit_comment_txtbox" rows="3" class="form-control" id="dc_edit_comment_txtbox_{{$comments->id}}"></textarea>
														</div>
														
														<div class="form-button-action">
															<a id="dc_edit_comment_close_{{$comments->id}}" href="#" class="btn btn-default btn-sm cancel-com"><i class="fa fa-close"></i></a>
															<button type="submit" name="update{{$comments->id}}" class="btn btn-default btn-sm">update</button>
														</div>
														{{ Form::close() }}
													</div>
												@endif
											</div>
											<div class="comment-action">
												<div class="update-com-btn pull-right">
													@if(Auth::user())
														@if(Auth::user()->id == $comments->user_id)
															<a id="dc_edit_comment_btn_{{$comments->id}}" href="#" class="btn btn-default btn-sm edit-com"><i class="fa fa-edit"></i></a>
															<a href="{{ route('deletecomment',['blogid'=>$singlepost->id,'comid'=>$comments->id]) }}" class="btn btn-default btn-sm delete-com"><i class="fa fa-trash"></i></a>
														@endif
														<a id="dc_reply_comment_btn_{{$comments->id}}" href="#" class="btn btn-default btn-sm reply-com"><i class="fa fa-reply"></i></a>
													@endif
												</div>
											</div>
										</div>		
											@foreach($singlepost->comments as $subcomments)
												@if($subcomments->parent_id == $comments->id)
													<div class="comment-box">
														<div class="sub-comment">
															<div class="comment-avatar">

																@if(isset($subcomments->userinfo) && !empty($subcomments->userinfo->avatar) && !is_int($subcomments->userinfo->avatar))
																<img src="{{ asset(path_profile().$subcomments->userinfo->avatar) }}" alt="{{$subcomments->userinfo->avatar}}" class="img-responsive img-rounded">
																@elseif($subcomments->userinfo->sex == 'f')
																<img src="{{ asset(path_profile().'female.jpg') }}" alt="female.jpg" class="img-responsive img-rounded">
																@else
																<img src="{{ asset(path_profile().'male.jpg') }}" alt="male.jpg" class="img-responsive img-rounded">
																@endif
															</div>
															<div class="comment-main-box">
																<div class="list-unstyled list-inline clearfix">
																	<li>{{ $subcomments->user->lname }}</li>
																	<li><span class="small">{{ time_elapsed_string($subcomments->updated_at) }}</span></li>
																</div>
																<div class="comment dc_comment_text" id="dc_comment_text_{{$subcomments->id}}">
																	{!! strip_tags(str_replace('<a ','<a target="_blank" ', $subcomments->description), '<a><br><strong><b><i><em><u>') !!}
																</div>
																@if(Auth::user() && Auth::user()->id == $subcomments->user_id)
																	<div class="edit-comment dc_edit_comment_box" id="dc_edit_comment_box_{{$subcomments->id}}">
																		{{ Form::open(array('route'=>['updatecomment','blogid'=>$singlepost->id,'comid'=>$subcomments->id], 'method'=>'post')) }}
																		<div class="edit-textarea">
																			<textarea name="editcomment" class="editcomment form-control" rows="3" class="form-control dc_edit_comment_txtbox" id="dc_edit_comment_txtbox_{{$subcomments->id}}"></textarea>
																		</div>
																		<div class="form-button-action">
																		<a id="dc_edit_comment_close_{{$subcomments->id}}" href="#" class="btn btn-default btn-sm cancel-com"><i class="fa fa-close"></i></a>
																		<button type="submit" name="update{{$subcomments->id}}" class="btn btn-default btn-sm">update</button>
																		</div>
																		{{ Form::close() }}
																	</div>
																@endif
															</div>
															<div class="comment-action">
																<div class="update-com-btn pull-right">
																	@if(Auth::user() && Auth::user()->id == $subcomments->user_id)
																	<a id="dc_edit_comment_btn_{{$subcomments->id}}" href="#" class="btn btn-default btn-sm edit-com"><i class="fa fa-edit"></i></a>
																	<a href="{{ route('deletecomment',['blogid'=>$singlepost->id,'comid'=>$subcomments->id]) }}" class="btn btn-default btn-sm delete-com"><i class="fa fa-trash"></i></a>
																	@endif
																</div>
															</div>
														</div>
													</div>
												@endif
											@endforeach
										@if(Auth::user())
										<!-- start: reply -->
										<div class="dc-comment-reply-box dc_reply_comment_box" id="dc_reply_comment_box_{{$comments->id}}">
											<div class="comment-avatar">
												@if(isset(Auth::user()->userinfo) && !empty(Auth::user()->userinfo->avatar) && !is_int(Auth::user()->userinfo->avatar))
												<img src="{{ asset(path_profile().Auth::user()->userinfo->avatar) }}" alt="{{Auth::user()->userinfo->avatar}}" class="img-responsive img-rounded">
												@elseif(Auth::user()->userinfo->sex == 'f')
												<img src="{{ asset(path_profile().'female.jpg') }}" alt="female.jpg" class="img-responsive img-rounded">
												@else
												<img src="{{ asset(path_profile().'male.jpg') }}" alt="male.jpg" class="img-responsive img-rounded">
												@endif
											</div>
											<div class="comment-main-box">
												<div class="list-unstyled list-inline clearfix">
													<li>{{ Auth::user()->lname }}</li>
												</div>
												<div class="reply-comment">
													{{ Form::open(array('route'=>['replycomment','blogid'=>$singlepost->id,'parentid'=>$comments->id],'method'=>'post')) }}
													<div class="reply-textarea">
														<textarea id="dc_reply_comment_txtbox_{{$comments->id}}" name="replycomment" class="replycomment form-control dc_reply_comment_txtbox" rows="1" class="form-control"></textarea>
													</div>
													<div class="form-button-action-reply">
													<a id="dc_reply_comment_close_{{$comments->id}}" href="#" class="btn btn-default btn-sm cancel-reply"><i class="fa fa-close"></i></a>
													<button type="submit" name="reply{{$comments->id}}" class="btn btn-default btn-sm">Reply</button>
													</div>
													{{ Form::close() }}
												</div>
											</div>
										</div>
										@endif
									</div>
								@endif
							@endforeach
						@endif
				
				@if($singlepost->commentable == 1)	
					@if(Auth::user())
						<div class="comment-seperator"></div>
						<h5 style="margin:0 0 30px; font-weight: 700">Leave Your Comment Here:</h5>
						<div class="dc-main-comment-box">
							<div class="comment-avatar">
								@if(isset(Auth::user()->userinfo) && !empty(Auth::user()->userinfo->avatar) && !is_int(Auth::user()->userinfo->avatar))
								<img src="{{ asset(path_profile().Auth::user()->userinfo->avatar) }}" alt="{{Auth::user()->userinfo->avatar}}" class="img-responsive img-rounded">
								@elseif(Auth::user()->userinfo->sex == 'f')
								<img src="{{ asset(path_profile().'female.jpg') }}" alt="female.jpg" class="img-responsive img-rounded">
								@else
								<img src="{{ asset(path_profile().'male.jpg') }}" alt="male.jpg" class="img-responsive img-rounded">
								@endif
							</div>
							<div class="comment-main-box">
								<div class="list-unstyled list-inline clearfix">
									<li>{{ Auth::user()->lname }}</li>
								</div>
								{{ Form::open(array('route'=>['submitcomment','blogid'=>$singlepost->id], 'method'=>'post')) }}
								<div class="reply-textarea">
									<textarea id="comment" name="comment" rows="3" class="form-control"></textarea>
								</div>
								<div class="form-button-action-reply">
									<button name="comsubmit" class="btn btn-default btn-sm">Submit</button>
								</div>
								{{ Form::close() }}
							</div>
						</div>
					@else
						@if($settinghelper['login_page'] !='')
						<a href="{{ route('page', ['slug'=>getpage($settinghelper['login_page'])]) }}" class="btn btn-primary btn-sm">Login</a>
						@endif
					@endif
				@endif
            @else
            <div class="panel panel-default custom-panel">
            	<div class="panel-body">
					<h4 class="text-center">
						This post is only for certain users. You are not eligable to see this post.
					</h4>
				</div>
			</div>
            @endif
		</div>
    </div>    
    @else
	<div class="col-md-12">
		<div class="panel panel-default custom-panel">
            <div class="panel-body">
				<h4 class="text-center">
					No blog found to view.
				</h4>
			</div>
		</div>
	</div>
	@endif
@section('jscode')
	{{-- {{ Html::script('assets/common/js/comment.js') }} --}}
@if($singlepost->comments)
	@foreach($singlepost->comments as $comments)
		@if($comments->parent_id == 0)
			@if(Auth::user() && Auth::user()->id == $comments->user_id)
				<script>
					$(function(){
						$('#dc_edit_comment_close_{{$comments->id}}').on('click',function(e){
							e.preventDefault();
							$('#dc_edit_comment_txtbox_{{$comments->id}}').val('');
							$('#dc_comment_text_{{$comments->id}}').show();
							$('#dc_edit_comment_box_{{$comments->id}}').hide();
						})
					})
				</script>
			@endif
			@if(Auth::user())
				@if(Auth::user()->id == $comments->user_id)
					<script>
						$(function(){
							$('#dc_edit_comment_btn_{{$comments->id}}').on('click',function(e){
								e.preventDefault();
								$('.dc_reply_comment_txtbox').text('');
								$('.dc_reply_comment_box').hide();
								$('.dc_edit_comment_txtbox').val('');
								$('.dc_comment_text').show();
								$('.dc_edit_comment_box').hide();
								$('#dc_edit_comment_txtbox_{{$comments->id}}').val($('#dc_comment_text_{{$comments->id}}').text().trim());
								$('#dc_comment_text_{{$comments->id}}').hide();
								$('#dc_edit_comment_box_{{$comments->id}}').show();
							})
						})
					</script>
				@endif
					<script>
						$(function(){
							$('#dc_reply_comment_btn_{{$comments->id}}').on('click',function(e){
								e.preventDefault();
								$('.dc_reply_comment_txtbox').text('');
								$('.dc_reply_comment_box').hide();
								$('.dc_edit_comment_txtbox').val('');
								$('.dc_comment_text').show();
								$('.dc_edit_comment_box').hide();
								$('#dc_reply_comment_box_{{$comments->id}}').css('display','table');
							})
						})
					</script>
			@endif
						
					@foreach($singlepost->comments as $subcomments)
						@if($subcomments->parent_id == $comments->id)
							@if(Auth::user() && Auth::user()->id == $subcomments->user_id)
								<script>
									$(function(){
										$('#dc_edit_comment_close_{{$subcomments->id}}').on('click',function(e){
											e.preventDefault();
											$('#dc_edit_comment_txtbox_{{$subcomments->id}}').val('');
											$('#dc_comment_text_{{$subcomments->id}}').show();
											$('#dc_edit_comment_box_{{$subcomments->id}}').hide();
										})
									})
								</script>
							@endif
								<script>
									$(function(){
										$('#dc_edit_comment_btn_{{$subcomments->id}}').on('click',function(e){
											e.preventDefault();
											$('.dc_reply_comment_txtbox').text('');
											$('.dc_reply_comment_box').hide();
											$('.dc_edit_comment_txtbox').val('');
											$('.dc_comment_text').show();
											$('.dc_edit_comment_box').hide();
											$('#dc_edit_comment_txtbox_{{$subcomments->id}}').val($('#dc_comment_text_{{$subcomments->id}}').text().trim());
											$('#dc_comment_text_{{$subcomments->id}}').hide();
											$('#dc_edit_comment_box_{{$subcomments->id}}').show();
										})
									})
								</script>
						@endif
					@endforeach
				</div>
				@if(Auth::user())
				<!-- start: reply -->
					<script>
						$(function(){
							$('#dc_reply_comment_close_{{$comments->id}}').on('click',function(e){
								e.preventDefault();
								$('.dc_reply_comment_txtbox').text('');
								$('.dc_reply_comment_box').hide();
								$('.dc_edit_comment_txtbox').val('');
								$('.dc_comment_text').show();
								$('.dc_edit_comment_box').hide();
								$('#dc_reply_comment_txtbox_{{$comments->id}}').val('');
								$('#dc_reply_comment_box_{{$comments->id}}').hide();
							})
						})
					</script>
				@endif
		@endif
	@endforeach
@endif
@endsection
@include('template.'.$settinghelper['template'].'.includes.footer')