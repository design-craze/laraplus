@include('template.'.$settinghelper['template'].'.includes.header')
@section('templatesection')
	@if(!Auth::user())
		<div class="row">
			<div class="col-md-12">
				<div class="access-form">
					<div class="access-form-top">
						<div class="access-form-top-left bg-default">
							<h2>WELCOME</h2>
							<p>Change your password and secure your account.</p>
						</div>
						<div class="access-form-top-right bg-second">
							<h4>New Here? Create An Account</h4>
							<a href="<?php 
							if($settinghelper['signup_page']!=''){echo route('page',['slug'=>getpage($settinghelper['signup_page'])]);}
							?>" class="btn btn-primary btn-lg">Sign Up</a>
						</div>
					</div>
					<div class="access-form-bottom">
					{{ Form::open(array('route'=>['recoveryemailprocess','vfcode'=>$vfcode], 'method'=>'post')) }}
				        <input type="password" placeholder="Enter New Password" name="new_pass">
				        <input type="password" placeholder="Confirm Password" name="new_pass_confirmation">
					    <button type="submit" class="btn btn-primary btn-lg" name="save_new_pass">Change Password</button>
					{{ Form::close() }}
					</div>
				</div>
			</div>
		</div>
	@else
	<div class="panel-body">
		Logged in user is not allowed to view this page! Please Log out and try again.
	</div>
	@endif
@show
@include('template.'.$settinghelper['template'].'.includes.footer')