@include('template.'.$settinghelper['template'].'.includes.header')
@section('templatesection')
	@if($dataerror==0)
	<div class="row">
        <div class="col-md-12 profile-aside">
            <div class="row">
            	 <div class="col-md-4">
                    <h1 class="profile-name">Hey! I'm {{$user->lname}}</h1>
					@if(isset($userinfo) && !empty($userinfo))
                    <p><i class="fa fa-map-marker text-green"></i> {{$userinfo->city}} - {{country($userinfo->country)}}, Member since {{ getDateFormat($userinfo->created_at)}}</p>
					@endif
                </div>
                <div class="col-md-4">
                    <div class="dc-pro-img">
			        	@if(isset($userinfo) && !empty($userinfo->avatar) && !is_int($userinfo->avatar))
						<img src="{{ asset(path_profile().$userinfo->avatar) }}" alt="{{$userinfo->avatar}}" class="img-responsive img-rounded">
						@elseif($userinfo->sex == 'f')
						<img src="{{ asset(path_profile().'female.jpg') }}" alt="female.jpg" class="img-responsive img-rounded">
						@else
						<img src="{{ asset(path_profile().'male.jpg') }}" alt="male.jpg" class="img-responsive img-rounded">
						@endif
			        </div>
                </div> 
            	<div class="col-md-4">
                    <div class="panel panel-default custom-panel">
                        <div class="panel-heading">Verification</div>
                        <div class="panel-body">
                        	<ul class="list-group">
                        		<li class="list-group-item">
                        			Email Address :
                        			@if($user->verified==1)
				                    	<span class="label label-danger">{{isemailverified($user->verified)}}</span>
				                    @elseif($user->verified==2)
				                    	<span class="label label-success">{{isemailverified($user->verified)}}</span>
				                    @endif
                        		</li>
                        		<li class="list-group-item">
                        			Account Status: 
                        			@if($user->active==1)
				                    	<span class="label label-danger">{{activelevel($user->active)}}</span>	
				                    @elseif($user->active==2)
				                    	<span class="label label-warning">{{activelevel($user->active)}}</span>	
				                    @elseif($user->active==3)
				                    	<span class="label label-info">{{activelevel($user->active)}}</span>
				                    @elseif($user->active==4)
				                    	<span class="label label-success">{{activelevel($user->active)}}</span>
				                    @endif
                        		</li>
                        	</ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-12">
                	@if($logged_id == $user->id)
                    <p><a href="{{ route('editprofile') }}" class="text-info small"> <i class="fa fa-pencil"></i> Edit Profile</a></p>
                    @endif
                    <div class="panel panel-default custom-panel">
                        <div class="panel-heading">Details</div>
                        <div class="panel-body">
                            <table class="table table-striped">
								<tr>
									<td class="col-xs-3 col-sm-6">Name</td>
									<td>: {{$user->fname}} {{$user->lname}}</td>
								</tr>
								 @if($logged_id == $user->id)
								<tr>
									<td>Username</td>
									<td>: {{$user->username}}</td>
								</tr>
								@endif
								<tr>
									<td>Email</td>
									<td>: <a href="mailto:{{$user->email}}">{{$user->email}}</a></td>
								</tr>
								<tr>
									<td>Role</td>
									<td>: {{roleaccess($user->role)}}</td>
								</tr>
								@if(isset($userinfo))
								<tr>
									<td>Addres Line 1</td>
									<td>: {{$userinfo->street1}}</td>
								</tr>
								<tr>
									<td>Addres Line 2</td>
									<td>: {{$userinfo->street2}}</td>
								</tr>
								<tr>
									<td>City</td>
									<td>: {{$userinfo->city}}</td>
								</tr>
								<tr>
									<td>State</td>
									<td>: {{$userinfo->state}}</td>
								</tr>
								<tr>
									<td>Zip</td>
									<td>: {{$userinfo->zip}}</td>
								</tr>
								<tr>
									<td>Country</td>
									<td>: {{country($userinfo->country)}}</td>
								</tr>
								<tr>
									<td>Sex</td>
									<td>: {{gender($userinfo->sex)}}</td>
								</tr>
								<tr>
									<td>Contact No.</td>
									<td>: <a href="tel:{{$userinfo->contact}}">{{$userinfo->contact}}</a></td>
								</tr>
								<tr>
									<td>Description</td>
									<td>: {{$userinfo->description}}</td>
								</tr>
								<tr>
									<td>Date Of Birth</td>
									<td>:
										@if($userinfo->dob)
											{{ getDateFormat($userinfo->dob,'d M, Y') }}
										@else
										Not Defined
										@endif
									</td>
								</tr>
								<tr>
									<td>Last Update</td>
									<td>: {{ getDateFormat($userinfo->updated_at) }}</td>
								</tr>
								@endif
							</table>
	            		</div>
                    </div>
                </div>
            </div>
        </div>
    </div>    
    @else
	<div class="col-md-12">
		<div class="panel panel-default custom-panel">
            <div class="panel-body">
				<h4 class="text-center">
					No user found to view.
				</h4>
			</div>
		</div>
	</div>
	@endif
@show
@include('template.'.$settinghelper['template'].'.includes.footer')