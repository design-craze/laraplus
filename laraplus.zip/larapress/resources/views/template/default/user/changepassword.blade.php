@include('template.'.$settinghelper['template'].'.includes.header')
@section('templatesection')
	<div class="row">
		@if(Auth::user()->active == 3 && Auth::user()->role != 12)
        <div class="col-md-12">
			<div class="panel panel-default custom-panel">
	            <div class="panel-body">
					<h4 class="text-center">
						You can not edit your profile at inactive mode. To make your profile active please contact to our help center. 
					</h4>
				</div>
			</div>
		</div>
        @else
		<div class="col-md-12">
			<div class="access-form">
				<div class="access-form-top">
					<div class="access-form-top-left bg-default">
						<h2>RESET PASSWORD</h2>
						<p>Reset Your Password and get your account secured</p>
					</div>
				</div>
				<div class="access-form-bottom">
				{{ Form::open(array('route'=>'changepasswordprocess', 'method'=>'post')) }}
					<label for="old_pass">Enter Old Password</label>
					<input type="password" name="old_pass" id="old_pass" placeholder="Enter Your Old Password">
					<label for="new_pass">Enter New Password</label>
					<input type="password" name="new_pass" id="new_pass" placeholder="Password">
					<label for="new_pass_con">Confirm Password</label>
					<input type="password" name="new_pass_confirmation" id="new_pass_con" placeholder="Confirm New Password">
					<input type="submit" name="change_pass" class="btn btn-primary btn-lg" value="Change Password">
				{{ Form::close() }}
				</div>
			</div>
		</div>
        </div>
		@endif
    </div>
@show
@include('template.'.$settinghelper['template'].'.includes.footer')