                        </div>
                    </div>
                    @if(isset($data->rightside) && !isset($data->user_id) && $data->rightside != 'default' && $data->rightside != 'none')
                        <div class="col-md-3 col-sm-4">
                            <div class="side-widget right-sidebar">
                                {!!getwidget($data->rightside)!!}
                            </div>
                        </div>
                    @elseif(isset($data->rightside) && !isset($data->user_id) && $data->rightside == 'default' && $settinghelper['page_rightsidebar']!='' && $settinghelper['page_rightsidebar']!='none')
                        <div class="col-md-3 col-sm-4">
                            <div class="side-widget right-sidebar">
                                {!!getwidget($settinghelper['page_rightsidebar'])!!}
                            </div>
                        </div>
                    @elseif(!isset($data->rightside) && !isset($data->user_id) && $settinghelper['page_rightsidebar']!='' && $settinghelper['page_rightsidebar']!='none')
                        <div class="col-md-3 col-sm-4">
                            <div class="side-widget right-sidebar">
                                {!!getwidget($settinghelper['page_rightsidebar'])!!}
                            </div>
                        </div>
                    @elseif(!isset($data->rightside) && isset($data->user_id) && $settinghelper['blog_rightsidebar']!='' && $settinghelper['blog_rightsidebar']!='none')
                        <div class="col-md-3 col-sm-4">
                            <div class="side-widget right-sidebar">
                                {!!getwidget($settinghelper['blog_rightsidebar'])!!}
                            </div>
                        </div>
                    @endif
                </div>
            </div>
        </div>
        <!--end: main-->
        <!--start: footer-->
        <?php
        $footercontainer =' dc-body-box-layout';
        if(isset($data->ftrlayout) && $data->ftrlayout == '1'){$footercontainer = '';}
        elseif(isset($data->ftrlayout) && $data->ftrlayout == '-1' && $settinghelper['footer_layout']=='1'){$footercontainer = '';}
        elseif(!isset($data->ftrlayout) && $settinghelper['footer_layout']=='1'){$footercontainer = '';}
        // dd($settinghelper['footer_layout']);
        ?>
        <footer class="footer">
            <?php 
                $myfooter = 0;
                $myfooterclass='';
                if(isset($data->ftrwid) && $data->ftrwid !='-1' && $data->ftrwid !='0' && $data->ftrwid !=''){
                    $myfooter = $data->ftrwid;
                }                
                else if(isset($data->ftrwid) && $data->ftrwid =='-1' && $settinghelper['footer'] != '0'){
                    $myfooter = $settinghelper['footer'];
                }
                elseif(!isset($data->ftrwid) && $settinghelper['footer'] != '0')
                {
                    $myfooter = $settinghelper['footer'];
                }

                if($myfooter >0){
            ?>
                    <div class="ftr-top{{$footercontainer}}">
                        <div class="container">
                            <div class="row">
            <?php
                                if($myfooter==1){
                                    $myfooterclass = 'col-md-12';
                                }
                                elseif($myfooter==2){
                                    $myfooterclass = 'col-sm-6';
                                }
                                elseif($myfooter==3){
                                    $myfooterclass = 'col-md-4';
                                }
                                elseif($myfooter==4){
                                    $myfooterclass = 'col-md-3 col-sm-6';
                                }
                                for($i=1; $i<=$myfooter; $i++){
            ?>
                                    <div class="{{$myfooterclass}}">
                                        <?php
                                            echo getwidget('f'.$i);
                                        ?>
                                    </div>
            <?php
                                }
            ?>
                            </div>
                        </div>
                    </div>
            <?php
                }
                $myfooter = 0;
                if(isset($data->btmftr) && $data->btmftr !='-1' && $data->btmftr !='0' && $data->btmftr !=''){
                    $myfooter = $data->btmftr;
                }                
                else if(isset($data->btmftr) && $data->btmftr =='-1' && $settinghelper['bottom_footer'] != '0'){
                    $myfooter = $settinghelper['bottom_footer'];
                }
                elseif(!isset($data->btmftr) && $settinghelper['bottom_footer'] != '0')
                {
                    $myfooter = $settinghelper['bottom_footer'];
                }
                if($myfooter ==1)
                {

            ?>
                    <!--start: footer bottom-->
                    <section class="ftr-bottom{{$footercontainer}}">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="copyright">
                                        {!!ifavailable([$settinghelper['copyright_text']])!!}
                                    </div>
                                </div>
                            </div>
                            <!--end: footer bottom-->
                        </div>
                    </section>
            <?php } ?>
        </footer>
        <a href="#" class="scrollToTop"><i class="fa fa-plus"></i></a>
        <!--end: footer-->

        
        <!-- Include all compiled plugins (below), or include individual files as needed -->
        {{ Html::script('assets/common/js/bootstrap.min.js') }}
        <!--start: Common nav js-->
        {{ Html::script('assets/common/js/dc-nav/dc-nav.js') }}
        <!--start: custom JS-->
        {{ Html::script('assets/common/js/dc-custom/dc-custom.js') }}
        <script type="text/javascript">
            $(function(){
                var dcMetaTags =$('meta[name="keywords"]');
                var dcMetaKeys = '';
                for(var i=0; i<dcMetaTags.length; i++){
                    var dcMetaKey = $(dcMetaTags[i]).attr('content');
                    var dcMetaKey = dcMetaKey.split(',');
                    for(var x=0; x<dcMetaKey.length; x++){
                        var tempMeta = dcMetaKey[x].trim();
                        if(tempMeta !=''){
                            dcMetaKeys = dcMetaKeys + '<a class="dc-meta-link" href="';
                            dcMetaKeys = dcMetaKeys + '<?php echo route("searchblog"); ?>';
                            dcMetaKeys = dcMetaKeys + '/?tag='+tempMeta+'">'+tempMeta +'</a>';
                        }
                    }
                }                
                $('.dc-metatag').html(dcMetaKeys);
            })
        </script>
        @yield('jscode')
        <!-- start: custom setting js -->
        @if (isset($settinghelper['custom_js']) && $settinghelper['custom_js'] != '')
            <script>
                {!!$settinghelper['custom_js']!!}
            </script>
        @endif
        <!--end: custom setting JS-->
        <!-- page js -->
        @if (isset($data->js) && $data->js !='')
            <style>
                {!!$data->js!!}
            </style>
        @endif
    </body>
</html>