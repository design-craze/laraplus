@section('headcode')
{{ Html::style('http://fonts.googleapis.com/css?family=Coustard') }}
{{ Html::style('http://fonts.googleapis.com/css?family=Raleway:400,300') }}
{{ Html::style('assets/template/lara-seventeen/css/construction.css') }}
<style>
	#main{		
		background: url({{ asset('assets/template/lara-seventeen/image/coming-soon.jpg') }}) no-repeat;
		-webkit-background-size: cover;
		background-size: cover;
	}
</style>
@endsection
@include('template.'.$settinghelper['template'].'.includes.header')
@section('templatesection')
	<!-- Header Section Starts -->
    <section id="header" style="padding-top:50px">
            <div class="container">
                <div class="row">
                	<div class="col-sm-6">
                		<!-- Logo Starts -->
			                <div style="display: table;margin: 40px auto 50px;" class="clearfix">
			                    <a href="{{ route('home') }}">
			                    @if(isset($settinghelper['logo_type']) && $settinghelper['logo_type'] == '2')
			                        @if(isset($settinghelper['logo_img']) && $settinghelper['logo_img'] != null)
			                            <img class="img-responsive" src="{{ asset(path_logo().$settinghelper['logo_img']) }}" alt="LOGO IMG">
			                        @else
			                            <img class="img-responsive" src="{{ asset('assets/template/lara-seventeen/image/logo.png') }}" alt="LOGO IMG">
			                        @endif
			                    @elseif(isset($settinghelper['logo_type']) && $settinghelper['logo_type'] == '1')
			                        @if(isset($settinghelper['site_name']) && $settinghelper['site_name'] != null)
			                            <h4 class="dc-text-default">
			                                {{ $settinghelper['site_name'] }}
			                            </h4>
			                        @else
			                            <h4 class="dc-text-default">LaraPress 17</h4>
			                        @endif
			                    @endif
			                	</a>
			                </div>
			                <!-- Logo Ends -->
			                <!-- Main Heading Starts -->
			                <div class="main-head">
			                    <h2 style="padding: 15px 0 25px;">
			                    	Website is under maintenance for better service 
			                    </h2>
			                    <p style="padding-top: 20px;">
			                        Stay tuned and be patient. Your patience will
			                        be well paid.</p>
			                </div>
	                	</div>
	                
	                <!-- Main Heading Ends -->
	                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
	                    {{ Form::open(array('route'=>'contactusprocess', 'method'=>'post','style'=>'font-size:14px !important; color: #666 !important;')) }}
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<input type="text" name="name" id="name" placeholder="Name">
								</div>
								<div class="form-group">
									<input type="email" name="email" id="email" placeholder="Email">
								</div>
								<div class="form-group">
									<input type="text" name="subject" id="subject" placeholder="Subject">
								</div>
								<div class="form-group">
									<textarea name="message" id="message" cols="30" rows="5"></textarea>
								</div>
								<div class="form-group">
									{!! app('captcha')->display(); !!}
								</div>
								<div class="form-group">
									<button type="submit" name="contact_us" class="btn dc-btn">Submit</button>
								</div>
							</div>
						</div>
						{{ Form::close() }}
	                </div>                
                </div>
            </div>
    </section>
    <!-- Header Section Ends -->

  
    <!-- Contact Us Section Ends -->
    <!-- Footer Starts -->
    <section id="footer">
        <div class="container">
            <!-- Copyright Starts -->
            <div data-scroll-reveal="enter bottom and move 50px over 1.2s">
                <p data-scroll-reveal="enter over 3.2s">
                    {!!ifavailable([$settinghelper['copyright_text']])!!}
                </p>
            </div>
            <!-- Copyright Ends -->
        </div>
    </section>
    <!-- Footer Ends -->
@show
@include('template.'.$settinghelper['template'].'.includes.footer')