@extends('template.'.$settinghelper['template'].'.page-template.'. ifavailable([$data->template, allsetting('template')]))
@section('body')
	@if($data->access_level == -1 && $userlevel > 0)
	    {{accessunloggeduser('en')}}
	@elseif($data->access_level > 0 && $data->access_level > $userlevel)
	    {{accesscompare($data->access_level,'en')}}
	@else
			{!! generate_shortcode($data->description) !!}
			@section('templatesection')
         		@parent
         	@endsection
	@endif
@endsection