<?php 
if(!defined('SHORTCODES') || SHORTCODES != 'shortcode'){exit();}


$this->add_shortcode('lightbox', function($atts, $content = null){
    extract($this->shortcode_atts(array(
                'image'  =>'',
                'class' =>'',
                'grouped' =>''
        ), 
    $atts));
    if($grouped=='yes'){
    	$grouped ='dc-lbimg-lnk';
    }
    else{
    	$grouped ='sl-lbimg';
    }
    if($image==''){
        $image = '#';
    }
    if($class!=''){
    	$class = ' '. trim($class);
    }
    $output = '<a href="'.$image.'" class="'.$grouped.$class.'">'.$content.'</a>';
    return $output;
});

$this->add_shortcode('glightbox', function($atts, $content = null){
    extract($this->shortcode_atts(array(
                'class' =>''
        ), 
    $atts));
    if($class!=''){
    	$class = ' '. trim($class);
    }
    $output = '<div class="group-lbox'.$class.'">'.$this->do_shortcode($content).'</div>';
    return $output;
});

$this->add_shortcode('portfolio', function($atts, $content = null){
    extract($this->shortcode_atts(array(
                'class' =>'',
                'maincol' => '',
                'medcol' => '',
                'smcol' => '',
                'tinycol' => '',
                'animtype' => '',
                'animation' => '',
                'top' => '',
                'bottom' => '',
                'left' => '',
                'right' => '',
                'capitalize' => '',
        ), 
    $atts));
    if(ctype_digit($maincol) && $maincol>0){$maincol= ' data-maincol="'.$maincol.'"';}else{$maincol='';}
    if(ctype_digit($medcol) && $medcol>0){$medcol= ' data-medcol="'.$medcol.'"';}else{$medcol='';}
    if(ctype_digit($smcol) && $smcol>0){$smcol= ' data-smcol="'.$smcol.'"';}else{$smcol='';}
    if(ctype_digit($tinycol) && $tinycol>0){$tinycol= ' data-tinycol="'.$tinycol.'"';}else{$tinycol='';}
    if(ctype_digit($top) && $top>0){$top= ' data-top="'.$top.'"';}else{$top='';}
    if(ctype_digit($bottom) && $bottom>0){$bottom= ' data-bottom="'.$bottom.'"';}else{$bottom='';}
    if(ctype_digit($left) && $left>0){$left= ' data-left="'.$left.'"';}else{$left='';}
    if(ctype_digit($right) && $right>0){$right= ' data-right="'.$right.'"';}else{$right='';}
    if($capitalize=='no'){$capitalize= ' data-capitalize="no"';}else{$capitalize='';}
    if($animtype=='modern'){$animtype= ' data-animation="modern"';}else{$animtype='';}
    if($animation!=''){$animation= ' data-appearance="'.$animation.'"';}else{$animation='';}
    if($class!=''){
    	$class = ' '. trim($class);
    }
    $output = '<div class="dc-pfolio'.$class.'"><div class="dc-pfbox"'.$maincol.$medcol.$smcol.$tinycol.$top.$bottom.$left.$right.$capitalize.$animtype.$animation.'>'.$this->do_shortcode($content).'</div></div>';
    return $output;
});

$this->add_shortcode('pf_item', function($atts, $content = null){
    extract($this->shortcode_atts(array(
                'lbimage' =>'',
                'lbicon'=>'fa-search',
                'image' =>'',
                'link'=>'#',
                'linkicon'=> 'fa-link',
                'title' => '',
                'category' => 'default',
                'class' => ''

        ), 
    $atts));
    $available=1;
    if($class!=''){
    	$class = ' '. trim($class);
    }
    if($lbimage!='' && $image==''){
    	$image = $lbimage;
    }
    elseif($lbimage=='' && $image!=''){
    	$lbimage = $image;
    }
    elseif($lbimage=='' && $image==''){
		$available=0;
    }
    if($available==1){
    	$output = '<div class="dc-pfitem'.$class.'" data-dc-pfsec="'.$category.'"><div class="dc-pf-img"><img src="'.$image.'" alt="" ><div class="dc-pf-info"><h3><a href="'.$link.'">'.$title.'</a></h3><div class="dc-pf-link"><ul><li><a href="#"><i class="fa '.$linkicon.'"></i></a></li><li><a href="'.$lbimage.'" class="dc-lbimg-lnk"><i class="fa '.$lbicon.'"></i></a></li></ul></div></div></div></div>';
    }
    else{
    	$output='';
    }
    return $output;
});

$this->add_shortcode('iconbox', function($atts, $content = null){
    extract($this->shortcode_atts(array(
                'class' => '',
                'iconpos' => '',
                'icon' => '',
                'title' =>''
        ), 
    $atts));
    
    if($iconpos == 'left'){$iconpos = 'icon-left-aligned';}else{$iconpos = 'icon-top-aligned';}
    if($class!=''){
        $class= ' ' .trim($class);
    }
    if($title!=''){
        $title ='<h3>'.$title.'</h3>';
    }
    $output = '<div class="'.$iconpos.$class.'"><div class="dc-icon-box"><div class="icon"><i class="'.$icon.'"></i></div><div class="icon-text">'.$title.$this->do_shortcode($content).'</div></div></div>';
    return $output;
});

$this->add_shortcode('counter', function($atts, $content = null){
    extract($this->shortcode_atts(array(
                'class' => '',
                'count' => '',
                'time' => '',
                'repeat' =>''
        ), 
    $atts));
    if(!ctype_digit($time)){$time=4000;}
    if(!ctype_digit($count)){$count=1000;}
    if($repeat=='yes'){
        $repeat= ' data-count-repeat="yes"';
    }
    if($class!=''){
        $class= ' ' .trim($class);
    }
    $output = '<div data-time="'.$time.'" data-count="'.$count.'" class="dc-count'.$class.'"'.$repeat.'>0</div>';
    return $output;
});

$this->add_shortcode('member', function($atts, $content = null){
    extract($this->shortcode_atts(array(
        'class' => '',
        'image' => '',
        'name' => '',
        'position' =>'',
        'fb' => '#',
        'ln' => '#',
        'tw' => '#',
        'gplus' => '#'
    ), 
    $atts));
    if($class!=''){
        $class= ' ' .trim($class);
    }
    $output = '<div class="dc-team-member'.$class.'"><div class="dc-team-thumb"><img src="'.$image.'" alt="'.$image.'" class="img-responsive"></div><div class="dc-team-overlay"><ul class="text-center"><li><a href="'.$fb.'"><i class="fa fa-facebook"></i></a></li><li><a href="'.$tw.'"><i class="fa fa-twitter"></i></a></li><li><a href="'.$ln.'"><i class="fa fa-linkedin"></i></a></li><li><a href="'.$gplus.'"><i class="fa fa-google-plus"></i></a></li></ul></div></div><div class="dc-team-description"><div class="dc-member-name">'.$name.'</div><div class="dc-member-post">'.$position.'</div><div class="dc-member-summary">'.$content.'</div></div>';
    return $output;
});

$this->add_shortcode('button', function($atts, $content = null){
    extract($this->shortcode_atts(array(
        'class' => '',
        'link' => '',
        'text' => ''
    ), 
    $atts));
    if($link==''){$link='#';}
    if($class!=''){
        $class= ' ' .trim($class);
    }
    $output = '<a href="'.$link.'" class="btn btn-primary btn-lg'.$class.'">'.$text.'</a>';
    return $output;
});

$this->add_shortcode('title', function($atts, $content = null){
    extract($this->shortcode_atts(array(
        'class' => ''
    ), 
    $atts));
    if($class!=''){
        $class= ' ' .trim($class);
    }
    $output = '<h2 class="titlehead-center'. $class .'">'. $content .'</h2>';
    return $output;
});

$this->add_shortcode('linespace', function($atts, $content = null){
    extract($this->shortcode_atts(array(
        'class' => '',
        'size' => ''
    ), 
    $atts));

    if($size == 'huge')
    {
        $size = 'dc-sep-huge';
    }
    elseif($size == 'big')
    {
        $size = 'dc-sep-big';
    }
    elseif ($size == 'mid')
    {
        $size = 'dc-sep-mid';
    }
    else{
        $size = 'dc-sep-sm';
    }

    if($class!=''){
        $class= ' ' .trim($class);
    }
    
    $output = '<div class="'.$size . $class .'"></div>';
    return $output;
});