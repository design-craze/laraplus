@include('template.'.$settinghelper['template'].'.includes.header')
@section('templatesection')
<!-- Start : 404 main content -->
<div class="row">
	<div class="col-md-12">
	    <div class="dc-404-ig">
	        <img src="{{ asset('assets/template/lara-seventeen/image/404.png') }}" alt="404 image" class="img-responsive" style="margin: 0 auto;">
	    </div>
	</div>
</div>
<div class="row text-center">
    <!-- Start : 404 main content --> 
    <div class="col-md-12">
        <h2> Oops sorry we can't find this page !</h2>
        <p>
           Either something went worng or the page doesn't exist anymore
        </p>
        <div>
            <a href="{{ route('home') }}" class="dc-btn">BACK TO HOME</a>
        </div>
    </div>
    <!-- End : 404 main content -->
</div>                    
<!-- End : 404 main content -->
@show
@include('template.'.$settinghelper['template'].'.includes.footer')