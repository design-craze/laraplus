<!DOCTYPE html>
<html lang="en">
    <head>
        <?php
            if(isset($settinghelper['google_vf_code']) && $settinghelper['google_vf_code'] !=''){
                echo '<meta name="google-site-verification" content="'.$settinghelper['google_vf_code'].'">';
            }
        ?>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <title><?php 
            if(isset($settinghelper['site_name']) && $settinghelper['site_name'] !=''){ 
            echo strip_tags($settinghelper['site_name']) . ' | '; 
            } else{ 
                echo 'LaraPlus | '; 
            }
            if(isset($data->name) && $data->name !=''){
                echo strip_tags($data->name);
            }
            elseif(isset($data->metatitle) && $data->metatitle !=''){
                echo strip_tags($data->metatitle);
            }
            elseif(isset($settinghelper['meta_title']) && $settinghelper['meta_title'] !=''){
                echo strip_tags($settinghelper['meta_title']);
            }
            ?></title>
        <meta name="title" content="<?php 
            if(isset($data->metatitle) && $data->metatitle !=''){
                echo strip_tags($data->metatitle);
            }
            elseif(isset($data->name) && $data->name !=''){
                echo strip_tags($data->name);
            }
            elseif(isset($settinghelper['meta_title']) && $settinghelper['meta_title'] !=''){
                echo strip_tags($settinghelper['meta_title']);
            }
            ?>">
        <meta name="keywords" content="<?php 
            if(isset($data->metatag) && $data->metatag !=''){
                echo strip_tags($data->metatag);
            }
            elseif(isset($settinghelper['meta_tag']) && $settinghelper['meta_tag'] !=''){
                echo strip_tags($settinghelper['meta_tag']);
            }
            ?>">
        <meta name="description" content="<?php 
            if(isset($data->metadesc) && $data->metadesc !=''){
                echo substr(strip_tags($data->metadesc),0,155);
            }
            elseif(isset($data->description)){
                echo substr(strip_tags($data->description),0,155);
            }
            elseif (isset($settinghelper['meta_desc']) && $settinghelper['meta_desc'] !='') {
                echo substr(strip_tags($settinghelper['meta_desc']),0,155);
            }
            ?>">
        <!-- Bootstrap -->

        <!-- start: favicon -->
        <link rel="shortcut icon" type="image/x-icon" 
        href="<?php if (isset($settinghelper['favicon']) && $settinghelper['favicon'] !=''){ 
            echo asset(path_favicon().$settinghelper['favicon']);
        } else{
            echo asset(path_favicon().'favicon.png'); 
        }
        ?>">

        <!-- end: favicon -->
        {{ Html::style('assets/common/css/bootstrap.min.css') }}
        <!-- dynamic bootstrap -->
        @include('common.lpdynamic')
        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
        
        <!-- Font Awesome -->
        {{ Html::style('assets/common/css/font-awesome.min.css') }}
        <!-- Animate.css -->
        {{ Html::style('assets/common/css/animate.min.css') }}
        <!-- Portfolio.css -->
        {{ Html::style('assets/common/css/dc-portfolio.css') }}
        <!-- Navbar -->
        {{ Html::style('assets/common/js/dc-nav/dc-nav.css') }}
        <!-- Common Custom CSS -->
        {{ Html::style('assets/common/css/common.css') }}
        <!-- Template CSS -->
        {{ Html::style('assets/template/'.$settinghelper['template'].'/flaticon/flaticon.css') }}
        {{ Html::style('assets/template/'.$settinghelper['template'].'/style.css') }}
        @if (isset($settinghelper['custom_css']) && $settinghelper['custom_css'] != '')
            <style>
                {!!$settinghelper['custom_css']!!}
            </style>
        @endif
        
        <!-- custom dynamic css -->
        @include('common.lpcdynamic')

        <!-- per page css -->
        @if (isset($data->css) && $data->css !='')
            <style>
                {!!$data->css!!}
            </style>
        @endif
        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        {{ Html::script('assets/common/js/jquery-1.9.1.js') }}
        {{ Html::script('assets/common/js/jquery-ui.js') }}
         @yield('headcode')
    </head>
    <body>
        <?php
            $container='container';
            if(isset($data->layout) && $data->layout == '0'){$container = 'container-fluid';}
            elseif(isset($data->layout) && $data->layout == '-1' && $settinghelper['page_layout']=='0'){$container = 'container-fluid';} 
            elseif(!isset($data->user_id) && !isset($data->layout) && $settinghelper['page_layout']=='0'){$container = 'container-fluid';}
            elseif(isset($data->user_id) && $settinghelper['blog_layout']=='0'){$container = 'container-fluid';}
            
            $outercontainer =' dc-body-box-layout';
            if(isset($data->bodystyle) && $data->bodystyle == '1'){$outercontainer = '';}
            elseif(isset($data->bodystyle) && $data->bodystyle == '-1' && $settinghelper['body_layout']=='1'){$outercontainer = '';}
            elseif(!isset($data->bodystyle) && $settinghelper['body_layout']=='1'){$outercontainer = '';}


            $myheader = 1;
            if(isset($data->header) && $data->header == '0' ){
                $myheader = 0;
            }                
            else if(isset($data->header) && $data->header =='-1' && $settinghelper['page_header'] == '0'){
                $myheader = 0;
            }
            else if(!isset($data->header) && $settinghelper['page_header'] == '0'){
                $myheader = 0;
            }

            $headercontainer =' dc-body-box-layout';
            if(isset($data->hdrlayout) && $data->hdrlayout == '1'){$headercontainer = '';}
            elseif(isset($data->hdrlayout) && $data->hdrlayout == '-1' && $settinghelper['header_layout']=='1'){$headercontainer = '';}
            elseif(!isset($data->hdrlayout) && $settinghelper['header_layout']=='1'){$headercontainer = '';}


            $mytitlebar = 1;
            if(isset($data->title) && $data->title == '0' ){
                $mytitlebar = 0;
            }                
            else if(isset($data->title) && $data->title =='-0' && $settinghelper['page_title'] == '0'){
                $mytitlebar = 0;
            }
            else if(!isset($data->title) && $settinghelper['page_title'] == '0'){
                $mytitlebar = 0;
            }

            $titlecontainer =' dc-body-box-layout';
            if(isset($data->titlelayout) && $data->titlelayout == '1'){$titlecontainer = '';}
            elseif(isset($data->titlelayout) && $data->titlelayout == '-1' && $settinghelper['title_layout']=='1'){$titlecontainer = '';}
            elseif(!isset($data->titlelayout) && $settinghelper['title_layout']=='1'){$titlecontainer = '';}
        ?>


        @if($myheader == 1)
            <header class="header">
                <div class="hdr-top{{$headercontainer}}">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-5 col-sm-6">
                                <div class="hdr-top-left">
                                    {!! social_media($settinghelper, '', 'list-unstyled list-inline hdr-social-link') !!}
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-6">
                                <div class="hdr-top-left">                                    
                                    <ul class="list-unstyled list-inline hdr-contact-info">
                                    @if($settinghelper['primary_phone']!='')
                                        <li><span class="icon-box"><i class="fa fa-phone-square"></i></span> <a href="tel:{{$settinghelper['primary_phone']}}">{{$settinghelper['primary_phone']}}</a></li>
                                    @endif
                                    @if($settinghelper['primary_email']!='')
                                        <li><span class="icon-box"><i class="fa fa-envelope"></i></span> <a href="mailto:{{$settinghelper['primary_email']}}">{{$settinghelper['primary_email']}}</a></li>
                                    @endif                                    
                                    </ul>                                        
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-12">
                                <div class="hdr-top-right clearfix">
                                    <!-- start: user credential box -->
                                    <ul class="list-unstyled list-inline pull-right credential-box">
                                            @if(Auth::user())
                                                <li>
                                                    <div class="dropdown">
                                                        <a id="user-link" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="user-link">
                                                            <i class="fa fa-user"></i>
                                                            @if(Auth::user()->fname != '' && Auth::user()->lname != '')
                                                                {{Auth::user()->fname}} {{Auth::user()->lname}}
                                                            @else
                                                                {{Auth::user()->username}}
                                                            @endif
                                                            <span class="caret"></span>
                                                        </a>
                                                        <ul class="dropdown-menu" aria-labelledby="user-link">
                                                            <li><a href="{{ route('dashboard') }}">Dashboard</a></li>
                                                            @if(Auth::user()->role > 6)
                                                            <li><a href="{{ route('myblogs') }}">My Blogs</a></li>
                                                            @endif
                                                            <li><a href="{{ route('usersetting') }}">Setting</a></li>
                                                            <li role="separator" class="divider"></li>
                                                            <li><a href="{{ route('logout') }}">Logout</a></li>
                                                        </ul>
                                                    </div>
                                                </li>
                                            @else
                                                @if($settinghelper['login_page']!='')
                                                    <li><a href="{{route('page',['slug'=>getpage($settinghelper['login_page'])])}}">Login</a></li>
                                                @else
                                                    <li class="user-login"><a href="{{route('adminlogin')}}">Login</a></li>
                                                @endif  
                                                @if($settinghelper['signup_page']!='')
                                                    <li><a href="{{route('page',['slug'=>getpage($settinghelper['signup_page'])])}}">Sign Up</a></li>
                                                @endif
                                            @endif
                                        </ul>
                                    <!-- end: user credential box -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- start: header bottom-->
                <div id="sticky" class="hdr-bottom{{$headercontainer}}">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12 clearfix">
                                <a href="{{ route('home') }}" class="logo">
                                    @if(isset($settinghelper['logo_type']) && $settinghelper['logo_type'] == '2')
                                        @if(isset($settinghelper['logo_img']) && $settinghelper['logo_img'] != null)
                                            <img src="{{ asset(path_logo().$settinghelper['logo_img']) }}" alt="LOGO IMG">
                                        @else
                                            <img src="{{ asset('assets/template/lara-seventeen/image/logo.png') }}" alt="LOGO IMG">
                                        @endif
                                    @elseif(isset($settinghelper['logo_type']) && $settinghelper['logo_type'] == '1')
                                        @if(isset($settinghelper['site_name']) && $settinghelper['site_name'] != null)
                                            <h4 class="dc-text-default">
                                                {{ $settinghelper['site_name'] }}
                                            </h4>
                                        @else
                                            <h4 class="dc-text-default">LaraPress 17</h4>
                                        @endif
                                    @endif
                                </a>

                                    <div class="dc-nav" data-mobilemenu="{{$settinghelper['mobile_breakpoint']}}" data-sticky="{{$settinghelper['sticky_header']}}" data-stickytop="{{$settinghelper['sticky_top']}}" data-menutype="{{$settinghelper['menu_type']}}" data-stickyid="sticky" data-menutext="{{$settinghelper['classic_menutext']}}">
                                        <div class="menu-toggle"></div>
                                        <nav>
                                            @if(isset($data->menu))
                                                {!!navview($data->menu, 'mainmenu-1')!!}
                                            @else
                                                {!!navview('', 'mainmenu-1')!!}
                                            @endif
                                        </nav>
                                    </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end: header bottom-->
            </header>
        @endif
        <!--end: header-->
        @if($mytitlebar==1)
        <!-- start: breadcrumb -->
        <div class="dc-page-title{{$titlecontainer}}">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <h5 class="page-name">
                            @if(isset($webtitle) && !empty($webtitle))
                                {{$webtitle}}
                            @elseif(isset($data->name) && $data->name != '')
                                {{ $data->name }}
                            @endif
                        </h5>
                    </div>
                    <div class="col-md-6">
                        @if(isset($data->breadcrumbs) && $data->breadcrumbs==2 && isset($breadcrumb))
                            {!!$breadcrumb!!}
                        @elseif(isset($data->breadcrumbs) && $data->breadcrumbs==-1 && $settinghelper['breadcrumbs']==2 && isset($breadcrumb))
                            {!!$breadcrumb!!}
                        @elseif(!isset($data->breadcrumbs) && $settinghelper['breadcrumbs']==2 && isset($breadcrumb))
                            {!!$breadcrumb!!}
                        @endif
                    </div>
                </div>
            </div>
        </div>
        <!-- end: breadcrumb -->
        @endif

        <!--start: main-->
        @yield('pagetop')
        <div role="main" class="main{{$outercontainer}}" id="main">
            <div class="{{$container}}">
                @if(Session::has('success'))
                <div class="row">
                    <div class="col-md-12" style="padding-top:30px; padding-bottom:30px;">
                        <div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <h4><i class="icon fa fa-check"></i> SUCCESS!</h4>
                            {{Session::get('success')}}
                        </div>
                    </div>
                </div>
                @elseif(Session::has('dissmiss'))
                <div class="row">
                    <div class="col-md-12" style="padding-top:30px; padding-bottom:30px;">
                        <div class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <h4><i class="icon fa fa-ban"></i> FAILED!</h4>
                            {{Session::get('dissmiss')}}
                        </div>
                    </div>
                </div>
                @elseif(count($errors) > 0)
                <div class="row">
                    <div class="col-md-12" style="padding-top:30px; padding-bottom:30px;">
                        <div class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <h4><i class="icon fa fa-ban"></i> Validation FAILED!</h4>
                            <ul class="list-unstyled" style="padding-left:31px;">
                                @foreach($errors->all() as $error)
                                    <li>
                                        {{ $error }}
                                    </li>
                                @endforeach
                            </ul>
                        </div>
                    </div>
                </div>
                @endif

                @if(Auth::user() && Auth::user()->verified != 2)
                    <div class="row">
                        <div class="col-md-12" style="padding-top:30px; padding-bottom:30px;">
                            <div class="alert alert-info alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                Your Email address is unverified. You must have a mail including verification link. If you didin't get any mail, Please <a href="{{ route('resendverifymail') }}" class="text-danger">click here</a> to get a verifiction link to your email.
                            </div>
                        </div>
                    </div>
                @endif

                @if(Auth::user() && Auth::user()->active == 3 && Auth::user()->role != 12)
                <div class="row">
                    <div class="col-md-12" style="padding-top:30px; padding-bottom:30px;">
                        <div class="alert alert-info alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            Your Account is inactive. You can not update your profile at this stage. Please contact to our Help Center to make your account active.
                        </div>
                    </div>
                </div>
                @endif

                <div class="row">
                @if(isset($data->leftside) && !isset($data->user_id) && $data->leftside != 'default' && $data->leftside != 'none')
                    <div class="col-md-3 col-sm-4">
                        <div class="side-widget left-sidebar">
                            {!!getwidget($data->leftside)!!}
                        </div>
                    </div>
                @elseif(isset($data->leftside) && !isset($data->user_id) && $data->leftside == 'default' && $settinghelper['page_leftsidebar']!='' && $settinghelper['page_leftsidebar']!='none')
                    <div class="col-md-3 col-sm-4">
                        <div class="side-widget left-sidebar">
                            {!!getwidget($settinghelper['page_leftsidebar'])!!}
                        </div>
                    </div>
                @elseif(!isset($data->leftside) && !isset($data->user_id) && $settinghelper['page_leftsidebar']!='' && $settinghelper['page_leftsidebar']!='none')
                    <div class="col-md-3 col-sm-4">
                        <div class="side-widget left-sidebar">
                            {!!getwidget($settinghelper['page_leftsidebar'])!!}
                        </div>
                    </div>
                @elseif(!isset($data->leftside) && isset($data->user_id) && $settinghelper['blog_leftsidebar']!='' && $settinghelper['blog_leftsidebar']!='none')
                    <div class="col-md-3 col-sm-4">                        
                        <div class="side-widget left-sidebar">
                            {!!getwidget($settinghelper['blog_leftsidebar'])!!}
                        </div>
                    </div>
                @endif

                <?php
                    $pageleft = 0;
                    $pageright = 0;
                    if(isset($data->leftside) && !isset($data->user_id) && $data->leftside != 'default' && $data->leftside != 'none'){
                        $pageleft = 1;
                    }
                    else if(isset($data->leftside) && !isset($data->user_id) && $data->leftside == 'default' && $settinghelper['page_leftsidebar']!='' && $settinghelper['page_leftsidebar']!='none'){
                        $pageleft = 1;
                    }
                    else if(!isset($data->leftside) && isset($data->user_id) && $settinghelper['blog_leftsidebar']!='' && $settinghelper['blog_leftsidebar']!='none'){
                        $pageleft = 1;
                    }
                    else if(!isset($data->leftside) && !isset($data->user_id) && $settinghelper['page_leftsidebar']!='' && $settinghelper['page_leftsidebar']!='none'){
                        $pageleft = 1;
                    }
                    
                    if(isset($data->rightside) && !isset($data->user_id) && $data->rightside != 'default' && $data->rightside != 'none'){
                        $pageright = 1;
                    }
                    else if(isset($data->rightside) && !isset($data->user_id) && $data->rightside == 'default' && $settinghelper['page_rightsidebar']!='' && $settinghelper['page_rightsidebar']!='none'){
                        $pageright = 1;
                    }
                    else if(!isset($data->rightside) && isset($data->user_id) && $settinghelper['blog_rightsidebar']!='' && $settinghelper['blog_rightsidebar']!='none'){
                        $pageright = 1;
                    }
                    else if(!isset($data->rightside) && !isset($data->user_id) && $settinghelper['page_rightsidebar']!='' && $settinghelper['page_rightsidebar']!='none'){
                        $pageright = 1;
                    }
                ?>

                @if($pageright==0 && $pageleft==0)
                    <div class="col-md-12">
                @elseif($pageright==1 && $pageleft==1)
                    <div class="col-md-6 col-sm-4">
                @elseif($pageright==0 || $pageleft==0)
                    <div class="col-md-9 col-sm-8">
                @endif
                    <div class="body-content">
                        @yield('body')