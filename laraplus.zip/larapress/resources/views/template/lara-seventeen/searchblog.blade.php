@include('template.'.$settinghelper['template'].'.includes.header')
@section('templatesection')
	@if($dataerror==0)
    @if(Auth::user() && $logged_role > 6)
	<div class="row">
        <div class="col-md-12">
        	<ul class="list-unstyled list-inline">
        		<li><a href="{{ route('blogs') }}" class="dc-btn">View All Posts</a></li>
        		<li><a href="{{ route('createblog') }}" class="dc-btn">Create Post</a></li>
        		<li><a href="{{ route('myblogs') }}" class="dc-btn">My Posts</a></li>
        	</ul>
        </div>
    </div>
	@endif
   	<div class="row">
        <div class="col-md-12">
        	@if(isset($myposts) && !empty($myposts))
<?php
    $pageleft = 0;
    $pageright = 0;
    if(isset($data->leftside) && !isset($data->user_id) && $data->leftside != 'default' && $data->leftside != 'none'){
        $pageleft = 1;
    }
    else if(isset($data->leftside) && !isset($data->user_id) && $data->leftside == 'default' && $settinghelper['page_leftsidebar']!='' && $settinghelper['page_leftsidebar']!='none'){
        $pageleft = 1;
    }
    else if(!isset($data->leftside) && isset($data->user_id) && $settinghelper['blog_leftsidebar']!='' && $settinghelper['blog_leftsidebar']!='none'){
        $pageleft = 1;
    }
    else if(!isset($data->leftside) && !isset($data->user_id) && $settinghelper['page_leftsidebar']!='' && $settinghelper['page_leftsidebar']!='none'){
        $pageleft = 1;
    }
    
    if(isset($data->rightside) && !isset($data->user_id) && $data->rightside != 'default' && $data->rightside != 'none'){
        $pageright = 1;
    }
    else if(isset($data->rightside) && !isset($data->user_id) && $data->rightside == 'default' && $settinghelper['page_rightsidebar']!='' && $settinghelper['page_rightsidebar']!='none'){
        $pageright = 1;
    }
    else if(!isset($data->rightside) && isset($data->user_id) && $settinghelper['blog_rightsidebar']!='' && $settinghelper['blog_rightsidebar']!='none'){
        $pageright = 1;
    }
    else if(!isset($data->rightside) && !isset($data->user_id) && $settinghelper['page_rightsidebar']!='' && $settinghelper['page_rightsidebar']!='none'){
        $pageright = 1;
    }
    $sidebar = $pageleft + $pageright;
    if($sidebar==1){$class= 'col-md-4';}
    elseif($sidebar==2){$class= 'col-md-6';}
    else{$class= 'col-md-3 col-sm-6';}
?>
				<div class="row dc-clear dc-blog" style="margin-top: 40px">
	        	@foreach($myposts as $mypost)
					@if((isset($mypost) && !empty($mypost) && $mypost->access_level == 0) || 
		        		(Auth::user() && $mypost->access_level == Auth::user()->role) || (isset($mypost) && !empty($mypost) && Auth::user() && $mypost->user_id == Auth::user()->id) || (isset($mypost) && !empty($mypost) && Auth::user() && Auth::user()->role == 12))
		                

		                <div class="{{$class}} dc-pfitem" data-dc-pfsec="Web Development, Logo"> 
			                <div class="dc-pf-img">
			                	@if(isset($mypost->thumb) && !empty($mypost->thumb))
			                		<img src="{{$mypost->thumb}}" alt="{{$mypost->thumb}}" class="img-responsive">
			                	@else
			                		<img src="{{asset('assets/common/images/no-thumb-big.jpg')}}" alt="" class="img-responsive">
			                	@endif

			                    <!-- <div class="dc-pf-info">
			                        <div class="dc-pf-link">
			                            <ul class="clearfix">
			                                <li><a href="{{ route('blog',['slug'=>$mypost->slug]) }}"><i class="fa fa-link"></i></a></li>
			                                <li><a href="images/portfolio/full/04.jpg" class="dc-lbimg-lnk"><i class="fa fa-search"></i></a></li>
			                            </ul>
			                        </div>
			                    </div> -->
			                </div>
			                <!--start: blog info-->
			                <div class="dc-pf-elem dc-grid-blog">
			                    <div class="pf-elem-cnt">
			                        <h3>
			                        	@if(isset($mypost->name) && !empty($mypost->name))
											<a href="{{ route('blog',['slug'=>$mypost->slug]) }}">{{$mypost->name}}</a>
										@endif
			                        </h3>
			                        <p>
			                            @if(isset($mypost->description) && !empty($mypost->description))
											{!!substr(strip_tags($mypost->description), 0, 150)!!}
										@endif
			                        </p>
			                        <a href="{{ route('blog',['slug'=>$mypost->slug]) }}" class="read-more">Learn More <i class="fa fa-angle-right"></i></a>
			                    </div>
			                    <div class="pf-elem-ftr">
			                        <ul class="clearfix">
			                            <li><span class="dc-fa-style"><i class="fa fa-calendar-o"></i></span> {{getDateFormat($mypost->updated_at)}}</li>
			                            <li><span class="dc-fa-style"><i class="fa fa-user"></i></span> <a href="{{ route('profile',['logcode'=>$mypost->user->logcode]) }}"> {{$mypost->user->fname}} {{$mypost->user->lname}}</a></li>
			                            <li><span class="dc-fa-style"><i class="fa fa-comment-o"></i></span> {{count($mypost->comments)}}</li>
			                            @if((Auth::user() && Auth::user()->id == $mypost->user_id && Auth::user()->role > 6) || (Auth::user() && Auth::user()->role > 7 && Auth::user()->role > $mypost->user->role))
			                            <li>
			        						<span class="dc-fa-style"><i class="fa fa-edit"></i></span> <a href="{{ route('editpost',['id'=>$mypost->id]) }}">
												Edit Post
											</a>
			                            </li>
										@endif
			                        </ul>
			                    </div>
			                </div>
			            </div>

		                
					@endif
	            @endforeach
		    	</div>
		    	<div class="row"> 
		    		<div class="col-md-12">
			            <?php
			            	$pagination = array(
			            		'route'=>'searchblog',
			            		'first'=>'<i class="fa fa-angle-double-left"></i>',
			            		'last'=> '<i class="fa fa-angle-double-right"></i>',
			            		'prev'=>'<i class="fa fa-angle-left"></i>',
			            		'next'=>'<i class="fa fa-angle-right"></i>'
			            	);
			            	pagination($myposts, $getelements, $pagination);
			            ?>
					</div>
				</div>
            @endif
		</div>
    </div>    
    @else
	<div class="col-md-12">
		<div class="panel panel-default custom-panel">
            <div class="panel-body">
				<h4 class="text-center">
					No blog found to view.
				</h4>
			</div>
		</div>
	</div>
	@endif

@show
@include('template.'.$settinghelper['template'].'.includes.footer')