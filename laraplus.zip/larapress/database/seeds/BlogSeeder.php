<?php

use Illuminate\Database\Seeder;
use App\Models\Blog;

class BlogSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $blog = new Blog();
        $blog->slug = "first-blog";
        $blog->name = "First Blog";
        $blog->description = "This is description of First Blog";
        $blog->user_id = 1;
        $blog->save();

    }
}
