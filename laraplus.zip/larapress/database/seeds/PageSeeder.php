<?php

use Illuminate\Database\Seeder;
Use App\Models\Page;

class PageSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $page = new Page();
        $page->slug = 'home';
        $page->name = 'Home Page';
        $page->description = 'This is descripton of Home Page';
        $page->metadesc = 'This is meta description';
        $page->metatag = 'home,home page';
        $page->home = 1;
        $page->save();
    }
}
