<?php

use Illuminate\Database\Seeder;
Use App\Models\Category;

class CategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $Category = new Category();
        $Category->ctgslug = 'Default Category';
        $Category->name = 'Default Category';
        $Category->description = 'This is descripton of Default Category';
        $Category->save();
    }
}
