<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePagesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('pages', function (Blueprint $table) {
            $table->increments('id');            
            $table->string('name', 255);
            $table->string('slug');
            $table->text('description')->nullable();
            $table->string('metatitle', 155)->nullable();
            $table->string('metadesc', 155)->nullable();
            $table->text('metatag')->nullable();
            $table->boolean('home')->default(0);
            $table->string('template')->nullable();
            $table->integer('parent')->default(0);
            $table->string('lang', 20)->default('en');
            $table->text('menu')->nullable();
            $table->text('css')->nullable();
            $table->text('js')->nullable();
            $table->tinyInteger('access_level')->default(0);
            $table->boolean('trashed')->default(0);
            $table->tinyInteger('header')->default('-1'); 
            $table->tinyInteger('hdrlayout')->default('-1');  
            $table->tinyInteger('title')->default('-1');  
            $table->tinyInteger('titlelayout')->default('-1');
            $table->tinyInteger('breadcrumbs')->default('-1');
            $table->tinyInteger('layout')->default('-1'); 
            $table->tinyInteger('bodystyle')->default('-1');  
            $table->string('leftside', 30)->default('default'); 
            $table->string('rightside', 30)->default('default');
            $table->tinyInteger('ftrlayout')->default('-1');  
            $table->tinyInteger('ftrwid')->default('-1');
            $table->tinyInteger('btmftr')->default('-1');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('pages');
    }
}
