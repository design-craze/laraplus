$(document).ready(function(){

	//Load default actions first
	firstload();
	myAutoOrder();

	//Add Page Action
	$('#addpage').on('click', function(){
		$('#allpages').find('.pagecheckbox').each(function(){
			var $this = $(this);
			var a;
			if($this.attr('data-name')==''){
				a='Unnamed';
			}
			else{
				a=$this.attr('data-name');
			}
			if($this.prop('checked')==true){
				$('.mymenu').append(
					'<li data-serial="' + $this.attr('data-serial') + '" ' +
						'data-megamenu="' + $this.attr('data-megamenu') + '" ' +
						'data-newtab="' + $this.attr('data-newtab') + '" ' +
						'data-class="' + $this.attr('data-class') + '" ' +
						'data-link="' + $this.attr('data-link') + '" ' +
						'data-blogid="' + $this.attr('data-blogid') + '" ' +
						'data-pageid="' + $this.attr('data-pageid') + '" ' +
						'data-name="' + a + '" ' +
						'data-menuid="' + $this.attr('data-menuid') + '" ' +
						'data-parentid="' + $this.attr('data-parentid') + '" ' +
						'data-id="' + $this.attr('data-id') + '"' +
					'>' +
						'<div class="innermenu">' +
							'<div class="innermenuhead">' +
								'<div class="title">' + a + '</div>' +
								'<div class="type"><span class="arrow-icon">Page <i class="fa fa-caret-right"></i></span></div>' +
							'</div>' +
							'<div class="innermenubody">' +
								'<p><label>Navigation Label<br></label><input type="text" value="' + $this.attr('data-name') + '" class="name"></p>' +
								'<p><label>Extra Class<br></label><input type="text" value="" class="class"></p>' +
								'<p><label for=""></label><input type="checkbox" class="newwindow"><em>Open link in a new window/tab</em></p>' +
								'<p class="mymgmenu"><label for=""></label><input type="checkbox" class="megamenu"><em>Use As Mega Menu</em></p>' +
								'<hr class="myhrborder">'+
								'<button class="deletebutton">Remove</button>'+
							'</div>' +
						'</div>' +
					'</li>'
				);
				$this.removeAttr('checked');
			}
		})
		myAutoOrder();
	})

	//Add Blog Action
	$('#addblog').on('click', function(){
		$('#allblogs').find('.blogcheckbox').each(function(){
			var $this = $(this);
			if($this.attr('data-name')==''){
				a='Unnamed';
			}
			else{
				a=$this.attr('data-name');
			}
			if($this.prop('checked')==true){
				$('.mymenu').append(
					'<li data-serial="' + $this.attr('data-serial') + '" ' +
						'data-megamenu="' + $this.attr('data-megamenu') + '" ' +
						'data-newtab="' + $this.attr('data-newtab') + '" ' +
						'data-class="' + $this.attr('data-class') + '" ' +
						'data-link="' + $this.attr('data-link') + '" ' +
						'data-blogid="' + $this.attr('data-blogid') + '" ' +
						'data-pageid="' + $this.attr('data-pageid') + '" ' +
						'data-name="' + a + '" ' +
						'data-menuid="' + $this.attr('data-menuid') + '" ' +
						'data-parentid="' + $this.attr('data-parentid') + '" ' +
						'data-id="' + $this.attr('data-id') + '"' +
					'>' +
						'<div class="innermenu">' +
							'<div class="innermenuhead">' +
								'<div class="title">' + a + '</div>' +
								'<div class="type"><span class="arrow-icon">Blog <i class="fa fa-caret-right"></i></span></div>' +
							'</div>' +
							'<div class="innermenubody">' +
								'<p><label>Navigation Label<br></label><input type="text" value="' + $this.attr('data-name') + '" class="name"></p>' +
								'<p><label>Extra Class<br></label><input type="text" value="" class="class"></p>' +
								'<p><label for=""></label><input type="checkbox" class="newwindow"><em>Open link in a new window/tab</em></p>' +
								'<p class="mymgmenu"><label for=""></label><input type="checkbox" class="megamenu"><em>Use As Mega Menu</em></p>' +
								'<hr class="myhrborder">'+
								'<button class="deletebutton">Remove</button>'+
							'</div>' +
						'</div>' +
					'</li>'
				);
				$this.removeAttr('checked');
			}
		})
		myAutoOrder();
	})

	//Add Custom Link Action
	$('#addlink').on('click', function(){
		var a;
		var b;
		if($('#alllinks').val()!=''){
			a =$('#alllinks').val()
		}
		else{
			a = $('#alllinks').attr('data-link')
		}
		if($('#alllinkname').val()!=''){
			b =$('#alllinkname').val()
		}
		else{
			b = $('#alllinkname').attr('data-name')
		}
		var $this = $('#alllinks');
			$('.mymenu').append(
				'<li data-serial="' + $this.attr('data-serial') + '" ' +
					'data-megamenu="' + $this.attr('data-megamenu') + '" ' +
					'data-newtab="' + $this.attr('data-newtab') + '" ' +
					'data-class="' + $this.attr('data-class') + '" ' +
					'data-link="' + a + '" ' +
					'data-blogid="' + $this.attr('data-blogid') + '" ' +
					'data-pageid="' + $this.attr('data-pageid') + '" ' +
					'data-name="' + b + '" ' +
					'data-menuid="' + $this.attr('data-menuid') + '" ' +
					'data-parentid="' + $this.attr('data-parentid') + '" ' +
					'data-id="' + $this.attr('data-id') + '"' +
				'>' +
					'<div class="innermenu">' +
						'<div class="innermenuhead">' +
							'<div class="title">'+ b +'</div>' +
							'<div class="type"><span class="arrow-icon">Custom <i class="fa fa-caret-right"></i></span></div>' +
						'</div>' +
						'<div class="innermenubody">' +
							'<p><label>Navigation Label<br></label><input type="text" value="'+ b +'" class="name"></p>' +
							'<p><label>Link<br></label><input type="text" value="'+ a +'" class="link"></p>' +
							'<p><label>Extra Class<br></label><input type="text" value="" class="class"></p>' +
							'<p><label for=""></label><input type="checkbox" class="newwindow"><em>Open link in a new window/tab</em></p>' +
							'<p class="mymgmenu"><label for=""></label><input type="checkbox" class="megamenu"><em>Use As Mega Menu</em></p>' +
							'<hr class="myhrborder">'+
							'<button class="deletebutton">Remove</button>'+
						'</div>' +
					'</div>' +
				'</li>'
			);
		myAutoOrder();
		$('#alllinks').val('')
		$('#alllinkname').val('')
	})

	//Function for input fields Action
    function myfield(a, b){
		var mymenu = $('.mymenu').find('li');
    	var mymenulength = mymenu.length;
    	var mysign = '';
    	var myfield='';
		for(var i=0; i<mymenulength; i++){
    			myfield = myfield + mysign + trimChar($(mymenu[i]).attr(a), '>');
    			mysign = '>';
		}
		$(b).val(myfield)
    }

	//Delete Action
	$(document).on('click', '.deletebutton', function(e) {
		e.preventDefault();
		var abc= $(this).parent().parent().parent().children('ol').children('li');
		console.log(abc.length);
		$a = $('#deletedid').val();
		$b = $(this).parent().parent().parent().attr('data-id');
		mysign = '>';
		if($b != ''){
			if($a == ''){
				$('#deletedid').val($b);
			}
			else{
				$('#deletedid').val($a + mysign + $b);
			}
		}
		if(abc.length!=0){
			$(this).parent().parent().parent().after(abc);
		}
		$(this).parent().parent().parent().remove();
		myAutoOrder();
	}) ;

	//Toggle Action
	$(document).on('click', '.innermenuhead .arrow-icon', function() {
			$(this).parent().parent().next().slideToggle(300);
			if($(this).find('i').hasClass('fa-caret-right')){
				$(this).find('i').removeClass('fa-caret-right').addClass('fa-caret-down');
			}
			else{
				$(this).find('i').removeClass('fa-caret-down').addClass('fa-caret-right');
			}
	}) ;

	//Megamenu action
	$(document).on('click', '.megamenu', function() {
		if($(this).prop('checked')==true){
			$(this).parent().parent().parent().parent().attr('data-megamenu', '1');
		}
		else if($(this).prop('checked')==false){
			$(this).parent().parent().parent().parent().attr('data-megamenu', '0');
		}
		myfield('data-megamenu', '#megamenu');
	})

	//NewTab action
	$(document).on('click', '.newwindow', function() {
		if($(this).prop('checked')==true){
			$(this).parent().parent().parent().parent().attr('data-newtab', '1');
		}
		else if($(this).prop('checked')==false){
			$(this).parent().parent().parent().parent().attr('data-newtab', '0');
		}
		myfield('data-newtab', '#newtab');
	})

	//Name field action
	$(document).on('keyup', '.name', function() {
		$(this).parent().parent().parent().parent().attr('data-name', $(this).val());
		// $(this).parent().parent().parent().parent().find('.title').text($(this).val());
		myfield('data-name', '#name');
	})

	//Link field action
	$(document).on('keyup', '.link', function() {
		$(this).parent().parent().parent().parent().attr('data-link', $(this).val());
		myfield('data-link', '#link');
	})

	//Link field action
	$(document).on('keyup', '.class', function() {
		$(this).parent().parent().parent().parent().attr('data-class', $(this).val());
		myfield('data-class', '#class');
	})

	//Sortable Nesting
    $('.mymenu').nestedSortable({
        handle: '.title',
        items: 'li',
        toleranceElement: '> div',
        // revert: function(){
        // 	myAutoOrder()
        // 	// return true;
        // },
        relocate: function(){
        	myAutoOrder()
        	// return true;
        }
    });

    //Auto arrange Hidden field
    function myAutoOrder(){
    	var mymenu = $('.mymenu').find('li');
        	var mymenulength = mymenu.length;
        	var mysign = '';
        	var mymainid='';
        	var myserial='';
        	var myparentid='';
        	var mymenuid='';
        	var myname='';
        	var mypageid='';
        	var myblogid='';
        	var mylink='';
        	var myclass='';
        	var mynewtab='';
        	var mymegamenu='';
    		for(var i=0; i<mymenulength; i++){
    				var checkid = $(mymenu[i]).attr('data-id');
    				if(checkid){
        				mymainid = mymainid + mysign + $(mymenu[i]).attr('data-id');
    				}
    				else{
        				mymainid = mymainid + mysign + '';
    				}

        			$(mymenu[i]).attr('data-serial', (i+1));
        			var myserial= myserial + mysign + (i+1);

        			if($(mymenu[i]).parent('ol').hasClass('mymenu')){
        				myparentid = myparentid + mysign + 0
        			}
        			else{
        				myparentid = myparentid + mysign + $(mymenu[i]).parent('ol').parent('li').attr('data-serial');
        				$(mymenu[i]).children('.innermenu').find('.megamenu').removeAttr('checked');
        				$(mymenu[i]).attr('data-megamenu', '0');
        			}

        			mymenuid = mymenuid + mysign + $(mymenu[i]).attr('data-menuid');
        			myname = myname + mysign + trimChar($(mymenu[i]).attr('data-name'), '>');
        			mypageid = mypageid + mysign + $(mymenu[i]).attr('data-pageid');
        			myblogid = myblogid + mysign + $(mymenu[i]).attr('data-blogid');
        			mylink = mylink + mysign + trimChar($(mymenu[i]).attr('data-link'), '>');
        			myclass = myclass + mysign + trimChar($(mymenu[i]).attr('data-class'), '>');
        			mynewtab = mynewtab + mysign + $(mymenu[i]).attr('data-newtab');
        			mymegamenu = mymegamenu + mysign + $(mymenu[i]).attr('data-megamenu');
        			mysign = '>';
    		}
			$('#mainid').val(mymainid)
			$('#myserial').val(myserial)
			$('#parentid').val(myparentid)
			$('#name').val(myname)
			$('#menuid').val(mymenuid)
			$('#pageid').val(mypageid)
			$('#blogid').val(myblogid)
			$('#link').val(mylink)
			$('#class').val(myclass)
			$('#newtab').val(mynewtab)
			$('#megamenu').val(mymegamenu)
    }

    //Action when window gets loaded first
    function firstload(){
    	var mymenu = $('.mymenu').find('li');
    	var mymenulength = mymenu.length;
    	for(var i=0; i<mymenulength; i++){
			if($(mymenu[i]).attr('data-newtab')==1){
				$(mymenu[i]).children('.innermenu').find('.newwindow').prop('checked', true);
			}
			else{
				$(mymenu[i]).children('.innermenu').find('.newwindow').removeAttr('checked', false);
			}

			if($(mymenu[i]).parent('ol').hasClass('mymenu') && $(mymenu[i]).attr('data-megamenu')==1){
				$(mymenu[i]).children('.innermenu').find('.megamenu').prop('checked', true);
			}
			else{
				$(mymenu[i]).children('.innermenu').find('.megamenu').removeAttr('checked', false);
			}
			$(mymenu[i]).children('.innermenu').find('.name').val(trimChar($(mymenu[i]).attr('data-name'), '>'));
			$(mymenu[i]).children('.innermenu').find('.link').val(trimChar($(mymenu[i]).attr('data-link'), '>'));
			$(mymenu[i]).children('.innermenu').find('.class').val(trimChar($(mymenu[i]).attr('data-class'), '>'));
			$('.pagecheckbox').prop('checked', false);
			$('.blogcheckbox').prop('checked', false);
			$('#alllinks').val('');
			$('#alllinkname').val('');
			$('#deletedid').val('');
		}
    }
    //remove special character
    function trimChar(string, charToRemove) {
	    if (charToRemove === "") {
	    	return string;
	    }
	    else{
		    var countit = string.split(charToRemove).length-1
		    for(var i=0; i<countit; i++){
		    	string = string.replace(charToRemove, '')
		    }
		    return string;
	    }
	}
});