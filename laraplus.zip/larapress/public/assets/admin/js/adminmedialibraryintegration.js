function mediaimagefunc(ed){
    var active= true;
    $('#mymediaselectbutton').on('click', function(e){
        e.preventDefault();
        var media = $('#medialibraryul').attr('data-libraryimage');
        var mediaalt = $('#mediaimagealttext').val();
        if(ed!='' && active==true){
            ed.focus();
            if(media!=''){
                if(mediaalt==''){
                    mediaalt=media;
                }
                ed.selection.setContent('<img src="'+ media +'" alt="'+ mediaalt +'" width="300">');
            }
        }
        active=false;
        $('#medialibraryul').children('li').removeClass('active');
        $('#mediapopup').modal('hide');
    })
    $('#mymediacancletbutton').on('click', function(){
        if(ed!='' && active==true){
            ed.focus();
        }
        active=false;
    })
}


//dropzone
$(document).ready(function(){
    Dropzone.options.addImages ={
        maxFilesize : 2,
        clickable : true,
        acceptedFiles : 'image/jpg, image/jpeg, image/png, image/gif, image/JPG, image/JPEG, image/PNG, image/GIF',
        success : function(file, response){
            if(file.status == 'success'){
                handleDropzoneFileUpload.handleSuccess(response);
            }
            // else{
            //  handleDropzoneFileUpload.handleError(response);
            // }
        }
    };

    var handleDropzoneFileUpload = {
        // handleError: function(response){
        //  myDropzone.removeFile(file);
        // },
        handleSuccess: function(response){
            var imageul = $('#medialibraryul');
            var mybasepath = window.location.origin;
            var imagesrc = mybasepath + '/' + response.filepath + response.filename;
            var imagethumbsrc = mybasepath + '/' + response.filepath + 'thumbs/' + response.filename;
            $(imageul).prepend('<li class="medialibraryli" data-libraryimage="'+imagesrc+'"><div class="listrap-toggle"><span></span><img src="'+ imagethumbsrc +'" /></div></li>')
        }
    }

    $('.mediafiledupload').on('click', function(e){
        e.preventDefault();
        var a = $(this).siblings('input');
        $('#mediapopup').modal('show');
        mediaimagefield(a);
    })

    function mediaimagefield(a){
        var active= true;
        $('#mymediaselectbutton').on('click', function(e){
            e.preventDefault();
            var media = $('#medialibraryul').attr('data-libraryimage');
            var mediaalt = $('#mediaimagealttext').val();
            if(a!='' && active==true){
                a.val(media);
            }
            active=false;
            $('#medialibraryul').children('li').removeClass('active');
            $('#mediapopup').modal('hide');
        })
        $('#mymediacancletbutton').on('click', function(){
            active=false;
        })
    }
})
$(document).on('click', '.medialibraryli', function () {
    $(this).addClass('active').siblings('li').removeClass('active');
    $(this).parent().attr('data-libraryimage', $(this).attr('data-libraryimage'));
    $('#mediaimageurl').val($('#medialibraryul').attr('data-libraryimage'));
    $('#mediaimagepreview').attr('src', $(this).parent().attr('data-libraryimage'))
});