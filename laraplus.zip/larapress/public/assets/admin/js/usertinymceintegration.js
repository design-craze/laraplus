        tinymce.init({
            selector: "#maintext",
            menubar: false,
            theme: "modern",
            relative_urls: false,
            force_div_newlines : true,
            force_h1_newlines : true,
            force_h2_newlines : true,
            force_h3_newlines : true,
            force_h4_newlines : true,
            force_h5_newlines : true,
            force_h6_newlines : true,
            force_p_newlines : true,
            force_ul_newlines : true,
            force_ol_newlines : true,
            force_li_newlines : true,
            force_hr_newlines : true,
            forced_br_newlines : true,
            plugins: [
                "advlist autolink lists link image charmap print preview hr anchor pagebreak",
                "searchreplace wordcount visualblocks visualchars code fullscreen",
                "insertdatetime media nonbreaking save table contextmenu directionality",
                "emoticons template paste textcolor colorpicker textpattern"
            ],
            toolbar1: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent",
            toolbar2: "print preview | forecolor backcolor | code link image medialibrary",
            image_advtab: false,
            setup : function(ed) {
                
            }
        })