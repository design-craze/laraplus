        tinymce.init({
            selector: "#maintext",
            menubar: false,
            theme: "modern",
            relative_urls: false,
            force_div_newlines : true,
            force_h1_newlines : true,
            force_h2_newlines : true,
            force_h3_newlines : true,
            force_h4_newlines : true,
            force_h5_newlines : true,
            force_h6_newlines : true,
            force_ul_newlines : true,
            force_ol_newlines : true,
            force_li_newlines : true,
            force_hr_newlines : true,
            forced_br_newlines : true,
            forced_p_newlines : false,
            forced_root_block : false,
            remove_linebreaks : true,
            convert_urls: false,
            plugins: [
                "advlist autolink lists link image charmap print preview hr anchor pagebreak",
                "searchreplace wordcount visualblocks visualchars code fullscreen",
                "insertdatetime media nonbreaking save table contextmenu directionality",
                "emoticons template paste textcolor colorpicker textpattern"
            ],
            toolbar1: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent",
            toolbar2: "print preview | forecolor backcolor | code link image medialibrary",
            image_advtab: false,
            setup : function(ed) {
                ed.addButton('medialibrary', {
                    title : 'Media Library',
                    text : 'Add Media',
                    image : 'http://www.query.com/assets/admin/img/upload.png',
                    onclick : function() {
                        $('#mediapopup').modal('toggle');
                        // Add you own code to execute something on click
                        // ed.focus();
                        // ed.selection.setContent('');
                        mediaimagefunc(ed);
                    }
                })

            },
            init_instance_callback: function (editor) {
                editor.on('PostProcess', function (e) {
                    e.content = e.content.replace(/<br \/>/g, '');
                    e.content = e.content.replace(/]/g, ']\n');
                    e.content = e.content.replace(/\[\//g, '\n\[\/');
                    // e.content += 'My custom content!';
                });
            }
        })