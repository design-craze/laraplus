<?php 
$bs_small = 767;
$bs_medium = 991;
$bs_large = 1199;
$bs_container_lg = 1170;
$bs_container_md = 962;
$bs_container_sm = 738;

if(ctype_digit($settinghelper['large_breakpoint'])==false){
  $settinghelper['large_breakpoint']=$bs_large;
}
if(ctype_digit($settinghelper['medium_breakpoint'])==false){
  $settinghelper['medium_breakpoint']=$bs_medium;
}
if(ctype_digit($settinghelper['small_breakpoint'])==false){
  $settinghelper['small_breakpoint']=$bs_small;
}
if(ctype_digit($settinghelper['container_width_lg'])==false){
  $settinghelper['container_width_lg']=$bs_container_lg;
}
if(ctype_digit($settinghelper['container_width_md'])==false){
  $settinghelper['container_width_md']=$bs_container_md;
}
if(ctype_digit($settinghelper['container_width_sm'])==false){
  $settinghelper['container_width_sm']=$bs_container_sm;
}

if($settinghelper['large_breakpoint']-$settinghelper['medium_breakpoint']>=3 && $settinghelper['medium_breakpoint']-$settinghelper['small_breakpoint']>=3 && $settinghelper['large_breakpoint']>0 && $settinghelper['medium_breakpoint'] >0 && $settinghelper['small_breakpoint'] >0 && $settinghelper['large_breakpoint']-$settinghelper['container_width_lg']>=29 && $settinghelper['medium_breakpoint']-$settinghelper['container_width_md'] >=29 && $settinghelper['small_breakpoint']-$settinghelper['container_width_sm'] >=29 && $settinghelper['container_width_lg'] > 0 && $settinghelper['container_width_md'] > 0 && $settinghelper['container_width_sm'] > 0 && $settinghelper['container_width_lg'] > $settinghelper['container_width_md'] && $settinghelper['container_width_md'] > $settinghelper['container_width_sm'])
{
  $bs_large = $settinghelper['large_breakpoint'];
  $bs_medium = $settinghelper['medium_breakpoint'];
  $bs_small = $settinghelper['small_breakpoint'];

  $bs_container_lg = $settinghelper['container_width_lg'];
  $bs_container_md = $settinghelper['container_width_md'];
  $bs_container_sm = $settinghelper['container_width_sm'];
}
?>

<style>
  .container-full{
    width:100%;
  }
  .container-center{
    width:100%;
  }
  
  .innersection,
  .inner-overlay{
    margin-left: -15px;
    margin-right: -15px;
    padding-left: 15px;
    padding-right: 15px;
  }

  @media  all and (min-width: <?php echo $bs_small+1; ?>px) {
    .container-fluid .col-sm-12 .container-center, .container-fluid .col-md-12 .container-center, 
    .container-fluid .col-lg-12 .container-center, .container-fluid .col-xs-12 .container-center{
      padding-left:15px;
      padding-right:15px;
      margin: 0 auto;
      width: <?php echo $bs_container_sm; ?>px;
    }
    .dc-body-box-layout{
      width: <?php echo $bs_container_sm; ?>px;
      margin:0 auto;
    }
    <?php if(file_exists(getviewpath().'/template/'.allsetting('template') . '/dynamicstyle/smallminscreen.blade.php')){ ?>
<?php echo $__env->make('template.'.$settinghelper['template'].'.dynamicstyle.smallminscreen', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php } ?>
    <?php echo e($settinghelper['small_min_css']); ?>

  }
  @media  all and (min-width: <?php echo $bs_medium+1; ?>px) {
    .container-fluid .col-sm-12 .container-center, .container-fluid .col-md-12 .container-center, 
    .container-fluid .col-lg-12 .container-center, .container-fluid .col-xs-12 .container-center{
      padding-left:15px;
      padding-right:15px;
      margin: 0 auto;
      width: <?php echo $bs_container_md; ?>px;
    }
    .dc-body-box-layout{
      width: <?php echo $bs_container_md; ?>px;
      margin:0 auto;
    }
    <?php if(file_exists(getviewpath().'/template/' . allsetting('template') . '/dynamicstyle/mediumminscreen.blade.php')){ ?>
<?php echo $__env->make('template.'.$settinghelper['template'].'.dynamicstyle.mediumminscreen', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php } ?>
    <?php echo e($settinghelper['medium_min_css']); ?>

  }
  @media  all and (min-width: <?php echo $bs_large+1; ?>px) {
    .container-fluid .col-sm-12 .container-center, .container-fluid .col-md-12 .container-center, 
    .container-fluid .col-lg-12 .container-center, .container-fluid .col-xs-12 .container-center{
      padding-left:15px;
      padding-right:15px;
      margin: 0 auto;
      width: <?php echo $bs_container_lg; ?>px;
    }
    .dc-body-box-layout{
      width: <?php echo $bs_container_lg; ?>px;
      margin:0 auto;
    }
    <?php if(file_exists(getviewpath().'/template/' . allsetting('template').'/dynamicstyle/largeminscreen.blade.php')){ ?>
<?php echo $__env->make('template.'.$settinghelper['template'].'.dynamicstyle.largeminscreen', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php } ?>
    <?php echo e($settinghelper['large_min_css']); ?>

  }
  @media  all and (max-width: <?php echo $bs_large; ?>px) {
    <?php if(file_exists(getviewpath().'/template/' . allsetting('template').'/dynamicstyle/largemaxscreen.blade.php')){ ?>
    <?php echo $__env->make('template.'.$settinghelper['template'].'.dynamicstyle.largemaxscreen', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php } ?>
    <?php echo e($settinghelper['large_max_css']); ?>

  }
  @media  all and (max-width: <?php echo $bs_medium; ?>px) {
    <?php if(file_exists(getviewpath().'/template/' . allsetting('template').'/dynamicstyle/mediummaxscreen.blade.php')){ ?>
    <?php echo $__env->make('template.'.$settinghelper['template'].'.dynamicstyle.mediummaxscreen', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php } ?>
    <?php echo e($settinghelper['medium_max_css']); ?>

  }
  @media  all and (max-width: <?php echo $bs_small; ?>px) {
    <?php if(file_exists(getviewpath().'/template/' . allsetting('template').'/dynamicstyle/smallmaxscreen.blade.php')){ ?>
    <?php echo $__env->make('template.'.$settinghelper['template'].'.dynamicstyle.smallmaxscreen', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php } ?>
    <?php echo e($settinghelper['small_max_css']); ?>

  }

<?php
  if(Auth::user() && file_exists(getviewpath().'/template/' . allsetting('template').'/dynamicstyle/usercss.blade.php')){ ?>
<?php echo $__env->make('template.'.$settinghelper['template'].'.dynamicstyle.usercss', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo e($settinghelper['user_css']); ?>

<?php }
  elseif(file_exists(getviewpath().'/template/' . allsetting('template').'/dynamicstyle/guestcss.blade.php')){ ?>
<?php echo $__env->make('template.'.$settinghelper['template'].'.dynamicstyle.guestcss', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo e($settinghelper['guest_css']); ?>

<?php } ?>

</style>