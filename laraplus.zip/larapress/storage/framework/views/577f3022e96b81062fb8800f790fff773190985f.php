<?php echo $__env->make('template.'.$settinghelper['template'].'.includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- start extra coding here but without container - Only Row and column if needed. but it's already in row. so better to just use div for design-->
<?php echo $__env->make('template.'.$settinghelper['template'].'.includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
