<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>DashBoard | <?php echo $__env->yieldContent('title'); ?></title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.4 -->
    <?php echo e(Html::style('assets/admin/css/bootstrap.min.css')); ?>

    <!-- Font Awesome -->
    <?php echo e(Html::style('assets/common/css/font-awesome.min.css')); ?>

    <!-- Ionicons -->
    <?php echo e(Html::style('assets/admin/vendor/ionicons-2.0.1/css/ionicons.min.css')); ?>

    <!-- Theme style -->
    <?php echo e(Html::style('assets/admin/css/AdminLTE.min.css')); ?>

    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <?php echo e(Html::style('assets/admin/css/skins/_all-skins.min.css')); ?>

    
    <?php echo $__env->yieldContent('headcode'); ?>

    <?php echo e(Html::style('assets/admin/css/style.css')); ?>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <!-- ADD THE CLASS sidedar-collapse TO HIDE THE SIDEBAR PRIOR TO LOADING THE SITE -->
  <body class="skin-blue sidebar-collapse sidebar-mini">
    <!-- Site wrapper -->
    <div class="wrapper">

      <header class="main-header">
        <!-- Logo -->
        <a href="" class="logo">
          <!-- mini logo for sidebar mini 50x50 pixels -->
          <span class="logo-mini"><strong>D</strong>C</span>
          <!-- logo for regular state and mobile devices -->
          <span class="logo-lg"><strong>Design</strong>Craze</span>
        </a>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top" role="navigation">
          <!-- Sidebar toggle button-->
          <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </a>
          <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
              <!-- Tasks: style can be found in dropdown.less -->
              <li class="dropdown tasks-menu">
                <a href="<?php echo e(route('home')); ?>" class="dropdown-toggle" target="_blank">
                  <i class="fa fa-sign-out"></i> Front End
                </a>
              </li>
              <!-- User Account: style can be found in dropdown.less -->
              <li class="dropdown user user-menu">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  <span class="hidden-xs">
                    <?php if(Auth::user()->fname != '' && Auth::user()->lname != ''): ?>
                      <?php echo e(Auth::user()->fname); ?> <?php echo e(Auth::user()->lname); ?>

                    <?php else: ?>
                      <?php echo e(Auth::user()->username); ?>

                    <?php endif; ?>
                  </span>
                </a>
                <ul class="dropdown-menu">
                  <!-- User image -->
                  <!-- Menu Footer-->
                  <li class="user-footer">
                    <div class="pull-left">
                      <a href="<?php echo e(route('viewuserinfo',['id'=>Auth::user()->id])); ?>" class="btn btn-default btn-flat">Profile</a>
                    </div>
                    <div class="pull-right">
                      <a href="<?php echo e(route('logout')); ?>" class="btn btn-default btn-flat">Sign out</a>
                    </div>
                  </li>
                </ul>
              </li>
            </ul>
          </div>
        </nav>
      </header>

      <!-- =============================================== -->

      <!-- Left side column. contains the sidebar -->
      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
          <!-- sidebar menu: : style can be found in sidebar.less -->
          <ul class="sidebar-menu">
            <li class="header">MAIN NAVIGATION</li>
            <li class="treeview">
              <a href="<?php echo e(route('admindashboard')); ?>">
                <i class="fa fa-tachometer"></i> <span>Dashboard</span> <i class="fa fa-angle-left pull-right"></i>
              </a>
            </li>
            <li class="treeview">
              <a href="#">
                <i class="fa fa-medium"></i> <span>Manage Media</span> <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="<?php echo e(route('mediamanager')); ?>"><i class="fa fa-circle-o"></i>Media Library</a></li>
                <li><a href="<?php echo e(route('mediaupload')); ?>"><i class="fa fa-circle-o"></i>Add Media</a></li>
              </ul>
            </li>
            <li class="treeview">
              <a href="#">
                <i class="fa fa-th"></i> <span>Manage Menu</span> <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="<?php echo e(route('managemenu')); ?>"><i class="fa fa-circle-o"></i>Menu Manager</a></li>
                <li><a href="<?php echo e(route('adminnav')); ?>"><i class="fa fa-circle-o"></i>Menu Sorter</a></li>
              </ul>
            </li>
            <li class="treeview">
              <a href="#">
                <i class="fa fa-cogs"></i> <span>Manage Template</span> <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="<?php echo e(route('setting')); ?>"><i class="fa fa-circle-o"></i>General Options</a></li>
                <li><a href="<?php echo e(route('template')); ?>"><i class="fa fa-circle-o"></i>Template Selection</a></li>
              </ul>
            </li>
            <li class="treeview">
              <a href="#">
                <i class="fa fa-file-text"></i> <span>Manage Page</span> <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="<?php echo e(route('pagemanager')); ?>"><i class="fa fa-circle-o"></i>Page Manager</a></li>
                <li><a href="<?php echo e(route('trashpage')); ?>"><i class="fa fa-circle-o"></i>Trashed Pages</a></li>
                <li><a href="<?php echo e(route('newpage')); ?>"><i class="fa fa-circle-o"></i>New Page</a></li>
              </ul>
            </li>
            <li class="treeview">
              <a href="#">
                <i class="fa fa-book"></i> <span>Manage Blog</span> <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="<?php echo e(route('blogmanager')); ?>"><i class="fa fa-circle-o"></i>Blog Manager</a></li>
                <li><a href="<?php echo e(route('trashblog')); ?>"><i class="fa fa-circle-o"></i>Trashed Blogs</a></li>
                <li><a href="<?php echo e(route('archiveblog')); ?>"><i class="fa fa-circle-o"></i>Archived Blogs</a></li>
                <li><a href="<?php echo e(route('newblog')); ?>"><i class="fa fa-circle-o"></i>New Blog</a></li>
              </ul>
            </li>
            <li class="treeview">
              <a href="#">
                <i class="fa fa-th-list"></i> <span>Manage Post Category</span> <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="<?php echo e(route('managecategory')); ?>"><i class="fa fa-circle-o"></i>All Categories</a></li>
                <li><a href="<?php echo e(route('createnewcategory')); ?>"><i class="fa fa-circle-o"></i>Add New Category</a></li>
                <li><a href="<?php echo e(route('trashcategory')); ?>"><i class="fa fa-circle-o"></i>Trashed Categories</a></li>
              </ul>
            </li>
            <li class="treeview">
              <a href="#">
                <i class="fa fa-comment"></i> <span>Manage Comments</span> <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="<?php echo e(route('managecomment')); ?>"><i class="fa fa-circle-o"></i>All Comments</a></li>
              </ul>
            </li>
            
            <li class="treeview">
              <a href="#">
                <i class="fa fa-users"></i> <span>Manage Users</span> <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="<?php echo e(route('userlist')); ?>"><i class="fa fa-circle-o"></i>All Users</a></li>
                <li><a href="<?php echo e(route('createuser')); ?>"><i class="fa fa-circle-o"></i>Add New User</a></li>
              </ul>
            </li>
            <li class="treeview">
              <a href="#">
                <i class="fa fa-braille"></i> <span>Manage Widget</span> <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="<?php echo e(route('widget')); ?>"><i class="fa fa-circle-o"></i>Widgets</a></li>
              </ul>
            </li>
            <li class="treeview">
              <a href="#">
                <i class="fa fa-gear"></i> <span>Manage Setting</span> <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="<?php echo e(route('viewuserinfo',['id'=>Auth::user()->id])); ?>"><i class="fa fa-user"></i>Profile</a></li>
                <li><a href="<?php echo e(route('adminusersetting')); ?>"><i class="fa fa-gears"></i>Setting</a></li>
              </ul>
            </li>
            <!-- <li class="treeview">
              <a href="#">
                <i class="fa fa-dashboard"></i> <span>Dashboard</span> <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="../../index.html"><i class="fa fa-circle-o"></i> Dashboard v1</a></li>
                <li><a href="../../index2.html"><i class="fa fa-circle-o"></i> Dashboard v2</a></li>
              </ul>
            </li> -->
            <!-- <li class="treeview active">
              <a href="#">
                <i class="fa fa-files-o"></i>
                <span>Layout Options</span>
                <span class="label label-primary pull-right">4</span>
              </a>
              <ul class="treeview-menu">
                <li><a href="top-nav.html"><i class="fa fa-circle-o"></i> Top Navigation</a></li>
                <li><a href="boxed.html"><i class="fa fa-circle-o"></i> Boxed</a></li>
                <li><a href="fixed.html"><i class="fa fa-circle-o"></i> Fixed</a></li>
                <li class="active"><a href="collapsed-sidebar.html"><i class="fa fa-circle-o"></i> Collapsed Sidebar</a></li>
              </ul>
            </li>
            <li>
              <a href="../widgets.html">
                <i class="fa fa-th"></i> <span>Widgets</span> <small class="label pull-right bg-green">new</small>
              </a>
            </li>
            <li class="treeview">
              <a href="#">
                <i class="fa fa-pie-chart"></i>
                <span>Charts</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="../charts/chartjs.html"><i class="fa fa-circle-o"></i> ChartJS</a></li>
                <li><a href="../charts/morris.html"><i class="fa fa-circle-o"></i> Morris</a></li>
                <li><a href="../charts/flot.html"><i class="fa fa-circle-o"></i> Flot</a></li>
                <li><a href="../charts/inline.html"><i class="fa fa-circle-o"></i> Inline charts</a></li>
              </ul>
            </li>
            <li class="treeview">
              <a href="#">
                <i class="fa fa-laptop"></i>
                <span>UI Elements</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="../UI/general.html"><i class="fa fa-circle-o"></i> General</a></li>
                <li><a href="../UI/icons.html"><i class="fa fa-circle-o"></i> Icons</a></li>
                <li><a href="../UI/buttons.html"><i class="fa fa-circle-o"></i> Buttons</a></li>
                <li><a href="../UI/sliders.html"><i class="fa fa-circle-o"></i> Sliders</a></li>
                <li><a href="../UI/timeline.html"><i class="fa fa-circle-o"></i> Timeline</a></li>
                <li><a href="../UI/modals.html"><i class="fa fa-circle-o"></i> Modals</a></li>
              </ul>
            </li>
            <li class="treeview">
              <a href="#">
                <i class="fa fa-edit"></i> <span>Forms</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="../forms/general.html"><i class="fa fa-circle-o"></i> General Elements</a></li>
                <li><a href="../forms/advanced.html"><i class="fa fa-circle-o"></i> Advanced Elements</a></li>
                <li><a href="../forms/editors.html"><i class="fa fa-circle-o"></i> Editors</a></li>
              </ul>
            </li>
            <li class="treeview">
              <a href="#">
                <i class="fa fa-table"></i> <span>Tables</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="../tables/simple.html"><i class="fa fa-circle-o"></i> Simple tables</a></li>
                <li><a href="../tables/data.html"><i class="fa fa-circle-o"></i> Data tables</a></li>
              </ul>
            </li>
            <li>
              <a href="../calendar.html">
                <i class="fa fa-calendar"></i> <span>Calendar</span>
                <small class="label pull-right bg-red">3</small>
              </a>
            </li>
            <li>
              <a href="../mailbox/mailbox.html">
                <i class="fa fa-envelope"></i> <span>Mailbox</span>
                <small class="label pull-right bg-yellow">12</small>
              </a>
            </li>
            <li class="treeview">
              <a href="#">
                <i class="fa fa-folder"></i> <span>Examples</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="../examples/invoice.html"><i class="fa fa-circle-o"></i> Invoice</a></li>
                <li><a href="../examples/login.html"><i class="fa fa-circle-o"></i> Login</a></li>
                <li><a href="../examples/register.html"><i class="fa fa-circle-o"></i> Register</a></li>
                <li><a href="../examples/lockscreen.html"><i class="fa fa-circle-o"></i> Lockscreen</a></li>
                <li><a href="../examples/404.html"><i class="fa fa-circle-o"></i> 404 Error</a></li>
                <li><a href="../examples/500.html"><i class="fa fa-circle-o"></i> 500 Error</a></li>
                <li><a href="../examples/blank.html"><i class="fa fa-circle-o"></i> Blank Page</a></li>
              </ul>
            </li>
            <li class="treeview">
              <a href="#">
                <i class="fa fa-share"></i> <span>Multilevel</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="#"><i class="fa fa-circle-o"></i> Level One</a></li>
                <li>
                  <a href="#"><i class="fa fa-circle-o"></i> Level One <i class="fa fa-angle-left pull-right"></i></a>
                  <ul class="treeview-menu">
                    <li><a href="#"><i class="fa fa-circle-o"></i> Level Two</a></li>
                    <li>
                      <a href="#"><i class="fa fa-circle-o"></i> Level Two <i class="fa fa-angle-left pull-right"></i></a>
                      <ul class="treeview-menu">
                        <li><a href="#"><i class="fa fa-circle-o"></i> Level Three</a></li>
                        <li><a href="#"><i class="fa fa-circle-o"></i> Level Three</a></li>
                      </ul>
                    </li>
                  </ul>
                </li>
                <li><a href="#"><i class="fa fa-circle-o"></i> Level One</a></li>
              </ul>
            </li>
            <li><a href="../../documentation/index.html"><i class="fa fa-book"></i> <span>Documentation</span></a></li>
            <li class="header">LABELS</li>
            <li><a href="#"><i class="fa fa-circle-o text-red"></i> <span>Important</span></a></li>
            <li><a href="#"><i class="fa fa-circle-o text-yellow"></i> <span>Warning</span></a></li>
            <li><a href="#"><i class="fa fa-circle-o text-aqua"></i> <span>Information</span></a></li> -->
          </ul>
        </section>
        <!-- /.sidebar -->
      </aside>

      <!-- =============================================== -->

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header dashboard-title">
          <div class="box box-primary">
              <div class="box-body">
                <h1>
                  Admin DashBoard
                </h1>
                <ol class="breadcrumb">
                  <li><a href=""><?php echo $__env->yieldContent('breadcambs'); ?></a></li>
                </ol>
              </div><!-- /.box-body -->
          </div>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
                <div class="col-md-12">
                  <?php if(Session::has('success')): ?>
                  <div class="alert alert-success alert-dismissable">
                      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                      <h4><i class="icon fa fa-check"></i> SUCCESS!</h4>
                      <?php echo e(Session::get('success')); ?>

                  </div>
                  <?php elseif(Session::has('dissmiss')): ?>
                  <div class="alert alert-danger alert-dismissable">
                      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                      <h4><i class="icon fa fa-ban"></i> FAILED!</h4>
                      <?php echo e(Session::get('dissmiss')); ?>

                  </div>
                  <?php elseif(Session::has('available')): ?>
                    <div class="alert alert-warning alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        <?php echo e(Session::get('available')); ?>

                    </div>
                  <?php elseif(count($errors) > 0): ?>
                  <div class="alert alert-danger alert-dismissable">
                      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                      <h4><i class="icon fa fa-ban"></i> Validation FAILED!</h4>
                      <ul class="list-unstyled" style="padding-left:31px;">
                          <?php foreach($errors->all() as $error): ?>
                              <li>
                                  <?php echo e($error); ?>

                              </li>
                          <?php endforeach; ?>
                      </ul>
                  </div>
                  <?php endif; ?>
                </div>
            </div>
            <?php echo $__env->yieldContent('bodycode'); ?>
        </section>

      </div><!-- ./wrapper -->
      <footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b>Version</b> 1.1.0
        </div>
        <strong>Copyright &copy; 2016 <a href="http://www.design-craze.com">Design Craze</a>.</strong> All rights reserved.
      </footer>
  </div>
    <!-- jQuery and jquey ui -->
    <?php echo e(Html::script('assets/common/js/jquery-1.9.1.js')); ?>

    <?php echo e(Html::script('assets/common/js/jquery-ui.js')); ?>

    <!-- Bootstrap 3.3.4 -->

    <?php echo e(Html::script('assets/admin/js/bootstrap.min.js')); ?>

    <!-- SlimScroll -->
    <?php echo e(Html::script('assets/admin/vendor/slimScroll/jquery.slimscroll.min.js')); ?>

    <!-- FastClick -->
    <?php echo e(Html::script('assets/admin/vendor/fastclick/fastclick.min.js')); ?>

    <!-- AdminLTE App -->
    <?php echo e(Html::script('assets/admin/js/app.min.js')); ?>

    <!-- AdminLTE for demo purposes -->
    <?php echo e(Html::script('assets/admin/js/demo.js')); ?>

    <script>
    $(function(){
      $('.confirmation').each(function(){
        var $this = $(this);
        $this.on('click', function(e){
          var r = confirm($this.attr('data-alert'));
          if (r == false) {
            e.preventDefault();
          }
        })
      })
    })
    </script>
    <?php echo $__env->yieldContent('jscode'); ?>
  </body>
</html>