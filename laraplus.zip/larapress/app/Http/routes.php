<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

$settinghelper = allsetting();
$larasearchblog ='searchblog';
if(isset($settinghelper['search_page']) && $settinghelper['search_page']!=null && $settinghelper['search_page'] > 0){$larasearchblog = getpage($settinghelper['search_page']);}
$larablogctg ='blogcats';
if(isset($settinghelper['blogctg_page']) && $settinghelper['blogctg_page']!=null && $settinghelper['blogctg_page'] > 0){$larablogctg = getpage($settinghelper['blogctg_page']);}


Route::get('/', ['uses' => 'Front\HomeController@index', 'as' => 'home']);
//User Route-----------------------------------------------------------------------------------------
Route::get('/user/dashboard', ['uses' => 'User\DashboardController@profile', 'as' => 'dashboard']);
Route::get('/user', ['uses' => 'User\DashboardController@user', 'as' => 'user']);
Route::get('/user/profile/{id}', ['uses' => 'User\DashboardController@profile', 'as' => 'profile']);
Route::get('/user/editprofile', ['uses' => 'User\DashboardController@editprofile', 'as' => 'editprofile']);
Route::post('/user/editprofileprocess', ['uses' => 'User\DashboardController@editprofileprocess', 'as' => 'editprofileprocess']);
// my post route
Route::get('/user/createblog', ['uses' => 'User\BlogController@createblog', 'as' => 'createblog']);
Route::post('/user/createblogprocess', ['uses' => 'User\BlogController@createblogprocess', 'as' => 'createblogprocess']);
Route::get('/user/editblog/{id}', ['uses' => 'User\BlogController@editblog', 'as' => 'editpost'])->where('id','[0-9]+');
Route::post('/user/editblogprocess/{id}', ['uses' => 'User\BlogController@editblogprocess', 'as' => 'editblogprocess'])->where('id','[0-9]+');
Route::get('/user/myblogs', ['uses' => 'User\BlogController@myblogs', 'as' => 'myblogs']);
Route::post('/submitcomment/{blogid}', ['uses' => 'user\BlogController@submitcomment', 'as' => 'submitcomment'])->where('blogid','[0-9]+');
Route::post('/updatecomment/{blogid}/{comid}', ['uses' => 'user\BlogController@updatecomment', 'as' => 'updatecomment'])->where(['blogid'=>'[0-9]+','comid'=>'[0-9]+']);
Route::post('/replycomment/{blogid}/{parentid}', ['uses' => 'user\BlogController@replycomment', 'as' => 'replycomment'])->where(['blogid'=>'[0-9]+','parentid'=>'[0-9]+']);
Route::get('/user/deletecomment/{blogid}/{comid}', ['uses' => 'user\BlogController@deletecomment', 'as' => 'deletecomment'])->where(['blogid'=>'[0-9]+','comid'=>'[0-9]+']);

// suspended route
Route::get('/user/usersetting', ['uses' => 'User\DashboardController@usersetting', 'as' => 'usersetting']);

// suspended route
Route::get('/user/suspended', ['uses' => 'User\SuspendedController@suspended', 'as' => 'suspended']);

// verify route
Route::get('/user/verify/{vfcode}', ['uses' => 'Front\VerifyController@verify', 'as' => 'verify']);
Route::get('/user/resendverifymail', ['uses' => 'Front\VerifyController@resendverifymail', 'as' => 'resendverifymail']);

// identify route
Route::post('/identifyemailprocess', ['uses' => 'Front\IdentifyController@identifyemailprocess', 'as' => 'identifyemailprocess']);
Route::get('/recovery/{vfcode}', ['uses' => 'Front\IdentifyController@recovery', 'as' => 'recovery']);
Route::post('/recoveryemailprocess/{vfcode}', ['uses' => 'Front\IdentifyController@recoveryemailprocess', 'as' => 'recoveryemailprocess']);
Route::post('recover/{vfcode}', ['uses' => 'Front\IdentifyController@recoveryemailprocess', 'as' => 'recoveryemailprocess']);

//Admin Route--------------------------------------------------------------------------------------------------
// suspended route
Route::get('/admin/suspended', ['uses' => 'Admin\SuspendedController@suspended', 'as' => 'adminsuspended']);
Route::post('/admin/suspendedmessageprocess', ['uses' => 'Admin\SuspendedController@suspendedmessageprocess', 'as' => 'suspendedmessageprocess']);

// user setting
Route::get('/admin/adminusersetting', ['uses' => 'Admin\DashboardController@adminusersetting', 'as' => 'adminusersetting']);
Route::post('/admin/changepasswordprocess', ['uses' => 'Admin\DashboardController@changepasswordprocess', 'as' => 'changepasswordprocess']);

// Comment Setting ------------------------------------------------------------------------------------
Route::get('/admin/managecomment', ['uses' => 'Admin\CommentController@managecomment', 'as' => 'managecomment']);
Route::get('/admin/commentdelete/{id}', ['uses' => 'Admin\CommentController@commentdelete', 'as' => 'commentdelete'])->where('id','[0-9]+');
Route::get('/admin/subcomment/{id}', ['uses' => 'Admin\CommentController@subcomment', 'as' => 'subcomment'])->where('id','[0-9]+');
Route::get('/admin/commentedit/{id}', ['uses' => 'Admin\CommentController@commentedit', 'as' => 'commentedit'])->where('id','[0-9]+');
Route::post('/admin/commenteditprocess/{id}', ['uses' => 'Admin\CommentController@commenteditprocess', 'as' => 'commenteditprocess'])->where('id','[0-9]+');

// Media Setting-------------------------------------------------------------------------------------------------------
Route::get('/admin/mediaupload', ['uses' => 'Admin\MediaController@mediaupload', 'as' => 'mediaupload']);
Route::post('/admin/mediauploadprocess', ['uses' => 'Admin\MediaController@mediauploadprocess', 'as' => 'mediauploadprocess']);

Route::get('/admin/mediamanager', ['uses' => 'Admin\MediaController@mediamanager', 'as' => 'mediamanager']);
Route::get('/admin/mediadelete/{id}', ['uses' => 'Admin\MediaController@mediadelete', 'as' => 'mediadelete'])->where('id', '[0-9]+');


//Login-------------------------------------------------------------------------------------------------------
Route::get('/admin/login', ['uses' => 'Admin\LoginController@login', 'as' => 'adminlogin']);
Route::post('/admin/loginprocess', ['uses' => 'Admin\LoginController@loginprocess', 'as' => 'adminloginprocess']);
Route::get('/logout', ['uses' => 'Admin\LoginController@logout', 'as' => 'logout']);

//Dashboard-------------------------------------------------------------------------------------------------------
Route::get('/admin/dashboard', ['uses' => 'Admin\DashboardController@dashboard', 'as' => 'admindashboard']);
Route::get('/admin', ['uses' => 'Admin\DashboardController@admin', 'as' => 'admin']);


//Setting-------------------------------------------------------------------------------------------------------
Route::get('/admin/setting', ['uses' => 'Admin\SettingController@setting', 'as' => 'setting']);
Route::post('/admin/settingprocess', ['uses' => 'Admin\SettingController@settingprocess', 'as' => 'settingprocess']);

//Blog manager--------------------------------------------------------------------------------------------------
Route::get('/admin/blogmanager', ['uses' => 'Admin\BlogController@bloglist', 'as' => 'blogmanager']);
Route::get('/admin/featureblog/{id}', ['uses' => 'Admin\BlogController@featureblog', 'as' => 'featureblog'])->where('id', '[0-9]+');

//Blog manager--------------------------------------------------------------------------------------------------
Route::get('/admin/template', ['uses' => 'Admin\TemplateController@template', 'as' => 'template']);
Route::get('/admin/changetemplate/{name}', ['uses' => 'Admin\TemplateController@changetemplate', 'as' => 'changetemplate']);

//Delete Blogs
Route::get('/admin/trashblog', ['uses' => 'Admin\BlogController@trashblog', 'as' => 'trashblog']);
Route::get('/admin/tempblogdelete/{id}/{from}', ['uses' => 'Admin\BlogController@tempblogdelete', 'as' => 'tempblogdelete'])->where(['id' => '[0-9]+', 'from' => '[1-2]']);
Route::get('/admin/parmblogdelete/{id}', ['uses' => 'Admin\BlogController@parmblogdelete', 'as' => 'parmblogdelete'])->where('id', '[0-9]+');
Route::get('/admin/restoreblog/{id}', ['uses' => 'Admin\BlogController@restoreblog', 'as' => 'restoreblog'])->where('id', '[0-9]+');

//Edit and create Blogs
Route::get('/admin/newblog', ['uses' => 'Admin\BlogController@newblog', 'as' => 'newblog']);
Route::post('/admin/blogcreateprocess', ['uses' => 'Admin\BlogController@blogcreateprocess', 'as' => 'blogcreateprocess']);
Route::get('/admin/editblog/{id}', ['uses' => 'Admin\BlogController@editblog', 'as' => 'editblog'])->where('id', '[0-9]+');
Route::post('/admin/blogeditprocess/{id}', ['uses' => 'Admin\BlogController@blogeditprocess', 'as' => 'blogeditprocess'])->where('id', '[0-9]+');

//Archive Blog
Route::get('/admin/archiveblog', ['uses' => 'Admin\BlogController@archiveblog', 'as' => 'archiveblog']);
Route::get('/admin/sendblogtoarchive/{id}', ['uses' => 'Admin\BlogController@sendblogtoarchive', 'as' => 'sendblogtoarchive'])->where('id', '[0-9]+');
Route::get('/admin/restorearchiveblog/{id}', ['uses' => 'Admin\BlogController@restorearchiveblog', 'as' => 'restorearchiveblog'])->where('id', '[0-9]+');

// user list
Route::get('/admin/userlist', ['uses' => 'Admin\UsersController@userlist', 'as' => 'userlist']);
Route::get('/admin/createuser', ['uses' => 'Admin\UsersController@createuser', 'as' => 'createuser']);
Route::post('/admin/createuserprocess', ['uses' => 'Admin\UsersController@createuserprocess', 'as' => 'createuserprocess']);
Route::get('/admin/removprofileimage/{imgval}',['uses' => 'Admin\UsersController@removprofileimage', 'as' => 'removprofileimage']);
Route::post('/admin/uloadprofileimage', ['uses' => 'Admin\UsersController@uloadprofileimage', 'as' => 'uloadprofileimage']);
Route::get('/admin/viewuserinfo/{id}', ['uses' => 'Admin\UsersController@viewuserinfo', 'as' => 'viewuserinfo'])->where('id', '[0-9]+');
Route::get('/admin/edituserinfo/{id}', ['uses' => 'Admin\UsersController@edituserinfo', 'as' => 'edituserinfo'])->where('id', '[0-9]+');
Route::post('/admin/edituserprocess/{id}', ['uses' => 'Admin\UsersController@edituserprocess', 'as' => 'edituserprocess'])->where('id', '[0-9]+');

//Page manager--------------------------------------------------------------------------------------------------------------------------------
Route::get('/admin/pagemanager', ['uses' => 'Admin\PageController@pagelist', 'as' => 'pagemanager']);
Route::get('/admin/changehomepage/{id}', ['uses' => 'Admin\PageController@changehomepage', 'as' => 'changehomepage'])->where('id', '[0-9]+');


//Multilingual pages
Route::get('/admin/createmultipages/{id}', ['uses' => 'Admin\PageController@createmultipages', 'as' => 'createmultipages'])->where('id', '[0-9]+');
Route::get('/admin/multipage/{id}', ['uses' => 'Admin\PageController@multipage', 'as' => 'multipage'])->where('id', '[0-9]+');

//Delete pages
Route::get('/admin/trashpage', ['uses' => 'Admin\PageController@trashpage', 'as' => 'trashpage']);
Route::get('/admin/temppagedelete/{id}', ['uses' => 'Admin\PageController@temppagedelete', 'as' => 'temppagedelete'])->where('id', '[0-9]+');
Route::get('/admin/parmpagedelete/{id}', ['uses' => 'Admin\PageController@parmpagedelete', 'as' => 'parmpagedelete'])->where('id', '[0-9]+');
Route::get('/admin/restorepage/{id}', ['uses' => 'Admin\PageController@restorepage', 'as' => 'restorepage'])->where('id', '[0-9]+');

//Edit and create pages
Route::get('/admin/newpage', ['uses' => 'Admin\PageController@newpage', 'as' => 'newpage']);
Route::post('/admin/pagecreateprocess', ['uses' => 'Admin\PageController@pagecreateprocess', 'as' => 'pagecreateprocess']);
Route::get('/admin/editpage/{id}', ['uses' => 'Admin\PageController@editpage', 'as' => 'editpage'])->where('id', '[0-9]+');
Route::post('/admin/pageeditprocess/{id}', ['uses' => 'Admin\PageController@pageeditprocess', 'as' => 'pageeditprocess'])->where('id', '[0-9]+');

//Menu Manager----------------------------------------------------------------------------------------------------------------------------------
Route::get('/admin/menu', ['uses' => 'Admin\NavController@index', 'as' => 'adminnav']);
Route::post('/admin/savenav', ['uses' => 'Admin\NavController@savenav', 'as' => 'savenav']);
Route::get('/admin/managemenu', ['uses' => 'Admin\NavController@managemenu', 'as' => 'managemenu']);
Route::post('/admin/createdeletenav', ['uses' => 'Admin\NavController@createdeletenav', 'as' => 'createdeletenav']);


//Widget Manager--------------------------------------------------------------------------------------------------------------------------------
Route::get('/admin/widget', ['uses' => 'Admin\WidgetController@widget', 'as' => 'widget']);
Route::post('/admin/widgetsave', ['uses' => 'Admin\WidgetController@widgetsave', 'as' => 'widgetsave']);

// image remove route

Route::get('/admin/removfavimage/{imgval}',['uses' => 'Admin\SettingController@removfavimage', 'as' => 'removfavimage']);
Route::get('/admin/removlogoimage/{imgval}',['uses' => 'Admin\SettingController@removlogoimage', 'as' => 'removlogoimage']);

// catgory manager
Route::get('/admin/managecategory', ['uses' => 'Admin\CategoryController@managecategory', 'as' => 'managecategory']);
Route::get('/admin/trashcategory', ['uses' => 'Admin\CategoryController@trashcategory', 'as' => 'trashcategory']);
Route::get('/admin/tempcatgdelete/{id}', ['uses' => 'Admin\CategoryController@tempcatgdelete', 'as' => 'tempcatgdelete'])->where('id','[0-9]+');
Route::get('/admin/restorecatg/{id}', ['uses' => 'Admin\CategoryController@restorecatg', 'as' => 'restorecatg'])->where('id','[0-9]+');
Route::get('/admin/permcatgdelete/{id}', ['uses' => 'Admin\CategoryController@permcatgdelete', 'as' => 'permcatgdelete'])->where('id','[0-9]+');
Route::get('/admin/createnewcategory', ['uses' => 'Admin\CategoryController@createnewcategory', 'as' => 'createnewcategory']);
Route::post('/admin/createcategoryprocess', ['uses' => 'Admin\CategoryController@createcategoryprocess', 'as' => 'createcategoryprocess']);
Route::get('/admin/editcategory/{id}', ['uses' => 'Admin\CategoryController@editcategory', 'as' => 'editcategory'])->where('id','[0-9]+');
Route::post('/admin/editcategoryprocess/{id}', ['uses' => 'Admin\CategoryController@editcategoryprocess', 'as' => 'editcategoryprocess'])->where('id','[0-9]+');

// signup process
Route::get('/'.$larasearchblog, ['uses' => 'Front\SearchController@searchblog', 'as' => 'searchblog']);
Route::post('/signupprocess', ['uses' => 'Front\SignupController@signupprocess', 'as' => 'signupprocess']);
Route::post('/contactusprocess', ['uses' => 'Front\ContactController@contactusprocess', 'as' => 'contactusprocess']);


//All Blog pages -No route after this line
Route::get('/blogs', ['uses' => 'Front\BlogController@blogs', 'as' => 'blogs']);
Route::get('/blogs/single/{slug}', ['uses' => 'Front\BlogController@single', 'as' => 'blog']);

//All Pages
Route::get('/'.$larablogctg.'/{slug}', ['uses' => 'Front\PageController@blogcategories', 'as' => 'blogcategory']);
Route::get('/'.$larablogctg.'/{slug}/{lang}', ['uses' => 'Front\PageController@blogcategories', 'as' => 'blogcategory2']);
Route::get('/{slug}', ['uses' => 'Front\PageController@index', 'as' => 'page']);
Route::get('/{slug}/{lang}', ['uses' => 'Front\PageController@index', 'as' => 'page2']);