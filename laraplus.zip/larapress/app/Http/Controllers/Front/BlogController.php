<?php

namespace App\Http\Controllers\Front;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

use App\Http\Requests;
use App\Models\Blog;
use App\Models\Category;
use App\Models\BlogCategory;
use App\Models\Comment;
use Validator;

class BlogController extends Controller
{
    // all blog
	public function blogs()
	{
		$data['settinghelper'] = $settinghelper = allsetting();
        if(Auth::user() && Auth::user()->role < 10 && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }
        else if(!Auth::user() && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }
		$data['data'] = '';                                           //Authentication for All users
        $data['userlevel'] = 0;
        $data['dataerror'] = 0;
        if(Auth::user())
        {
            $data['logged_id'] = Auth::user()->id;
            $data['logged_role'] = Auth::user()->role;
        }
		$data['getelements'] = array(
                'sort' =>''
        );
        foreach($data['getelements'] as $key => $val){
            if ($val == ''){
                unset($data['getelements'][$key]);
            }
        }
        $data['categories'] = Category::where(['trashed' => '0'])->get();
        $data['myposts'] = Blog::where([ 'trashed' => '0', 'archived' => '0'])->orderBy('updated_at', 'desc')->paginate(12)->appends($data['getelements']);
        if(count($data['myposts'])==0)
        {
            $data['dataerror'] = 1;
        }

        $data['webtitle'] = $webtitle = 'Blogs';

        $data['breadcrumb'] = breadcrumb(
            array(
                ['Home','home'],
                [$webtitle,'blogs']
            ),
            $settinghelper['brdcrmb_sep']
        );

		return view('template.' . $settinghelper['template'] . '.blogs',$data);		
	}

	public function single($slug)
	{
		$data['settinghelper'] = $settinghelper = allsetting();
        if(Auth::user() && Auth::user()->role < 10 && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }
        else if(!Auth::user() && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }
        $data['userlevel'] = 0;
        $data['dataerror'] = 0;
        if(Auth::user())
        {
            $data['logged_id'] = Auth::user()->id;
            $data['logged_role'] = Auth::user()->role;
        }
		
		$data['singlepost'] = $data['data'] = Blog::where(['slug'=>$slug,'trashed'=>0,'archived'=>0])->first();
		if(!$data['singlepost'])
		{
            $data['dataerror'] = 1;
		}

        $data['breadcrumb'] = breadcrumb(
            array(
                ['Home','home'],
                ['Blogs','blogs'],
                [$data['data']->name,'blog',['slug'=>$slug]]
            ),
            $settinghelper['brdcrmb_sep']
        );

		return view('template.' . $settinghelper['template'] . '.single',$data);		
	}
}
