<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

use App\Models\Setting;

class TemplateController extends Controller
{
    function template(){
    	if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10){
		    	$data['settinghelper'] = allsetting();
		    	return view('admin.template', $data);
	    	}
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    function changetemplate($name){
    	if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10){
            	$templates = templates();
		    	$settinghelper = allsetting();
            	if(in_array($name, $templates)==true && $settinghelper['template'] != $name){
            		$updated = Setting::where(['slug'=>'template'])->update(['value'=>$name]);
            		if($updated){
            			return redirect()->back()->with(['success'=>'The Template has been changed Successfully']);
            		}
            		else{
            			return redirect()->back()->with(['dissimss'=>'The Template Can not be changed for some reason']);
            		}
            	}
            	else if($settinghelper['template'] == $name){
            		return redirect()->back()->with(['available'=>'The Template is already activated']);
            	}
            	else{
            		return redirect()->back()->with(['dissimss'=>'The Template Can not be changed for some reason']);
            	}

		    	return view('admin.template', $data);
	    	}
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }
}
