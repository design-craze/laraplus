<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\Blog;
use App\Models\Category;
use App\Models\BlogCategory;
use App\Models\comment;
use App\Models\Like;
use App\Models\Media;
use Validator;
use Session;
use Illuminate\Support\Facades\Auth;

class BlogController extends Controller
{
    //ACTIVE BLOGS
    public function bloglist(){
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10){                  //Authentication for Minimum Managers
                $data['logged_id'] = Auth::user()->id;
                $data['logged_role'] = Auth::user()->role;

                $data['getelements'] = array(
                    'sort' =>''
                );
                foreach($data['getelements'] as $key => $val){
                    if ($val == ''){
                        unset($data['getelements'][$key]);
                    }
                }
                $data['pages'] = Blog::where([ 'trashed' => '0', 'archived' => '0'])->orderBy('updated_at', 'desc')->paginate(15)->appends($data['getelements']);

                return view('admin.blog', $data);       
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    public function featureblog($id){
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10){                  //Authentication for Minimum Managers
                $data['logged_id'] = Auth::user()->id;
                $data['logged_role'] = Auth::user()->role;

                $blog = Blog::where(['id' => $id])->first();
                if(isset($blog) && $blog->featured == 0)
                {
                    $blogfeatured = Blog::where(['id' => $id])->update(['featured'=>1]);
                    if($blogfeatured){
                        return redirect()->back()->with(['success'=> 'This Blog Has Been Featured Successfully']);
                    }
                    else{
                        return redirect()->back()->with(['dissmiss'=> 'Fail To Make This Post Featured']);
                    }
                }else{
                    $blogunfeatured = Blog::where(['id' => $id])->update(['featured'=>0]);
                    if($blogunfeatured){
                        return redirect()->back()->with(['success'=> 'This Blog Has Been Unfeatured Successfully']);
                    }
                    else{
                        return redirect()->back()->with(['dissmiss'=> 'Fail To Make This Post Uneatured']);
                    }
                }
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }

        
    }

    //DELETED BLOGS
    public function trashblog()
    {
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10){                  //Authentication for Minimum Managers
                $data['logged_id'] = Auth::user()->id;
                $data['logged_role'] = Auth::user()->role;

                $data['getelements'] = array(
                        'sort' =>''
                );
                foreach($data['getelements'] as $key => $val){
                    if ($val == ''){
                        unset($data['getelements'][$key]);
                    }
                }
                $data['pages'] = Blog::where(['trashed' => '1'])->paginate(15)->appends($data['getelements']);
                return view('admin.trashblog', $data);
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    //ARCHIVED BLOGS
    public function archiveblog()
    {
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10){                  //Authentication for Minimum Managers
                $data['logged_id'] = Auth::user()->id;
                $data['logged_role'] = Auth::user()->role;

                $data['getelements'] = array(
                        'sort' =>''
                );
                foreach($data['getelements'] as $key => $val){
                    if ($val == ''){
                        unset($data['getelements'][$key]);
                    }
                }
                $data['pages'] = Blog::where(['trashed' => '0', 'archived' => '1'])->paginate(15)->appends($data['getelements']);
                return view('admin.archiveblog', $data);

            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    public function tempblogdelete($id, $from){
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10){                  //Authentication for Minimum Managers
                $data['logged_id'] = Auth::user()->id;
                $data['logged_role'] = Auth::user()->role;

                if($from==2){
                    $from = 'blogmanager';
                }
                else{
                    $from = 'archiveblog';
                }
                $page = Blog::where(['id' => $id, 'trashed' => 0])->first();
                if($page){
                    $update = Blog::where('id', $id)->update(['trashed' => 1]);
                    if($update){
                        return redirect()->route($from)->with(['success'=> 'This Blog Has Been Sent To Trash Successfully']);
                    }
                    else{
                        return redirect()->route($from)->with(['dissmiss'=> 'This Blog Can not be Sent to Trash for Some Reasons']);
                    }
                }
                else{
                    return redirect()->route($from)->with(['dissmiss'=> 'This Blog is either already in Trash or unavailable']);
                }
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    public function restoreblog($id){
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10){                  //Authentication for Minimum Managers
                $data['logged_id'] = Auth::user()->id;
                $data['logged_role'] = Auth::user()->role;

                $page = Blog::where(['id' => $id, 'trashed' => 1])->first();
                if($page){
                    $update = Blog::where('id', $id)->update(['trashed' => 0]);
                    if($update){
                        return redirect()->route('trashblog')->with(['success'=> 'This Article Has Been Restored Successfully']);
                    }
                    else{
                        return redirect()->route('trashblog')->with(['dissmiss'=> 'This Article Can not be Restored for Some Reasons']);
                    }
                }
                else{
                    return redirect()->route('trashblog')->with(['dissmiss'=> 'There is no Such Article to Restore']);
                }
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    public function parmblogdelete($id){
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10){                  //Authentication for Minimum Managers
                $data['logged_id'] = Auth::user()->id;
                $data['logged_role'] = Auth::user()->role;

                $page = Blog::where(['id' => $id, 'trashed' => 1])->first();
                if($page){
                    $delete = Blog::where('id', $id)->delete();
                    if($delete){
                        comment::where('blog_id', $id)->delete();
                        Like::where('blog_id', $id)->delete();
                        BlogCategory::where('blog_id', $id)->delete();
                        return redirect()->route('trashblog')->with(['success'=> 'This Blog Has Been Deleted Successfully']);
                    }
                    else{
                        return redirect()->route('trashblog')->with(['dissmiss'=> 'This Blog Can not be deleted for Some Reasons']);
                    }
                }
                else{
                    return redirect()->route('trashblog')->with(['dissmiss'=> 'There is no Such Blog to Delete']);
                }
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }

        
    }

    public function sendblogtoarchive($id){
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10){                  //Authentication for Minimum Managers
                $data['logged_id'] = Auth::user()->id;
                $data['logged_role'] = Auth::user()->role;

                $page = Blog::where(['id' => $id, 'trashed' => 0, 'archived' => 0])->first();
                if($page){
                    $update = Blog::where('id', $id)->update(['archived' => 1]);
                    if($update){
                        return redirect()->route('blogmanager')->with(['success'=> 'This Article Has Been sent to Archive Successfully']);
                    }
                    else{
                        return redirect()->route('blogmanager')->with(['dissmiss'=> 'This Article Can not be sent to Archive for Some Reasons']);
                    }
                }
                else{
                    return redirect()->route('blogmanager')->with(['dissmiss'=> 'There is no Such Article to send to Archive']);
                }
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    public function restorearchiveblog($id){
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10){                  //Authentication for Minimum Managers
                $data['logged_id'] = Auth::user()->id;
                $data['logged_role'] = Auth::user()->role;

                $page = Blog::where(['id' => $id, 'trashed' => 0, 'archived' => 1])->first();
                if($page){
                    $update = Blog::where('id', $id)->update(['archived' => 0]);
                    if($update){
                        return redirect()->route('archiveblog')->with(['success'=> 'This Article Has Been Restored to Live Mode Successfully']);
                    }
                    else{
                        return redirect()->route('archiveblog')->with(['dissmiss'=> 'This Article Can not be Restored to Live Mode for Some Reasons']);
                    }
                }
                else{
                    return redirect()->route('archiveblog')->with(['dissmiss'=> 'There is no Such Article to Restore to Live Mode']);
                }

            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    //Create A blog
    public function newblog(){
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10){                  //Authentication for Minimum Managers
                $data['logged_id'] = Auth::user()->id;
                $data['logged_role'] = Auth::user()->role;

                $data['categories'] = Category::where(['trashed' => '0'])->get();
                $data['mymedia'] = Media::orderBy('id', 'desc')->get();
                return view('admin.newblog', $data);

            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    //Process for New Blog
    protected function blogcreateprocess(Request $request){
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10){                  //Authentication for Minimum Managers
                $data['logged_id'] = Auth::user()->id;
                $data['logged_role'] = Auth::user()->role;

                $rules = [ 
                    'name'=>'required', 
                    'slug'=>'required',
                    'access_level' => 'required|integer|between:-1,'.max(array_keys(role())),
                    'commentable' => 'required|integer|between:0,1',
                    'thumb' => 'max:255'
                    ];
                $messages = [ 
                    'name.required' => 'Fill up Blog Name', 
                    'slug.required'   => 'Fill up slug field.',
                    'access_level.required' => 'Access level is required',
                    'access_level.integer' => 'You have selected a wrong access level',
                    'access_level.between' => 'You have selected a wrong access level',
                    'commentable.required' => 'Active comment Field is required',
                    'commentable.integer' => 'Active Comment must be Yes or No',
                    'commentable.between' => 'Active Comment must be Yes or No',
                    'thumb.max' => 'Thumbnail image path must be less or equal to 255 characters'
                    ];
                    
                $validator = Validator::make($request->all(), $rules, $messages);
                if ($validator->fails()) {
                    return redirect()->back()->withErrors($validator)->withInput();
                }
                else{
                    $slug = cleanslug($request->slug);
                    $finalslug = $slug;
                    for($i=0; $i>-1; $i++){
                        $sameslug = Blog::where('slug', $finalslug)->count();
                        if($sameslug > 0){
                            $finalslug = $slug . '-' . ($i+1);
                        }
                        else{
                            $i= -10;
                        }
                    }
                    $input = $request->except('_token', 'slug', 'category', 'create-blog');
                    // Here need the user ID;
                    $input['slug'] = $finalslug;
                    $input['user_id'] = Auth::user()->id;
                    $inserted = Blog::create($input)->id;
                    if($inserted){
                        if($request->category != null){
                            foreach($request->category as $category){
                                $existedcategory = Category::where('id', $category)->count();
                                if($existedcategory==1){
                                    BlogCategory::create(['blog_id' => $inserted , 'category_id' => $category]);
                                }
                            }
                        }
                        return redirect()->route('editblog', ['id' => $inserted])->with(['success'=> 'Article Has been Created Successfully']);
                    }
                    else{
                        return redirect()->back()->with(['dissmiss'=> 'Article Can not be created for some reason']);
                    }
                }
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    public function editblog($id){
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10){                  //Authentication for Minimum Managers
                $data['logged_id'] = Auth::user()->id;
                $data['logged_role'] = Auth::user()->role;

                $data['singleblog'] = Blog::where(['id' => $id, 'trashed' => 0])->firstOrFail();
                $data['categories'] = Category::where(['trashed' => '0'])->get();
                $data['mymedia'] = Media::orderBy('id', 'desc')->get();
                $a=$data['dbcategory'] = $data['singleblog']->categories;
                return view('admin.editblog',$data);
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    protected function blogeditprocess($id, Request $request){
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10){                  //Authentication for Minimum Managers
                $data['logged_id'] = Auth::user()->id;
                $data['logged_role'] = Auth::user()->role;

                $rules = [ 
                    'name'=>'required', 
                    'slug'=>'required',
                    'access_level' => 'required|integer|between:-1,'.max(array_keys(role())),
                    'commentable' => 'required|integer|between:0,1',
                    'thumb' => 'max:255'
                    ];
                $messages = [ 
                    'name.required' => 'Fill up Blog Name', 
                    'slug.required'   => 'Fill up slug field.',
                    'access_level.required' => 'Access level is required',
                    'access_level.integer' => 'You have selected a wrong access level',
                    'access_level.between' => 'You have selected a wrong access level',
                    'commentable.required' => 'Active comment Field is required',
                    'commentable.integer' => 'Active Comment must be Yes or No',
                    'commentable.between' => 'Active Comment must be Yes or No',
                    'thumb.max' => 'Thumbnail image path must be less or equal to 255 characters'
                    ];
                    
                $validator = Validator::make($request->all(), $rules, $messages);
                if ($validator->fails()) {
                    return redirect()->back()->withErrors($validator)->withInput();
                }
                else
                {
                    $slug = cleanslug($request->slug);
                    $finalslug = $slug;
                    for($i=0; $i>-1; $i++){
                        $sameslug = Blog::where('slug', $finalslug)->first();
                        if(count($sameslug) > 0 && $sameslug->id != $id){
                            $finalslug = $slug . '-' . ($i+1);
                        }
                        else{
                            $i= -10;
                        }
                    }


                    $update = $request->except('_token', 'slug', 'category', 'update');
                    // Here need the user ID;
                    $update['slug'] = $finalslug;
                    $updated = Blog::where('id',$id)->update($update);
                    if($updated){
                        if($request->category != null){
                            $reservedcatgs = BlogCategory::where(['blog_id' => $id])->delete();

                            foreach($request->category as $category){
                                $existedcategory = Category::where('id', $category)->count();
                                if($existedcategory==1){
                                    BlogCategory::create(['blog_id' => $id , 'category_id' => $category]);
                                }
                            }
                        }
                        else{
                            $reservedcatgs = BlogCategory::where(['blog_id' => $id])->delete();
                        }
                        
                        return redirect()->route('editblog', ['id' => $id])->with(['success'=> 'Article Has been Created Successfully']);
                    }
                    else{
                        return redirect()->back()->with(['dissmiss'=> 'Article Can not be created for some reason']);
                    }   
                }

            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }
}
