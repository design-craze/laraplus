<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;

use App\Http\Requests;
use Validator;
use App\Http\Controllers\Controller;

use App\Models\Comment;
use Illuminate\Support\Facades\Auth;

class CommentController extends Controller
{
    public function managecomment()
    {
    	if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
             if(Auth::user()->role >= 10){                      //Authentication for Minimum Managers
                // $data['getelements'] = array(
                //     'sdf' =>''
                // );
                // foreach($data['getelements'] as $key => $val){
                //     if ($val == ''){
                //         unset($data['getelements'][$key]);
                //     }
                // }
                $data['comments'] = Comment::paginate(10);
                //->appends($data['getelements']);
                return view('admin.comments', $data);
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    public function subcomment($id)
    {
    	if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
             if(Auth::user()->role >= 10){                      //Authentication for Minimum Managers
                // $data['getelements'] = array(
                //     'sdf' =>''
                // );
                // foreach($data['getelements'] as $key => $val){
                //     if ($val == ''){
                //         unset($data['getelements'][$key]);
                //     }
                // }
                $data['comments'] = Comment::where('parent_id',$id)->paginate(10);
                //->appends($data['getelements']);
                return view('admin.subcomments', $data);
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    public function commentdelete($id)
    {
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else
        {
            if(Auth::user()->role >= 10)
            {
                
                $delete = Comment::where('id', $id)->orWhere('parent_id',$id)->delete();

                if($delete){
                    return redirect()->back()->with(['success'=>'This Comment Has Been Deleted Successfully.']);
                }
                else{
                    return redirect()->back()->with(['dissmiss'=>'This Comment Can not be deleted for some reason.']);
                }
                   
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    public function commentedit($id)
    {
    	if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10)
            {
                $data['comment'] = Comment::where(['id' => $id])->firstOrFail();
                return view('admin.commentedit',$data);         
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

	public function commenteditprocess($id, Request $request)
    {
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10)
            {
                $rules = [ 
                    'description'=>'required', 
                    'is_approved'=>'required|numeric' 
                    ];
                $messages = [ 
                    'description.required' => 'Fill up Comment Field', 
                    'is_approved.required'   => 'Comment Status Field is required.',
                    'is_approved.numeric'   => 'Comment Status must be a number.'
                    ];
                    
                $validator = Validator::make($request->all(), $rules, $messages);
                if ($validator->fails()) {
                    return redirect()->back()->withErrors($validator)->withInput();
                }
                else {
                    $update = $request->except('_token');
                    $edited = Comment::where('id', $id)->update($update);
                    if($edited){
                        return redirect()->route('commentedit', ['id' => $id])->with(['success'=> 'Comment Has been Edited Successfully']);
                    }
                    else{
                        return redirect()->back()->with(['dissmiss'=> 'Comment Can not be edited for some reason']);
                    }
                }           
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }
}
