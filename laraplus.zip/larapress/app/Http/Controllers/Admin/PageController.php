<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\Page;
use App\Models\Menu;
use App\Models\Menuplace;
use App\Models\Media;
use Validator;
use Illuminate\Support\Facades\Auth;

class PageController extends Controller
{
    //ACTIVE PAGES
    public function pagelist(){
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('home'); 
        }
        else{
             if(Auth::user()->role >= 10){                      //Authentication for Minimum Managers
                $data['getelements'] = array(
                    'sort' =>'',
                    'act' =>''
                );
                foreach($data['getelements'] as $key => $val){
                    if ($val == ''){
                        unset($data['getelements'][$key]);
                    }
                }
                $data['pages'] = Page::where(['lang' => 'en', 'trashed' => '0', 'parent' => '0'])->paginate(15)->appends($data['getelements']);
                return view('admin.page', $data);
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    //MULTIPLE PAGES
    public function multipage($id){
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10){                  //Authentication for Minimum Managers
                $data['logged_id'] = Auth::user()->id;
                $data['logged_role'] = Auth::user()->role;

                $data['getelements'] = array(
                    'sort' =>'',
                    'act' =>''
                );
                foreach($data['getelements'] as $key => $val){
                    if ($val == ''){
                        unset($data['getelements'][$key]);
                    }
                }
                $data['pages'] = Page::where(['id' => $id, 'trashed' => 0])->orWhere(['parent' => $id, 'trashed' => 0])->paginate(15)->appends($data['getelements']);
                return view('admin.multilingual', $data);

            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    //DELETED PAGES
    public function trashpage(){
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10){                  //Authentication for Minimum Managers
                $data['logged_id'] = Auth::user()->id;
                $data['logged_role'] = Auth::user()->role;

                $data['getelements'] = array(
                    'sort' =>'',
                    'act' =>''
                );
                foreach($data['getelements'] as $key => $val){
                    if ($val == ''){
                        unset($data['getelements'][$key]);
                    }
                }
                $data['pages'] = Page::where(['lang' => 'en', 'trashed' => '1', 'parent'=> 0])->paginate(15)->appends($data['getelements']);
                return view('admin.trashpage', $data);

            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    public function temppagedelete($id){
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10){                  //Authentication for Minimum Managers
                $data['logged_id'] = Auth::user()->id;
                $data['logged_role'] = Auth::user()->role;

                $page = Page::where(['id' => $id, 'trashed' => 0, 'home'=> 0, 'parent' => 0])->first();
                if($page){
                    $update = Page::where('id', $id)->update(['trashed' => 1]);
                    if($update){
                        Page::where('parent', $id)->update(['trashed' => 1]);
                        return redirect()->route('pagemanager')->with(['success'=> 'This Page Has Been Sent To Trash Successfully with related multilingual pages']);
                    }
                    else{
                        return redirect()->route('pagemanager')->with(['dissmiss'=> 'This Page Can not be Sent to Trash for Some Reasons']);
                    }
                }
                else{
                    return redirect()->route('pagemanager')->with(['dissmiss'=> 'The page is either set as homepage or There is no Such Page to send to Trash']);
                }
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    public function restorepage($id){
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10){                  //Authentication for Minimum Managers
                $data['logged_id'] = Auth::user()->id;
                $data['logged_role'] = Auth::user()->role;

                $page = Page::where(['id' => $id, 'trashed' => 1, 'parent' =>0])->first();
                if($page){
                    $update = Page::where('id', $id)->update(['trashed' => 0]);
                    if($update){
                        Page::where('parent', $id)->update(['trashed' => 0]);
                        return redirect()->route('trashpage')->with(['success'=> 'This Page Has Been Restored Successfully with related multilingual pages']);
                    }
                    else{
                        return redirect()->route('trashpage')->with(['dissmiss'=> 'This Page Can not be Restored for Some Reasons']);
                    }
                }
                else{
                    return redirect()->route('trashpage')->with(['dissmiss'=> 'There is no Such Page to Restore']);
                }
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    public function parmpagedelete($id){
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10){                  //Authentication for Minimum Managers
                $data['logged_id'] = Auth::user()->id;
                $data['logged_role'] = Auth::user()->role;

                $page = Page::where(['id' => $id, 'trashed' => 1, 'parent'=>0])->first();
                if($page){
                    $delete = Page::where('id', $id)->delete();
                    if($delete){
                        Page::where('parent', $id)->delete();
                        return redirect()->route('trashpage')->with(['success'=> 'This Page Has Been Deleted Successfully with related multilingual pages']);
                    }
                    else{
                        return redirect()->route('trashpage')->with(['dissmiss'=> 'This Page Can not be deleted for Some Reasons']);
                    }
                }
                else{
                    return redirect()->route('trashpage')->with(['dissmiss'=> 'There is no Such Page to Delete']);
                }
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    public function createmultipages($id){
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10){                  //Authentication for Minimum Managers
                $data['logged_id'] = Auth::user()->id;
                $data['logged_role'] = Auth::user()->role;

                $page = Page::where(['id' => $id, 'trashed' => 0, 'parent' =>0])->first();
                if($page){
                    $lang = language();
                    unset($lang['en']);
                    foreach($lang as $key => $val){
                        $child = Page::where(['parent' => $id, 'lang' =>  $key])->first();
                        if(!$child){
                            $create = Page::create(['slug'=> $page->slug, 'name' => $page->name, 'parent' => $id, 'lang' =>  $key]);
                        }
                    }
                    return redirect()->route('pagemanager')->with(['success'=> 'Related Multilingual Pages have been Created Successfully']);
                }
                else{
                    return redirect()->route('pagemanager')->with(['dissmiss'=> 'Related Multilingual Pages Can not be Created for the requested page']);
                }

            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    public function changehomepage($id){
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10){                  //Authentication for Minimum Managers
                $data['logged_id'] = Auth::user()->id;
                $data['logged_role'] = Auth::user()->role;

                $page = Page::where(['id' => $id, 'trashed' => 0, 'parent' =>0, 'home' => 0])->first();
                if($page)
                {
                    $home = Page::where(['home' => 1, 'trashed' => 0, 'parent' =>0])->first();
                    if($home)
                    {
                        $oldhome = Page::where(['home' => 1, 'trashed' => 0, 'parent' =>0])->update(['home' => 0]);
                        if($oldhome)
                        {
                            $newhome = Page::where('id', $id)->update(['home' => 1]);
                            if($newhome)
                            {
                                return redirect()->route('pagemanager')->with(['success'=> 'Selected Page Has been turned to Home Page Successfully']);
                            }
                            else
                            {
                                return redirect()->route('pagemanager')->with(['dissmiss'=> 'Selected Page Can Not be turned to Home Page For some Reason']);
                            }
                        }
                        else
                        {
                            return redirect()->route('pagemanager')->with(['dissmiss'=> 'Current Home Page Can Not be turned Off For some Reason']);
                        }
                    }
                    else
                    {
                        $newhome = Page::where('id', $id)->update(['home' => 1]);
                        if($newhome)
                        {
                            return redirect()->route('pagemanager')->with(['success'=> 'Selected Page Has been turned to Home Page Successfully']);
                        }
                        else
                        {
                            return redirect()->route('pagemanager')->with(['dissmiss'=> 'Selected Page Can Not be turned to Home Page For some Reason']);
                        }
                    }
                    
                }
                else
                {
                    return redirect()->route('pagemanager')->with(['dissmiss'=> 'Either This page is home page or The page cannot be changed to Home Page']);
                }

            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    //CREATE A PAGE
    public function newpage(){
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10){                  //Authentication for Minimum Managers
                $data['logged_id'] = Auth::user()->id;
                $data['logged_role'] = Auth::user()->role;

                $data['menu'] = Menu::get();
                $data['menuplace'] = Menuplace::get();
                $data['mymedia'] = Media::orderBy('id', 'desc')->get();
                return view('admin.newpage',$data);
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    protected function pagecreateprocess(Request $request){
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10){                 //Authentication for Minimum Managers
                $data['logged_id'] = Auth::user()->id;
                $data['logged_role'] = Auth::user()->role;

                $rules = [ 
                    'name'=>'required|max:255', 
                    'slug'=>'required|max:255', 
                    'metatitle'=>'max:155',
                    'metadesc'=>'max:155',
                    'template'=>'required|max:255|in:'.arrayvalidation(pagetemplates()),
                    'access_level'=>'required|integer|between:-1,'.(count(role())-2),
                    'header'=>'required|in:-1,0,1',
                    'hdrlayout'=>'required|in:-1,1,2',
                    'title'=>'required|in:-1,0,1',
                    'titlelayout'=>'required|in:-1,1,2',
                    'breadcrumbs'=>'required|in:-1,1,2',
                    'layout'=>'required|in:-1,0,1',
                    'bodystyle'=>'required|in:-1,1,2',
                    'leftside'=>'required|max:255|in:'.arrayvalidation(widget_area(), 'default,none,'),
                    'rightside'=>'required|max:255|in:'.arrayvalidation(widget_area(), 'default,none,'),
                    'ftrlayout'=>'required|in:-1,1,2',
                    'ftrwid'=>'required|in:-1,0,1,2,3,4',
                    'btmftr'=>'required|in:-1,0,1'
                ];
                $messages = [ 
                    'name.required' => 'Name is required', 
                    'name.max' => 'Name must be less than 255 characters',
                    'slug.required' => 'Slug is required', 
                    'slug.max' => 'Slug must be less than 255 characters', 
                    'metatitle.max' => 'Metatitle must be less than 155 characters', 
                    'metadesc.max' => 'Metadesc must be less than 155 characters', 
                    'template.required' => 'Invalide Template is Selected', 
                    'template.max' => 'Invalide Template is Selected', 
                    'template.in' => 'Invalide Template is Selected', 
                    'access_level.required' => 'Invalide Access level is Selected', 
                    'access_level.integer' => 'Invalide Access level is Selected', 
                    'access_level.max' => 'Invalide Access Level is Selected',
                    'header.required' => 'Invalide Header is Selected', 
                    'header.in' => 'Invalide Header is Selected',
                    'hdrlayout.required' => 'Invalide Header Layout is Selected', 
                    'hdrlayout.in' => 'Invalide Header Layout is Selected',
                    'title.required' => 'Invalide Title is Selected', 
                    'title.in' => 'Invalide Title is Selected',
                    'titlelayout.required' => 'Invalide Title Layout is Selected', 
                    'titlelayout.in' => 'Invalide Title Layout is Selected',
                    'breadcrumbs.required' => 'Invalide Breadcrumbs is Selected', 
                    'breadcrumbs.in' => 'Invalide Breadcrumbs is Selected',
                    'layout.required' => 'Invalide Layout is Selected', 
                    'layout.in' => 'Invalide Layout is Selected',
                    'bodystyle.required' => 'Invalide Body Style is Selected', 
                    'bodystyle.in' => 'Invalide Body Style is Selected',
                    'leftside.required' => 'Invalide Left Side bar is Selected', 
                    'leftside.max' => 'Invalide Left Side bar is Selected', 
                    'leftside.in' => 'Invalide Left Side bar is Selected',
                    'rightside.required' => 'Invalide Right Side bar is Selected', 
                    'rightside.max' => 'Invalide Right Side bar is Selected', 
                    'rightside.in' => 'Invalide Right Side bar is Selected',
                    'ftrlayout.required' => 'Invalide Footer Layour is Selected', 
                    'ftrlayout.in' => 'Invalide Footer Layour is Selected',
                    'ftrwid.required' => 'Invalide Footer Widget is Selected', 
                    'ftrwid.in' => 'Invalide Footer Widget is Selected',
                    'btmftr.required' => 'Invalide Bottom Footer is Selected', 
                    'btmftr.in' => 'Invalide Bottom Footer is Selected',
                ];
                    
                $validator = Validator::make($request->all(), $rules, $messages);
                if ($validator->fails()) {
                    return redirect()->route('newpage')->withErrors($validator)->withInput();
                }
                else {
                    $slug = cleanslug($request->slug);
                    $finalslug = $slug;
                    for($i=0; $i>-1; $i++){
                        $sameslug = Page::where('slug', $finalslug)->count();
                        if($sameslug > 0){
                            $finalslug = $slug . '-' . ($i+1);
                        }
                        else{
                            $i= -10;
                        }
                    }
                    $input = $request->except('_token', 'slug');
                    $input['slug'] = $finalslug;
                    $inserted = Page::create($input)->id;
                    if($inserted){
                        return redirect()->route('editpage', ['id' => $inserted])->with(['success'=> 'Page Has been Created Successfully']);
                    }
                    else{
                        return redirect()->route('newpage')->with(['dissmiss'=> 'Page Can not be created for some reason']);
                    }
                }

            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    public function editpage($id){

        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10){                  //Authentication for Minimum Managers
                $data['logged_id'] = Auth::user()->id;
                $data['logged_role'] = Auth::user()->role;

                $data['menu'] = Menu::get();
                $data['menuplace'] = Menuplace::get();
                $data['singlepage'] = page::where(['id' => $id, 'trashed' => 0])->firstOrFail();
                $data['mymedia'] = Media::orderBy('id', 'desc')->get();
                return view('admin.editpage',$data);

            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    protected function pageeditprocess($id, Request $request){

        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10){                  //Authentication for Minimum Managers
                $data['logged_id'] = Auth::user()->id;
                $data['logged_role'] = Auth::user()->role;


                $rules = [ 
                    'name'=>'required|max:255', 
                    'slug'=>'required|max:255', 
                    'metatitle'=>'max:155',
                    'metadesc'=>'max:155',
                    'template'=>'required|max:255|in:'.arrayvalidation(pagetemplates()),
                    'access_level'=>'required|integer|between:-1,'.(count(role())-2),
                    'header'=>'required|in:-1,0,1',
                    'hdrlayout'=>'required|in:-1,1,2',
                    'title'=>'required|in:-1,0,1',
                    'titlelayout'=>'required|in:-1,1,2',
                    'breadcrumbs'=>'required|in:-1,1,2',
                    'layout'=>'required|in:-1,0,1',
                    'bodystyle'=>'required|in:-1,1,2',
                    'leftside'=>'required|max:255|in:'.arrayvalidation(widget_area(), 'default,none,'),
                    'rightside'=>'required|max:255|in:'.arrayvalidation(widget_area(), 'default,none,'),
                    'ftrlayout'=>'required|in:-1,1,2',
                    'ftrwid'=>'required|in:-1,0,1,2,3,4',
                    'btmftr'=>'required|in:-1,0,1'
                ];
                $messages = [ 
                    'name.required' => 'Name is required', 
                    'name.max' => 'Name must be less than 255 characters',
                    'slug.required' => 'Slug is required', 
                    'slug.max' => 'Slug must be less than 255 characters', 
                    'metatitle.max' => 'Metatitle must be less than 155 characters', 
                    'metadesc.max' => 'Metadesc must be less than 155 characters', 
                    'template.required' => 'Invalide Template is Selected', 
                    'template.max' => 'Invalide Template is Selected', 
                    'template.in' => 'Invalide Template is Selected', 
                    'access_level.required' => 'Invalide Access level is Selected', 
                    'access_level.integer' => 'Invalide Access level is Selected', 
                    'access_level.max' => 'Invalide Access Level is Selected',
                    'header.required' => 'Invalide Header is Selected', 
                    'header.in' => 'Invalide Header is Selected',
                    'hdrlayout.required' => 'Invalide Header Layout is Selected', 
                    'hdrlayout.in' => 'Invalide Header Layout is Selected',
                    'title.required' => 'Invalide Title is Selected', 
                    'title.in' => 'Invalide Title is Selected',
                    'titlelayout.required' => 'Invalide Title Layout is Selected', 
                    'titlelayout.in' => 'Invalide Title Layout is Selected',
                    'breadcrumbs.required' => 'Invalide Breadcrumbs is Selected', 
                    'breadcrumbs.in' => 'Invalide Breadcrumbs is Selected',
                    'layout.required' => 'Invalide Layout is Selected', 
                    'layout.in' => 'Invalide Layout is Selected',
                    'bodystyle.required' => 'Invalide Body Style is Selected', 
                    'bodystyle.in' => 'Invalide Body Style is Selected',
                    'leftside.required' => 'Invalide Left Side bar is Selected', 
                    'leftside.max' => 'Invalide Left Side bar is Selected', 
                    'leftside.in' => 'Invalide Left Side bar is Selected',
                    'rightside.required' => 'Invalide Right Side bar is Selected', 
                    'rightside.max' => 'Invalide Right Side bar is Selected', 
                    'rightside.in' => 'Invalide Right Side bar is Selected',
                    'ftrlayout.required' => 'Invalide Footer Layour is Selected', 
                    'ftrlayout.in' => 'Invalide Footer Layour is Selected',
                    'ftrwid.required' => 'Invalide Footer Widget is Selected', 
                    'ftrwid.in' => 'Invalide Footer Widget is Selected',
                    'btmftr.required' => 'Invalide Bottom Footer is Selected', 
                    'btmftr.in' => 'Invalide Bottom Footer is Selected',
                ];
                    
                $validator = Validator::make($request->all(), $rules, $messages);
                if ($validator->fails()) {
                    return redirect()->back()->withErrors($validator)->withInput();
                }
                else {
                    if($request->slug!=null){
                        $slug = cleanslug($request->slug);
                        $finalslug = $slug;
                        for($i=0; $i>-1; $i++){
                            $sameslug = Page::where(array(['slug', '=', $finalslug], ['parent', '=', 0], ['id', '!=', $id]))->count();
                            if($sameslug > 0){
                                $finalslug = $slug . '-' . ($i+1);
                            }
                            else{
                                $i= -10;
                            }
                        }
                    }
                    $update = $request->except('_token', 'slug');
                    if($request->slug!=null){
                        $update['slug'] = $finalslug;
                    }
                    $edited = Page::where('id', $id)->update($update);
                    if($edited){
                        if($request->slug!=null){
                            $child = Page::where('parent', $id)->get();
                            if($child){
                                foreach($child as $element){
                                    Page::where('id', $element->id)->update(array('slug' => $finalslug));
                                }
                            }
                        }
                        return redirect()->route('editpage', ['id' => $id])->with(['success'=> 'Page Has been Edited Successfully']);
                    }
                    else{
                        return redirect()->route('newpage')->with(['dissmiss'=> 'Page Can not be edited for some reason']);
                    }
                }
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }
}
