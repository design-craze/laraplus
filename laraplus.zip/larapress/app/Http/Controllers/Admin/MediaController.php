<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Models\Media;
use Intervention\Image\ImageManagerStatic as Image;
use File;

class MediaController extends Controller
{
    public function mediaupload(){
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else
        {
            if(Auth::user()->role >= 10){
                // code goes here.
               return view('admin.mediaupload');
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    public function mediauploadprocess(Request $request){
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else
        {
            if(Auth::user()->role >= 10){
                // code goes here.
                $file = $request->file('file');

                $filepath = path_images();
                $filename = uniqid() . '.' . $file->getClientOriginalExtension();
                $extension  = $file->getClientOriginalExtension();
                $userid = Auth::user()->id;

                $fileuploaded = $file->move(path_images(), $filename);
                if($fileuploaded){
                    $img = Image::make($filepath.$filename);
                    $img->fit(160);
                    $img->crop(120, 120, 20, 20);
                    $img->save(path_thumbs().$filename);

                    $input = array(
                        'filepath' => $filepath,
                        'filename' => $filename,
                        'extension' => $extension,
                        'user_id' => $userid
                    );

                    $inserted= Media::create($input);
                    return $inserted;
                }
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    public function mediamanager(){
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else
        {
            if(Auth::user()->role >= 10){
                // code goes here.
                    $data['media'] = Media::paginate(15);
                    return view('admin.media', $data);
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    public function mediadelete($id){
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else
        {
            if(Auth::user()->role >= 10){
                // code goes here.
                $media = Media::where('id', $id)->first();
                if($media){
                    File::delete($media->filepath.$media->filename, $media->filepath.'thumbs/'.$media->filename);
                    $delete = Media::where('id', $id)->delete();
                    if($delete){
                        return redirect()->back()->with(['success'=> 'The media item Has Been Deleted Successfully']);
                    }
                    else{
                        return redirect()->back()->with(['dissmiss'=> 'The media item can not Be Deleted for some reason']);
                    }
                }
                else{
                    return redirect()->back()->with(['dissmiss'=> 'There is no such item to delete']);
                }
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }
}
