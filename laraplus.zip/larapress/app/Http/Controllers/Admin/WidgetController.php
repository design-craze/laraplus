<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\Widget;
use App\Models\Menu;
use Illuminate\Support\Facades\Auth;

class WidgetController extends Controller
{
    public function widget(){
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10){                  //Authentication for Minimum Managers
                $data['logged_id'] = Auth::user()->id;
                $data['logged_role'] = Auth::user()->role;

                $data['menu'] = Menu::get();
                $data['data'] = Widget::orderBy('serial', 'asc')->get();

                return view('admin.widget',$data);
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    protected function widgetsave(Request $request){
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10){                  //Authentication for Minimum Managers
                $data['logged_id'] = Auth::user()->id;
                $data['logged_role'] = Auth::user()->role;

                $mysign = '<>';
                if($request->savewid!=null){
                    $inputid=explode($mysign,$request->inputid);
                    $inputslug=explode($mysign,$request->inputslug);
                    $inputwidslug=explode($mysign,$request->inputwidslug);
                    $inputtype=explode($mysign,$request->inputtype);
                    $inputname=explode($mysign,$request->inputname);
                    $inputcontent=explode($mysign,$request->inputcontent);
                    $inputserial=explode($mysign,$request->inputserial);
                    $inputdisabled=explode($mysign,$request->inputdisabled);
                    $inputdelete=explode($mysign,$request->inputdelete);
                    $count = count($inputid);
                    // checkpre($myserial);
                    if(count($inputslug)==$count && count($inputwidslug)==$count && count($inputtype)==$count && count($inputname)==$count && count($inputcontent)==$count && count($inputserial)==$count && count($inputdisabled)==$count){
                        for($i=0; $i<$count; $i++){
                            $data= array(
                                'slug'=>$inputslug[$i],
                                'widget_slug'=>$inputwidslug[$i],
                                'type'=>$inputtype[$i],
                                'name'=>$inputname[$i],
                                'content'=>$inputcontent[$i],
                                'serial'=>$inputserial[$i],
                                'disabled'=>$inputdisabled[$i]
                            );

                            if($inputid[$i] !=''){
                                Widget::where('id', $inputid[$i])->update($data);
                            }else{
                                Widget::create($data);
                            }
                        }
                        foreach($inputdelete as $id){
                            Widget::where('id', $id)->delete();
                        }
                        return redirect()->back()->with(['success'=> 'Your Widgets have been saved successfully']);
                    }
                    else{
                        return redirect()->back()->with(['dissmiss'=> 'Some or all of your Widgets can not be saved for some reason']);
                    }
                }
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }
}
