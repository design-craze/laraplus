<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\Page;
use App\Models\Setting;
use Illuminate\Support\Facades\Auth;
use Intervention\Image\ImageManagerStatic as Image;
use Illuminate\Support\Facades\Input;
use File;

class SettingController extends Controller
{
    public function setting(){
    	if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10){                  //Authentication for Minimum Managers
                $data['logged_id'] = Auth::user()->id;
                $data['logged_role'] = Auth::user()->role;

                $data['pages'] = Page::where('trashed', 0)->get();
		    	$data['data'] = Setting::get();
		    	return view('admin.setting', $data);
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    public function settingprocess(Request $request){
    	if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10){                  //Authentication for Minimum Managers

                $data = Setting::get();
		    	foreach($data as $item){
		    		if($item->slug == 'site_name' && $item->value != $request->site_name){
						Setting::where('slug', 'site_name')->update(['value' => trim($request->site_name)]);
					}
					elseif ($item->slug == 'logo_img' && $item->value != $request->logo_img && !empty($request->logo_img) && $request->logo_img != null) {
						// saving image in target path
						$favImg = $request->logo_img;
						$favPath = path_logo();
						
						$uplodImage = uploadimage($favImg,$favPath);

						if($uplodImage != false)
						{
							// saving image in database
							Setting::where('slug', 'logo_img')->update(['value' => $uplodImage]);
						}
					}
					elseif ($item->slug == 'favicon' && $item->value != $request->favicon && !empty($request->favicon) && $request->favicon != null) {
						// saving image in target path
						$favImg = $request->favicon;
						$favPath = path_favicon();

						$uplodImage = uploadimage($favImg,$favPath,32,32);

						if($uplodImage != false)
						{
							// saving image in database
							Setting::where('slug', 'favicon')->update(['value' => $uplodImage]);
						}
					}
					elseif ($item->slug == 'logo_type' && $item->value != $request->logo_type) {
						if($request->logo_type==1 || $request->logo_type==2){
							Setting::where('slug', 'logo_type')->update(['value' => $request->logo_type]);
						}
					}
					elseif ($item->slug == 'primary_phone' && $item->value != $request->primary_phone) {
						Setting::where('slug', 'primary_phone')->update(['value' => trim($request->primary_phone)]);
					}
					elseif ($item->slug == 'primary_email' && $item->value != $request->primary_email && (filter_var($request->primary_email, FILTER_VALIDATE_EMAIL) == true)) {
						Setting::where('slug', 'primary_email')->update(['value' => $request->primary_email]);
					}
					elseif ($item->slug == 'signable' && $item->value != $request->signable) {
						$newsignable = '';
						$mysign = '';
						foreach($request->signable as $signable)
						{
							$newsignable .= $mysign . $signable;
							$mysign = ',';
						}
						Setting::where('slug', 'signable')->update(['value' => $newsignable]);
					}
					elseif ($item->slug == 'web_status' && $item->value != $request->web_status) {
						if($request->web_status==1 || $request->web_status==2 || $request->web_status==3){
							Setting::where('slug', 'web_status')->update(['value' => $request->web_status]);
						}
					}
					elseif ($item->slug == 'page_header' && $item->value != $request->page_header) {
						if($request->page_header=='1' || $request->page_header=='0'){
							Setting::where('slug', 'page_header')->update(['value' => $request->page_header]);
						}
					}
					elseif ($item->slug == 'header_layout' && $item->value != $request->header_layout) {
						if($request->header_layout=='1' || $request->header_layout=='2'){
							Setting::where('slug', 'header_layout')->update(['value' => $request->header_layout]);
						}
					}
					elseif ($item->slug == 'page_title' && $item->value != $request->page_title) {
						if($request->page_title=='1' || $request->page_title=='0'){
							Setting::where('slug', 'page_title')->update(['value' => $request->page_title]);
						}
					}
					elseif ($item->slug == 'title_layout' && $item->value != $request->title_layout) {
						if($request->title_layout=='1' || $request->title_layout=='2'){
							Setting::where('slug', 'title_layout')->update(['value' => $request->title_layout]);
						}
					}
					elseif ($item->slug == 'breadcrumbs' && $item->value != $request->breadcrumbs) {
						if($request->breadcrumbs=='1' || $request->breadcrumbs=='2'){
							Setting::where('slug', 'breadcrumbs')->update(['value' => $request->breadcrumbs]);
						}
					}
					elseif ($item->slug == 'brdcrmb_sep' && $item->value != $request->brdcrmb_sep) {
						Setting::where('slug', 'brdcrmb_sep')->update(['value' => trim($request->brdcrmb_sep)]);
					}
					elseif ($item->slug == 'body_layout' && $item->value != $request->body_layout) {
						if($request->body_layout=='1' || $request->body_layout=='2'){
							Setting::where('slug', 'body_layout')->update(['value' => $request->body_layout]);
						}
					}
					elseif ($item->slug == 'footer_layout' && $item->value != $request->footer_layout) {
						if($request->footer_layout=='1' || $request->footer_layout=='2'){
							Setting::where('slug', 'footer_layout')->update(['value' => $request->footer_layout]);
						}
					}
					elseif ($item->slug == 'footer' && $item->value != $request->footer) {
						if($request->footer=='4' || $request->footer=='3' || $request->footer=='2' || $request->footer=='1' || $request->footer=='0'){
							Setting::where('slug', 'footer')->update(['value' => $request->footer]);
						}
					}
					elseif ($item->slug == 'bottom_footer' && $item->value != $request->bottom_footer) {
						if($request->bottom_footer=='1' || $request->bottom_footer=='0'){
							Setting::where('slug', 'bottom_footer')->update(['value' => $request->bottom_footer]);
						}
					}
					elseif ($item->slug == 'copyright_text' && $item->value != $request->copyright_text) {
						Setting::where('slug', 'copyright_text')->update(['value' => trim($request->copyright_text)]);
					}
					elseif ($item->slug == 'page_leftsidebar' && $item->value != $request->page_leftsidebar) {
						Setting::where('slug', 'page_leftsidebar')->update(['value' => $request->page_leftsidebar]);
					}
					elseif ($item->slug == 'page_rightsidebar' && $item->value != $request->page_rightsidebar) {
						Setting::where('slug', 'page_rightsidebar')->update(['value' => $request->page_rightsidebar]);
					}
					elseif ($item->slug == 'page_layout' && $item->value != $request->page_layout) {
						if($request->page_layout=='1' || $request->page_layout=='0'){
							Setting::where('slug', 'page_layout')->update(['value' => $request->page_layout]);
						}
					}			
					elseif ($item->slug == 'blog_leftsidebar' && $item->value != $request->blog_leftsidebar) {
						Setting::where('slug', 'blog_leftsidebar')->update(['value' => $request->blog_leftsidebar]);
					}
					elseif ($item->slug == 'blog_rightsidebar' && $item->value != $request->blog_rightsidebar) {
						Setting::where('slug', 'blog_rightsidebar')->update(['value' => $request->blog_rightsidebar]);
					}
					elseif ($item->slug == 'blog_layout' && $item->value != $request->blog_layout) {
						if($request->blog_layout==1 || $request->blog_layout==0){
							Setting::where('slug', 'blog_layout')->update(['value' => $request->blog_layout]);
						}
					}
					elseif ($item->slug == 'login_page' && $item->value != $request->login_page && ctype_digit($request->login_page)) {
						Setting::where('slug', 'login_page')->update(['value' => $request->login_page]);
					}
					elseif ($item->slug == 'signup_page' && $item->value != $request->signup_page && ctype_digit($request->signup_page)) {
						Setting::where('slug', 'signup_page')->update(['value' => $request->signup_page]);
					}
					elseif ($item->slug == 'identify_page' && $item->value != $request->identify_page && ctype_digit($request->identify_page)) {
						Setting::where('slug', 'identify_page')->update(['value' => $request->identify_page]);
					}
					elseif ($item->slug == 'coming_soon' && $item->value != $request->coming_soon && ctype_digit($request->coming_soon)) {
						Setting::where('slug', 'coming_soon')->update(['value' => $request->coming_soon]);
					}
					elseif ($item->slug == 'under_dev' && $item->value != $request->under_dev && ctype_digit($request->under_dev)) {
						Setting::where('slug', 'under_dev')->update(['value' => $request->under_dev]);
					}
					elseif ($item->slug == 'search_page' && $item->value != $request->search_page && ctype_digit($request->search_page)) {
						Setting::where('slug', 'search_page')->update(['value' => $request->search_page]);
					}
					elseif ($item->slug == 'blogctg_page' && $item->value != $request->blogctg_page && ctype_digit($request->blogctg_page)) {
						Setting::where('slug', 'blogctg_page')->update(['value' => $request->blogctg_page]);
					}
					elseif ($item->slug == 'facebook' && $item->value != $request->facebook) {
						Setting::where('slug', 'facebook')->update(['value' => trim($request->facebook)]);
					}
					elseif ($item->slug == 'twitter' && $item->value != $request->twitter) {
						Setting::where('slug', 'twitter')->update(['value' => trim($request->twitter)]);
					}
					elseif ($item->slug == 'linkedin' && $item->value != $request->linkedin) {
						Setting::where('slug', 'linkedin')->update(['value' => trim($request->linkedin)]);
					}
					elseif ($item->slug == 'google' && $item->value != $request->google) {
						Setting::where('slug', 'google')->update(['value' => trim($request->google)]);
					}
					elseif ($item->slug == 'skype' && $item->value != $request->skype) {
						Setting::where('slug', 'skype')->update(['value' => trim($request->skype)]);
					}
					elseif ($item->slug == 'youtube' && $item->value != $request->youtube) {
						Setting::where('slug', 'youtube')->update(['value' => trim($request->youtube)]);
					}
					elseif ($item->slug == 'vimeo' && $item->value != $request->vimeo) {
						Setting::where('slug', 'vimeo')->update(['value' => trim($request->vimeo)]);
					}
					elseif ($item->slug == 'pinterest' && $item->value != $request->pinterest) {
						Setting::where('slug', 'pinterest')->update(['value' => trim($request->pinterest)]);
					}
					elseif ($item->slug == 'flickr' && $item->value != $request->flickr) {
						Setting::where('slug', 'flickr')->update(['value' => trim($request->flickr)]);
					}
					elseif ($item->slug == 'instagram' && $item->value != $request->instagram) {
						Setting::where('slug', 'instagram')->update(['value' => trim($request->instagram)]);
					}
					elseif ($item->slug == 'rss' && $item->value != $request->rss) {
						Setting::where('slug', 'rss')->update(['value' => trim($request->rss)]);
					}
					elseif ($item->slug == 'contact_email' && $item->value != $request->contact_email && (filter_var($request->contact_email, FILTER_VALIDATE_EMAIL) == true)) {
						Setting::where('slug', 'contact_email')->update(['value' => $request->contact_email]);
					}
					elseif ($item->slug == 'contact_phone' && $item->value != $request->contact_phone) {
						Setting::where('slug', 'contact_phone')->update(['value' => trim($request->contact_phone)]);
					}
					elseif ($item->slug == 'contact_company' && $item->value != $request->contact_company) {
						Setting::where('slug', 'contact_company')->update(['value' => trim($request->contact_company)]);
					}
					elseif ($item->slug == 'contact_address' && $item->value != $request->contact_address) {
							Setting::where('slug', 'contact_address')->update(['value' => trim($request->contact_address)]);
					}
					elseif ($item->slug == 'contact_map' && $item->value != $request->contact_map) {
						if($request->contact_map==1 || $request->contact_map==2){
						Setting::where('slug', 'contact_map')->update(['value' => $request->contact_map]);
						}
					}
					elseif ($item->slug == 'contact_latlong' && $item->value != $request->contact_latlong) {
						Setting::where('slug', 'contact_latlong')->update(['value' => trim($request->contact_latlong)]);
					}
					elseif ($item->slug == 'contact_map_show_by' && $item->value != $request->contact_map_show_by) {
						if($request->contact_map_show_by==1 || $request->contact_map_show_by==2){
							Setting::where('slug', 'contact_map_show_by')->update(['value' => $request->contact_map_show_by]);
						}
					}
					elseif ($item->slug == 'google_map_zoom' && $item->value != $request->google_map_zoom && $request->google_map_zoom > 0 && $request->google_map_zoom <= 23 && ctype_digit($request->google_map_zoom)) {
						Setting::where('slug', 'google_map_zoom')->update(['value' => $request->google_map_zoom]);
					}
					elseif ($item->slug == 'google_map_type' && $item->value != $request->google_map_type && $request->google_map_type > 0 && $request->google_map_type <= count(google_map_type()) && ctype_digit($request->google_map_type)) {
						Setting::where('slug', 'google_map_type')->update(['value' => $request->google_map_type]);
					}
					elseif ($item->slug == 'google_map_marker_show' && $item->value != $request->google_map_marker_show && $request->google_map_marker_show > 0 && $request->google_map_marker_show <= 2 && ctype_digit($request->google_map_marker_show)) {
						Setting::where('slug', 'google_map_marker_show')->update(['value' => $request->google_map_marker_show]);
					}elseif ($item->slug == 'google_mark_icon' && $item->value != $request->google_mark_icon) {
						Setting::where('slug', 'google_mark_icon')->update(['value' => trim($request->google_mark_icon)]);
					}
					elseif ($item->slug == 'custom_css' && $item->value != $request->custom_css) {
						Setting::where('slug', 'custom_css')->update(['value' => $request->custom_css]);
					}
					elseif ($item->slug == 'large_min_css' && $item->value != $request->large_min_css) {
						Setting::where('slug', 'large_min_css')->update(['value' => $request->large_min_css]);
					}
					elseif ($item->slug == 'large_max_css' && $item->value != $request->large_max_css) {
						Setting::where('slug', 'large_max_css')->update(['value' => $request->large_max_css]);
					}
					elseif ($item->slug == 'medium_min_css' && $item->value != $request->medium_min_css) {
						Setting::where('slug', 'medium_min_css')->update(['value' => $request->medium_min_css]);
					}
					elseif ($item->slug == 'medium_max_css' && $item->value != $request->medium_max_css) {
						Setting::where('slug', 'medium_max_css')->update(['value' => $request->medium_max_css]);
					}
					elseif ($item->slug == 'small_min_css' && $item->value != $request->small_min_css) {
						Setting::where('slug', 'small_min_css')->update(['value' => $request->small_min_css]);
					}
					elseif ($item->slug == 'small_max_css' && $item->value != $request->small_max_css) {
						Setting::where('slug', 'small_max_css')->update(['value' => $request->small_max_css]);
					}
					elseif ($item->slug == 'user_css' && $item->value != $request->user_css) {
						Setting::where('slug', 'user_css')->update(['value' => $request->user_css]);
					}
					elseif ($item->slug == 'guest_css' && $item->value != $request->guest_css) {
						Setting::where('slug', 'guest_css')->update(['value' => $request->guest_css]);
					}
					elseif ($item->slug == 'custom_js' && $item->value != $request->custom_js) {
						Setting::where('slug', 'custom_js')->update(['value' => $request->custom_js]);
					}
					elseif ($item->slug == 'meta_title' && $item->value != $request->meta_title) {
						Setting::where('slug', 'meta_title')->update(['value' => trim($request->meta_title)]);
					}
					elseif ($item->slug == 'meta_tag' && $item->value != $request->meta_tag) {
						Setting::where('slug', 'meta_tag')->update(['value' => trim($request->meta_tag)]);
					}
					elseif ($item->slug == 'meta_desc' && $item->value != $request->meta_desc) {
						Setting::where('slug', 'meta_desc')->update(['value' => trim($request->meta_desc)]);
					}
					elseif ($item->slug == 'google_vf_code' && $item->value != $request->google_vf_code) {
						Setting::where('slug', 'google_vf_code')->update(['value' => $request->google_vf_code]);
					}
					elseif ($item->slug == 'large_breakpoint' && $item->value != $request->large_breakpoint && ctype_digit($request->large_breakpoint)) {
						Setting::where('slug', 'large_breakpoint')->update(['value' => $request->large_breakpoint]);
					}
					elseif ($item->slug == 'medium_breakpoint' && $item->value != $request->medium_breakpoint && ctype_digit($request->medium_breakpoint)) {
						Setting::where('slug', 'medium_breakpoint')->update(['value' => $request->medium_breakpoint]);
					}
					elseif ($item->slug == 'small_breakpoint' && $item->value != $request->small_breakpoint && ctype_digit($request->small_breakpoint)) {
						Setting::where('slug', 'small_breakpoint')->update(['value' => $request->small_breakpoint]);
					}
					elseif ($item->slug == 'container_width_lg' && $item->value != $request->container_width_lg && ctype_digit($request->container_width_lg)) {
						Setting::where('slug', 'container_width_lg')->update(['value' => $request->container_width_lg]);
					}
					elseif ($item->slug == 'container_width_md' && $item->value != $request->container_width_md && ctype_digit($request->container_width_md)) {
						Setting::where('slug', 'container_width_md')->update(['value' => $request->container_width_md]);
					}
					elseif ($item->slug == 'container_width_sm' && $item->value != $request->container_width_sm && ctype_digit($request->container_width_sm)) {
						Setting::where('slug', 'container_width_sm')->update(['value' => $request->container_width_sm]);
					}
					elseif ($item->slug == 'mobile_breakpoint' && $item->value != $request->mobile_breakpoint && ctype_digit($request->mobile_breakpoint)) {
						Setting::where('slug', 'mobile_breakpoint')->update(['value' => $request->mobile_breakpoint]);
					}
					elseif ($item->slug == 'menu_type' && $item->value != $request->menu_type) {
						if($request->menu_type=='classic' || $request->menu_type=='modern'){
							Setting::where('slug', 'menu_type')->update(['value' => $request->menu_type]);
						}
					}
					elseif ($item->slug == 'classic_menutext' && $item->value != $request->classic_menutext) {
						Setting::where('slug', 'classic_menutext')->update(['value' => trim($request->classic_menutext)]);
					}
					elseif ($item->slug == 'sticky_header' && $item->value != $request->sticky_header) {
						if($request->sticky_header=='yes' || $request->sticky_header=='no'){
							Setting::where('slug', 'sticky_header')->update(['value' => $request->sticky_header]);
						}
					}
					elseif ($item->slug == 'sticky_top' && $item->value != $request->sticky_top && ctype_digit($request->sticky_top)) {
						Setting::where('slug', 'sticky_top')->update(['value' => $request->sticky_top]);
					}
					// elseif ($item->slug == 'sticky_id' && $item->value != $request->sticky_id) {
					// 	Setting::where('slug', 'sticky_id')->update(['value' => str_replace(' ', '', $request->sticky_id)]);
					// }
				}
				return redirect()->back()->with(['success'=> 'Setting Data has been saved successfully']);
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    public function removfavimage($imgval)
    {
    	if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10){                  //Authentication for Minimum Managers
                $data['logged_id'] = Auth::user()->id;
                $data['logged_role'] = Auth::user()->role;

                $imgData = Setting::where(['slug'=>'favicon', 'value'=>$imgval])->first();
                // deleting uploaded image from folder
	            $deletedImage = removeuploadedimage($imgData->value, path_favicon());

	            if($deletedImage)
	            {
		        	$updated = Setting::where(['slug'=>'favicon', 'value'=>$imgval])->update(['value' => '']);
		        	if($updated)
			        {
			        	return redirect()->back()->with(['remove'=> 'Favicon image has been removed successfully ']);
			        }
	            }
	            return redirect()->back()->with(['dissmiss'=> 'Favicon image could not be removed! Try Later.']);
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    public function removlogoimage($imgval)
    {
    	if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10){                  //Authentication for Minimum Managers
                $data['logged_id'] = Auth::user()->id;
                $data['logged_role'] = Auth::user()->role;

                $imgData = Setting::where(['slug'=>'logo_img', 'value'=>$imgval])->first();

                // deleting uploaded image from folder
	            $deletedImage = removeuploadedimage($imgData->value, path_logo());

	            if($deletedImage)
	            {
			        $updated = Setting::where(['slug'=>'logo_img', 'value'=>$imgval])->update(['value' => '']);

			        if($updated)
			        {
			        	return redirect()->back()->with(['remove'=> 'Logo image has been Removed successfully.']);
			        }
	            }
		        return redirect()->back()->with(['dissmiss'=> 'Logo Image could not be removed now! Try Later.']);
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }
}
