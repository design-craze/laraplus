<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Userinfo;
use Validator;
use Hash;
use Mail;
use Illuminate\Support\Facades\Auth;
use Intervention\Image\ImageManagerStatic as Image;
use Illuminate\Support\Facades\Input;
use File;

class UsersController extends Controller
{
    public function userlist()
    {
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
             if(Auth::user()->role >= 10){                  //Authentication for Minimum Managers
                $data['logged_role'] = Auth::user()->role;  //User Role from Authentication data
                $data['logged_id'] = Auth::user()->id;      //User ID from authentication data
                $where = false;                             //Determine if where is available to query
                $perpage = 10;                               //Determine item per page for pagination
                $getmethod = '';                            //Variable that contains the extended url for get method
                $blankget = false;                          //Determine if get is available or not
                $getchar = '?';                             //Determine the joining character for multiple get methods
                $data['getelements'] = array();             //Element data for pagination in view;
                $sort = 'desc';

                if(isset($_GET['r']) && $_GET['r']!=''){                        //Set Role
                    $data['getelements']['r'] = $_GET['r'];
                    $wherearray['role']= $data['getelements']['r'];
                    $where=true;
                }
                if(isset($_GET['v']) && $_GET['v']!=''){                        //Set verification
                    $data['getelements']['v'] = $_GET['v'];
                    $wherearray['verified']= $data['getelements']['v'];
                    $where=true;
                }
                if(isset($_GET['a']) && $_GET['a']!=''){                        //Set Activation
                    $data['getelements']['a'] = $_GET['a'];
                    $wherearray['active']= $data['getelements']['a'];
                    $where=true;
                }
                if(isset($_GET['s']) && $_GET['s']!=''){                        //Set Sorting
                    $data['getelements']['s'] = $sort = $_GET['s'];
                }
                if(isset($_GET)){                                               //Build get method path
                    foreach($_GET as $key => $val){
                        if($val!=''){
                            $getmethod .= $getchar . $key . '=' . $val;
                            $getchar = '&';
                        }
                        else{
                            $blankget = true;
                        }
                    }
                    if($blankget == true){
                        return redirect(route('userlist') . $getmethod);
                    }
                }

                if(isset($data['getelements']['r']) || isset($data['getelements']['v']) || isset($data['getelements']['a']) || isset($data['getelements']['s'])){
                    if($where==true){
                        $data['users'] = User::where($wherearray)->orderBy('id', $sort)->paginate($perpage)->appends($data['getelements']);
                    }
                    else{
                        $data['users'] = User::orderBy('id', $sort)->paginate($perpage)->appends($data['getelements']);
                    }
                }
                else{
                    $data['users'] = User::orderBy('id', 'desc')->paginate($perpage)->appends($data['getelements']);
                }
                return view('admin.userlist', $data);
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    public function createuser()
    {
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10){                  //Authentication for Minimum Managers
                $data['logged_id'] = Auth::user()->id;
                $data['logged_role'] = Auth::user()->role;
                $data['autousername'] = getRandKey('',$limit=3,$preFix='user_');
                $data['autopassword'] = getRandKey('0123456789',$limit=4,$preFix='pass');
                return view('admin.createuser', $data);
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    public function createuserprocess(Request $request)
    {
        if (!Auth::user())
        {                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else
        {
            if(Auth::user()->role >= 10)
            {                  //Authentication for Minimum Managers
                $rules = [ 
                    'fname'=>'required|max:50|min:2', 
                    'lname'=>'required|max:50|min:2',
                    'username'=> 'required|alpha_dash|unique:users,username|max:50|min:3',
                    'email'=> 'required|email|unique:users,email|max:255|min:5',
                    'password'=> 'required|string|max:255|min:6',
                    'role'=> 'required|integer|between:1,'.(Auth::user()->role-1),
                    'verified'=> 'required|integer|between:1,'.count(isemailverified()),
                    'country'=>'in:'.keystring(country(),','),
                    'sex'=>'in:'.keystring(gender(),','),
                    'contact' => 'numeric',
                    'dob' => 'date_format:yy-m-d|before: -5 Years'
                    ];

                $messages = [ 
                    'fname.required' => 'First Name field is required', 
                    'fname.max' => 'First Name field consists of maximum 50 characters', 
                    'fname.min' => 'First Name field consists of minimum 2 characters', 
                    'lname.required' => 'Last Name field is required.',
                    'lname.max' => 'Last Name field consists of maximum 50 characters', 
                    'username.required' => 'Username field is required.',
                    'username.alpha_dash' => 'Username field must be alphabate number, as well as dashes and underscores.',
                    'username.unique' => 'Oops! This Username already exists, Please choose unique Username.',
                    'username.max' => 'Username field consists of maximum 50 characters', 
                    'username.min' => 'Username field consists of minimum 3 characters', 
                    'email.required' => 'Email field is required.',
                    'email.email' => 'Email field contains invalid Email Address.',
                    'email.unique' => 'Oops! This Email already exists, Please choose unique Email.',
                    'email.max' => 'Email field consists of maximum 50 characters', 
                    'email.min' => 'Email field consists of minimum 5 characters', 
                    'password.required' => 'Password field is required.',
                    'password.string' => 'Password must be string.',
                    'password.max' => 'Password field consists of maximum 255 characters', 
                    'password.min' => 'Password field consists of minimum 6 characters', 
                    'role.required' => 'Role field is required.',
                    'role.integer' => 'Role field contains invalid value.', 
                    'role.between' => 'Role field contains invaild value', 
                    'verified.required' => 'Email Verification field is required.',
                    'verified.integer' => 'Email Verification field contains invalid value.', 
                    'verified.between' => 'Email Verification field contains invaild value',
                    'country.in' => 'Selected Country is not available in the list.',
                    'sex.in' => 'Selected Gender is not available in the list.',
                    'contact.numeric' => 'Contact Number must consist of Numbers.',
                    'dob.date_format' => 'Date of Birth contains invalid format. Date Format must consist of yyyy-mm-dd.',
                    'dob.before' => 'Date of Birth must be minimum five years old.'
                    ];

                $validator = Validator::make($request->all(), $rules, $messages);

                if($validator->fails())
                {
                    return redirect()->back()->withErrors($validator)->withInput();
                }
                else
                {
                    $insert['fname'] = $request->fname;
                    $insert['lname'] = $request->lname;
                    $insert['username'] = $request->username;
                    $insert['email'] = $request->email;
                    $insert['password'] = Hash::make($request->password);
                    $insert['role'] = $request->role;
                    $insert['verified'] = $request->verified;
                    $insert['active'] = count(activelevel());
                    $insert['logcode'] = md5($request->email.uniqid());
                    $insert['vfcode'] = md5(uniqid());


                    $inserted = User::create($insert)->id;
                    if($inserted)
                    {
                        
                        // inserting userinfo data
                        $userinfoinput = $request->except('_token','fname','lname','username','email','password','role','verified','active');

                        $userinfoinput['user_id'] = $inserted;
                        $userinfoinserted = Userinfo::create($userinfoinput);

                        if($userinfoinserted)
                        {
                            // sending mail
                            $userName = $request->fname . ' ' . $request->lname;
                            $userEmail = $request->email;
                            $subject = 'Welcome Message';
                            
                            $sentMail = Mail::send(
                                            'admin.emails.welcome',
                                            ['data' => $request],
                                            function ($message) use ($userName, $userEmail, $subject)
                                            {
                                                $message->to($userEmail, $userName)->subject($subject)->replyTo('DoNotReply@design-craze.com', 'Design Craze');
                                            }
                                        );
                            
                            return redirect()->route('viewuserinfo', ['id' => $inserted])->with(['success'=> 'User Account has been created Successfully with all data']);
                        }else{
                            return redirect()->back()->with(['success'=> 'User Account has been created with only Primary data but not the user personal data.']);
                        }
                    }
                    else{
                        return redirect()->back()->with(['dissmiss'=> 'User Account Can not be created for some reason. Please try again.']);
                    }
                }
            }
            else
            {                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }
    
    public function viewuserinfo($id)
    {
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
             if(Auth::user()->role >= 10){                   //Authentication for Minimum Managers
                $data['dataerror'] = 0;
                $data['logged_id'] = Auth::user()->id;
                $data['logged_role'] = Auth::user()->role;
                $data['user'] = User::where(['id'=>$id])->first();
                if($data['user'])
                {
                    $data['userinfo'] = $data['user']->userinfo;
                }
                else{
                    $data['dataerror'] = 1;
                }

                return view('admin.viewuserinfo', $data);
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    public function edituserinfo($id)
    {
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
             if(Auth::user()->role >= 10){                   //Authentication for Minimum Managers
                $data['dataerror'] = 0;
                $data['logged_role'] = Auth::user()->role;
                $data['logged_id'] = Auth::user()->id;
                $data['user'] = User::where(['id'=>$id])->first();
                if($data['user'])
                {
                    $data['userinfo'] = $data['user']->userinfo;
                }
                else{
                    $data['dataerror'] = 1;
                }

                return view('admin.edituserinfo', $data);
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    public function edituserprocess($id,Request $request)
    {
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10){                   //Authentication for Minimum Managers
                $rules = [ 
                    'fname'=>'required', 
                    'lname'=>'required',
                    'country'=>'in:'.keystring(country(),','),
                    'sex'=>'in:'.keystring(gender(),','),
                    'contact' => 'numeric',
                    'dob' => 'date_format:yy-m-d|before: -5 Years'
                    ];

                $messages = [ 
                    'fname.required' => 'First Name field is required', 
                    'lname.required' => 'Last Name field is required.',
                    'country.in'     => 'Selected Country is not available in the list.',
                    'sex.in'     => 'Selected Gender is not available in the list.',
                    'contact.numeric'     => 'Contact Number must consist of Numbers.',
                    'dob.date_format' => 'Date of Birth contains invalid format. Date Format must consist of yyyy-mm-dd.',
                    'dob.before' => 'Date of Birth must be minimum five years old.'
                    ];

                if($request->role != null){
                    $rules['role'] = 'required|integer|between:1,'.(Auth::user()->role-1);
                    $messages['role.required'] = 'Role field is required.';
                    $messages['role.integer'] = 'Role field contains invaild value.';
                    $messages['role.between'] = 'Role field contains invalid value.';
                }
                if($request->verified!=null){
                    $rules['verified'] = 'required|integer|between:1,'.count(isemailverified());
                    $messages['verified.required'] = 'Email Verification field is required.';
                    $messages['verified.integer'] = 'Email Verification field contains invaild value.';
                    $messages['verified.between'] = 'Email Verification field contains invalid value.';
                }
                if($request->active!=null){
                    $maxval = (count(role())-1) - Auth::user()->role;
                    $rules['active'] = 'required|integer|between:'. $maxval .','.count(activelevel());
                    $messages['active.required'] = 'Status field is required.';
                    $messages['active.integer'] = 'Status field contains invaild value.';
                    $messages['active.between'] = 'Status field contains invaild value.';
                }

                $validator = Validator::make($request->all(), $rules, $messages);
                if ($validator->fails()) {
                    return redirect()->back()->withErrors($validator)->withInput();
                }
                else {
                    $userupdate = $request->except('_token','street1','street2','city','state','zip','country','sex','contact','description','dob');
                    $updated = User::where('id', $id)->update($userupdate);
                    if($updated){
                        $userinfoupdate = array(
                            'street1' => $request->street1,
                            'street2' => $request->street2,
                            'city' => $request->city,
                            'state' => $request->state,
                            'zip' => $request->zip,
                            'country' => $request->country,
                            'sex' => $request->sex,
                            'contact' => $request->contact,
                            'description' => $request->description
                        );
                        if($request->dob !=''){
                            $userinfoupdate['dob'] = $request->dob;
                        }
                        $searchuser = Userinfo::where('user_id', $id)->count();
                        if($searchuser>0){
                            $edited = Userinfo::where('user_id', $id)->update($userinfoupdate);

                            if($edited)
                            {
                                return redirect()->route('viewuserinfo', ['id' => $id])->with(['success'=> 'All submited data Has been Edited Successfully']);
                            }else{
                                return redirect()->back()->with(['success'=> 'Only Primary data has been Edited Successfully but not the user personal data.']);
                            }
                        }
                        else{
                            $userinfoupdate['user_id'] = $id;
                            $created = Userinfo::create($userinfoupdate);
                            if($created){
                                return redirect()->route('viewuserinfo', ['id' => $id])->with(['success'=> 'All submited data Has been Edited Successfully']);
                            }else{
                                return redirect()->back()->with(['success'=> 'Only Primary data has been Edited Successfully but not the user personal data.']);
                            }
                        }
                    }
                    else{
                        return redirect()->back()->with(['dissmiss'=> 'User Data Can not be edited for some reason']);
                    }
                }
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    public function uloadprofileimage(Request $request)
    {   
        if (!Auth::user())
        {                                     
            return redirect()->route('adminlogin'); 
        }
        else
        {
            if(Auth::user()->role >= 10)
            {                   
                $rules = [ 
                    'profileimg'=>'required|dimensions:min_width=180,min_height=180|image'
                ];

                $messages = [ 
                    'profileimg.required' => 'Image field can not be emtpy.',
                    'profileimg.dimensions' => 'Image dimensions must be 180x180 equal or above.',
                    'profileimg.image' => 'The uploaded file must be an image (jpeg, png).'
                ];

                $validator = Validator::make($request->all(), $rules, $messages);
                if ($validator->fails()) {
                    return redirect()->back()->withErrors($validator)->withInput();
                }
                else {
                    $favImg = $request->profileimg;
                    $favPath = path_profile();
                    
                    $uplodImage = uploadimage($favImg,$favPath,180, 180);

                    if($uplodImage)
                    {
                        // removing previous profile image if exists
                        $userdata = Userinfo::where(['user_id' => Auth::user()->id])->first();
                        $prevImg = $userdata->avatar;

                        if(!empty($prevImg))
                        {
                            removeuploadedimage($prevImg, $favPath);
                        }

                        // saving image in database
                        $updated = Userinfo::where(['user_id'=>Auth::user()->id])->update(['avatar' => $uplodImage]);
                        if($updated)
                        {
                            return redirect()->back()->with(['success'=> 'Profile image has been uploaded successfully.']);
                        }
                        return redirect()->back()->with(['dissmiss'=> 'Profile image can not be uploaded now! please try again.']);
                        
                    }
                    else{
                        return redirect()->back()->with(['dissmiss'=> 'Profile image can not be uploaded now! please try again.']);

                    }
                }
            }
        }
    }

    public function removprofileimage($imgval)
    {
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10){
                $data['logged_id'] = Auth::user()->id;
                $data['logged_role'] = Auth::user()->role;

                $imgData = Userinfo::where(['user_id'=>Auth::user()->id, 'avatar'=>$imgval])->first();

                // deleting uploaded image from folder
                $deletedImage = removeuploadedimage($imgData->avatar, path_profile());

                if($deletedImage)
                {
                    $updated = Userinfo::where(['user_id'=>Auth::user()->id, 'avatar'=>$imgval])->update(['avatar' => '']);

                    if($updated)
                    {
                        return redirect()->back()->with(['success'=> 'Profile image has been Removed successfully.']);
                    }
                }
                return redirect()->back()->with(['dissmiss'=> 'Profile Image could not be removed now! Try Later.']);
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }
}
