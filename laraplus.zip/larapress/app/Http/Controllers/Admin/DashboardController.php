<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Validator;
use Hash;
use App\Models\User;
use App\Models\Blog;
use App\Models\Page;
use App\Models\Category;
use App\Models\BlogCategory;
use App\Models\Comment;
use Mail;

class DashboardController extends Controller
{
    public function __construct()
    {
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin')->send();
        }
        else{
            if(Auth::user() && Auth::user()->role != 12 && Auth::user()->role >= 10)
            {
                if(Auth::user()->verified == 1 || Auth::user()->active == 3 || Auth::user()->active == 2)
                {
                     return redirect()->route('adminsuspended')->send();
                }
            }
        }
    }

    public function admin()
    {
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10){                  //Authentication for Minimum Managers
                // $data['logged_id'] = Auth::user()->id;
                // $data['logged_role'] = Auth::user()->role;

                // return redirect()->route('admindashboard',$data);
                return redirect()->route('admindashboard');
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    public function dashboard()
    {
    	if(Auth::user()->role >= 10){                      //Authentication for Minimum Managers
            
            $data['blogs'] = Blog::where([ 'trashed' => '0', 'archived' => '0'])->orderBy('updated_at','desc')->skip(0)->take(5)->get();
            $data['countblogs'] = Blog::count();

            $data['pages'] = Page::where([ 'lang' => 'en', 'trashed' => '0', 'parent' => '0'])->orderBy('updated_at','desc')->skip(0)->take(5)->get();
            
            $data['countpages'] = Page::where([ 'lang' => 'en', 'parent' => '0'])->count();

            $data['users'] = User::orderBy('id','desc')->skip(0)->take(5)->get();
            $data['countusers'] = User::count();

            $data['countcomments'] = Comment::count();

            return view('admin.dashboard',$data);
        }
        else{                                               //Authentication for User Less than managers
            return redirect()->route('dashboard');
        }
    }

    public function adminusersetting()
    {
        if(Auth::user()->role >= 10){                      //Authentication for Minimum Managers

          return view('admin.adminusersetting');
        }
        else{                                               //Authentication for User Less than managers
            return redirect()->route('dashboard');
        }
    }

    public function changepasswordprocess(Request $request)
    {
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10){                  //Authentication for Minimum Managers
                $data['logged_id'] = Auth::user()->id;
                $data['logged_role'] = Auth::user()->role;

                $rules = [ 
                    'old_pass' => 'required|string|max:255|min:6', 
                    'new_pass' => 'required|string|confirmed|max:255|min:6'
                ];

                $messages = [ 
                    'old_pass.required' => 'Old Password field is required.',
                    'old_pass.string' => 'Old Password must be string.',
                    'old_pass.max' => 'Old Password field consists of maximum 255 characters', 
                    'old_pass.min' => 'Old Password field consists of minimum 6 characters',
                    'new_pass.required' => 'New Password field is required.',
                    'new_pass.string' => 'New Password must be string.',
                    'new_pass.confirmed' => 'New Password fields did not match',
                    'new_pass.max' => 'New Password field consists of maximum 255 characters', 
                    'new_pass.min' => 'New Password field consists of minimum 6 characters'
                ];

                $validator = Validator::make($request->all(), $rules, $messages);

                if($validator->fails())
                {
                    return redirect()->back()->withErrors($validator)->withInput();
                }
                else
                {
                    $checkoldpass = Hash::check($request->old_pass, Auth::user()->password);

                    if($checkoldpass)
                    {
                        $new_pass = Hash::make($request->new_pass);
                        $updated = User::where('id',Auth::user()->id)->update(['password'=>$new_pass]);

                        if($updated)
                        {
                            // sending mail
                            $userName = Auth::user()->fname . ' ' . Auth::user()->lname;
                            $userEmail = Auth::user()->email;
                            $subject = 'Password Changing Message | Larapress';

                            $sentmail = Mail::send(
                                'admin.emails.passchange',
                                ['data' => Auth::user(),'new_pass'=>$request->new_pass],
                                function ($message) use ($userName, $userEmail, $subject)
                                {
                                    $message->to($userEmail, $userName)->subject($subject)->replyTo(
                                        'DoNotReply@design-craze.com', 'Design Craze'
                                    );
                                }
                            );

                            return redirect()->back()->with('success','Password Successfully Changed.');
                        }
                    }
                    else{
                        return redirect()->back()->with('dissmiss','Old Password Did not macth! Try again.');
                    }
                }
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }
}