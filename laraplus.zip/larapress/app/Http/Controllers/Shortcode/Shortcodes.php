<?php

namespace App\Http\Controllers\Shortcode;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Shortcode\Shortcode as Shortcode;
use App\Models\Blog;

use App;
class Shortcodes extends Shortcode
{
    function __construct(){
    	define("SHORTCODES", "shortcode");
    	if(file_exists(getviewpath().'/template/' . allsetting('template').'/functions/shortcodes.php'))
    	{
require base_path('resources/views/template/'. allsetting('template').'/functions/shortcodes.php');
    	}
        $this->add_shortcode('section', function($atts, $content = null){
		    extract($this->shortcode_atts(array(
		                'type'  =>'',
		                'clearcol' => '',
		                'class' => '',
		                'style' => '',
		                'id' =>'',
		                'parallax'=> '',
		                'image'=>'',
		                'direction'=>'',
		                'fixed'=>'',
		                'overlay'=>''
		     	), 
		    $atts));
		    if($fixed=='yes'){
		    	$fixed=' data-parallax-fixed="yes"';
		    }
		    else{
				$fixed='';
		    }
		    if($direction=='left'){
		    	$direction=' data-parallax-dir="left"';
		    }
		    elseif($direction=='right'){
		    	$direction=' data-parallax-dir="right"';
		    }
		    else{$direction='';}
		    if($parallax=='yes'){$parallax=' dc-parallax';}else{$parallax='';}
		    if($type=='full'){$type = ' container-full';}else{$type = 'container-center';}
		    if($clearcol=='yes'){$clearcol = ' dc-clear';}else{$clearcol = '';}
		    if($id!=''){
		    	$id= ' id="'.trim($id).'"';
		    }
		    if($class!=''){
		    	$class= ' class="innersection '.trim($class).$parallax.'"';
		    }
		    else{$class= ' class="innersection'.$parallax.'"';}
	    	if($image!=''){$image='background-image:url('.$image.');';}
	    	$style=' style="'.$image.$style.'"';
		    $output = '<div '.$id.$class.$style.$direction.$fixed.'><div class="inner-overlay" style="background-color:'.$overlay.'"><div class="'.$type.'"><div class="row'.$clearcol.'">'.$this->do_shortcode($content).'</div></div></div></div>';
		    
		    return $output;
		});

		$this->add_shortcode('column', function($atts, $content = null){
		    extract($this->shortcode_atts(array(
		                'lg'  =>'',
		                'md' => '',
		                'sm' => '',
		                'xs' => '',
		                'class' => ''
		     	), 
		    $atts));
		    $col = '';
		    $number = array('1','2','3','4','5','6','7','8','9','10','11','12');
		    if(in_array($lg, $number) || in_array($md, $number) || in_array($sm, $number) || in_array($xs, $number)){
		    	if(in_array($lg, $number)){
		    		$col .= 'col-lg-'. $lg;
		    	}
		    	if(in_array($md, $number) && $col==''){
		    		$col .= 'col-md-'. $md;
		    	}
		    	else if(in_array($md, $number) && $col!=''){
		    		$col .= ' col-md-'. $md;
		    	}
		    	if(in_array($sm, $number) && $col==''){
		    		$col .= 'col-sm-'. $sm;
		    	}
		    	else if(in_array($sm, $number) && $col!=''){
		    		$col .= ' col-sm-'. $sm;
		    	}
		    	if(in_array($xs, $number) && $col==''){
		    		$col .= 'col-xs-'. $xs;
		    	}
		    	else if(in_array($xs, $number) && $col!=''){
		    		$col .= ' col-xs-'. $xs;
		    	}
		    }
		    else{
		    	$col = 'col-lg-12';
		    }
		    if($class!=''){
		    	$col .= ' ' . trim($class);
		    }

		    $output = '<div class="'.$col.'">'.$this->do_shortcode($content).'</div>';
		    
		    return $output;
		});

		$this->add_shortcode('blogs', function($atts, $content = null){
		    extract($this->shortcode_atts(array(
		    			'type'  =>'',
		                'number'  =>'',
		                'skip' => '',
		                'order' => '',
		                'parent_class' => '',
		                'read_more' =>'Read More',
		                'col' => '4',
		                'class' => '',
		                'style' => '',
		                'id' =>'',
		                'parallax'=> '',
		                'image'=>'',
		                'direction'=>'',
		                'fixed'=>'',
		                'overlay'=>''
		     	), 
		    $atts));
		    $output='';
		    if($fixed=='yes'){
		    	$fixed=' data-parallax-fixed="yes"';
		    }
		    else{
				$fixed='';
		    }
		    if($direction=='left'){
		    	$direction=' data-parallax-dir="left"';
		    }
		    elseif($direction=='right'){
		    	$direction=' data-parallax-dir="right"';
		    }
		    else{$direction='';}
		    if($parallax=='yes'){$parallax=' dc-parallax';}else{$parallax='';}
		    if($type=='full'){$type = ' container-full';}else{$type = 'container-center';}
		    if(ctype_digit($col) && $col==6){
		    	$col = 'col-lg-2 col-md-3 col-sm-6';
		    }
		    elseif(ctype_digit($col) && $col==4){
		    	$col = 'col-md-3 col-sm-6';
		    }
		    elseif(ctype_digit($col) && $col==3){
		    	$col = 'col-md-3';
		    }
		    elseif(ctype_digit($col) && $col==2){
		    	$col = 'col-sm-6';
		    }
		    elseif(ctype_digit($col) && $col==1){
		    	$col = 'col-md-12';
		    }
		    else{
		    	$col = 'col-md-3 col-sm-6';
		    }
		    if($id!=''){
		    	$id= ' id="'.trim($id).'"';
		    }
		    if($class!=''){
		    	$class= ' class="innersection '.trim($class).$parallax.'"';
		    }
		    else{$class= ' class="innersection'.$parallax.'"';}
		    if($image!=''){$image='background-image:url('.$image.');';}
		    $style=' style="'.$image.$style.'"';

		    if(!ctype_digit($number) || $number==''){$number=12;}
		    if(!ctype_digit($skip) || $skip==''){$skip=0;}
		    if($order=='asc'){$order='asc';}else{$order='desc';}
		    $where = array(
		    	'trashed' => '0',
		    	'type' => 'blog',
		    	'archived' => '0'
		    );
		    if($parent_class!=''){
		    	$parent_class= ' ' .trim($parent_class);
		    }
            $blogs = Blog::where($where)->orderBy('updated_at', 'desc')->skip($skip)->take($number)->get();
            if(count($blogs)>0){
            	$output =	'<div '.$id.$class.$style.$direction.$fixed.'>'.
            				'<div class="inner-overlay" style="background-color:'.$overlay.'">'.
            				'<div class="'.$type.'">'.
            				'<div class="row dc-clear">';
        		foreach ($blogs as $blog) {
        			$output .= 	'<div class="' . $col.$parent_class.'">'.
        								'<div class="blog-thumb-big-image">'.
        									'<img class="img-responsive" src="';
								if($blog->thumb!=''){
								$output .= 	e($blog->thumb);
								}
								else{
								$output .= 	asset('assets/common/images/no-thumb-big.jpg');
								}
								$output .= '" alt="';
								if($blog->thumb!=''){
								$output .= 	e($blog->thumb);
								}
								$output .= 	'">'.
        								'</div>'.
        								'<div>'.
											'<h4 class="blog-thumb-big-title"><a href="' . route('blog', ['slug'=>$blog->slug]).'">'.strip_tags($blog->name) . '</a></h4>'.
											'<p class="blog-thumb-big-info">';
								if(isset($blog->user)){
									if($blog->user->fname!='' || $blog->user->lname!='' ){
										$output .= 	'<span class="blog-thumb-info-part"><i class="fa fa-user"></i> '. $blog->user->fname . '' . $blog->user->lname . '</span>';
									}
									
								}
								$output .= 	'<span class="blog-thumb-info-part"><i class="fa fa-clock-o"></i> '. time_elapsed_string($blog->updated_at).'</span>';
								if(isset($blog->comments)){
									$output .= 	'<span class="blog-thumb-info-part"><i class="fa fa-comment"></i> '. count($blog->comments) .'</span>';
								}			
								$output .= '</p>'.
											'<p class="blog-thumb-big-desc">'. substr(strip_tags($blog->description), 0, 150). '... <a class="dc-btn" href="' . route('blog', ['slug'=>$blog->slug]).'">'. $read_more . '</a></p>'.
										'</div>'.
								'</div>';
        		}
					$output .='</div>'.
								'</div>'.
								'</div>'.
								'</div>';
            }
		    return $output;
		});

		$this->add_shortcode('accordions', function($atts, $content = null){
		    extract($this->shortcode_atts(array(
		                'class'  =>'',
		                'start'  =>'',
		                'expand'  =>'',
		                'openicon'  =>'fa-caret-down',
		                'closeicon'  =>'fa-caret-right',
		     	), 
		    $atts));
		    if(!ctype_digit($start)){$start = '';}
		    if($expand=='all'){$expand='all';}else{$expand='';}
		    $output = '<div class="dc-accordion" data-exclass="'.$class.'" data-start="'.$start.'" data-expand="'.$expand.'" data-openicon="'.$openicon.'" data-closeicon="'.$closeicon.'">'.$this->do_shortcode($content).'</div>';
		    return $output;
		});

		$this->add_shortcode('accordion', function($atts, $content = null){
		    extract($this->shortcode_atts(array(
		                'title'  =>''
		        ), 
		    $atts));
		    $output = '<div class="dc-acc-box"><div class="dc-acc-head"><p><i class="dc-accrd-icon"></i> '.e($title).'</p></div><div class="dc-acc-body">'.$content.'</div></div>';
		    return $output;
		});

		$this->add_shortcode('testimonials', function($atts, $content = null){
		    extract($this->shortcode_atts(array(
		            'class'=> '',
		            'slide'=> 'yes'
		     	), 
		    $atts));
		     if($class!=''){
		        $class = ' '.trim($class);
		     }
		     $arrow ='';
		     if($slide=='yes'){$slide='yes';$arrow='<div class="dc-nav-tab-arrow"><div class="dc-tab-arrow-prev"><i class="fa fa-chevron-left"></i></div><div class="dc-tab-arrow-next"><i class="fa fa-chevron-right"></i></div></div>';}
		    $output = '<div class="dc-tab dc-testimony-primary'.$class.'" data-slide="yes" data-slideshow="yes" data-time="3000" data-section-type="float" data-transtime="0.6s" data-nav-trans="yes"><div class="dc-nav-tab-container"><ul class="dc-nav-tab clearfix dc-nav-tab-square-primary"></ul></div>'.$arrow.'<div class="dc-tab-content"><div class="dc-tab-container">'.$this->do_shortcode($content).'</div></div></div>';
		    return $output;
		});

		$this->add_shortcode('testimonial', function($atts, $content = null){
		    extract($this->shortcode_atts(array(
		                'image'  =>''
		        ), 
		    $atts));
		    if($image==''){
		        $image = asset('assets/common/images/shadow.jpg');
		    }
		    $output = '<div class="dc-tab-pane"><div class="removable-image-testimony"><img src="'.$image.'"></div><div class="dc-quote-primary">'.$content.'</div></div>';
		    return $output;
		});

	}
}
