<?php

namespace App\Http\Controllers\RoleController;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Session;

class RoleController extends Controller{
    protected $myloginrole = 0;
    protected $mylogactivation = 0;
    protected $mylogid = 0;

    function __construct(){
    	if (Session::has('user_role')){
			$this->myloginrole = Session::get('user_role');
    	}
    	if(Session::has('user_activation') && Session::has('user_activation')==1 && Session::has('user_verification') && Session::has('user_verification')==1){
    		$this->mylogactivation= '3';
    	}
    	else if(Session::has('user_activation') && Session::has('user_activation')==1 && Session::has('user_verification') && Session::has('user_verification')==0){
    		$this->mylogactivation= '2';
    	}
    	else if(Session::has('user_activation') && Session::has('user_activation')==0 && Session::has('user_verification') && Session::has('user_verification')==1){
    		$this->mylogactivation= '1';
    	}
    	if (Session::has('user_id')) {
			$this->mylogid = Session::get('user_id');
    	}
    }

    public function AccessUser(){
        if($this->myloginrole >=1){
            return redirect()->route('user', ['id' => $this->mylogid]);
        }
    }

    public function AccessEditor(){
        if($this->myloginrole >=2){
            return redirect()->route('user', ['id' => $this->mylogid]);
        }
    }

    public function AccessManager(){
        if($this->myloginrole >=3){
            return redirect()->route('user', ['id' => $this->mylogid]);
        }
    }

    public function AccessAdministrator(){
        if($this->myloginrole >=4){
            return redirect()->route('user', ['id' => $this->mylogid]);
        }
    }

    public function AccessUnlogged(){
        if($this->myloginrole <1){
            return redirect()->route('login');
        }
    }
}
