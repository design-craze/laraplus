<?php

namespace App\Http\Controllers\Setting;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\Setting;
use App\Models\Page;

class SettingController extends Controller
{
    public function allsetting(){
    	$output = array();
    	$a = Setting::get();
    	foreach($a as $val){
    		$output[$val->slug] = $val->value;
    	}
    	return $output;
    }

    public function singlesetting($a){
    	$output = array();
    	$b = Setting::where('slug', $a)->first();
        if($b){
    		$output[$a] = $b->value;
        }
        else{
            $output[$a] = '';
        }
    	return $output;
    }

}
