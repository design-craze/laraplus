<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Menu extends Model
{
    protected $fillable = ['class', 'name', 'selected', 'updated_at'];

    public function menuitems(){
    	return $this->hasMany('App\Models\Menuitem')->orderBy('serial', 'asc');
    }

    public function mypages(){
    	$a= $this->join('menuitems', 'menus.id', '=', 'menuitems.menu_id')->join('pages', 'menuitems.page_id', '=', 'pages.id')->select('menuitems.*', 'pages.slug')->orderBy('menuitems.serial', 'asc')->get();
    	return $a;
    }

    public function myblogs(){
    	$a= $this->join('menuitems', 'menus.id', '=', 'menuitems.menu_id')->join('blogs', 'menuitems.blog_id', '=', 'blogs.id')->select('menuitems.*', 'blogs.slug')->orderBy('menuitems.serial', 'asc')->get();
    	return $a;
    }
}
