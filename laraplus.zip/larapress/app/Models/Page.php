<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Page extends Model
{
    protected $fillable = ['name', 'slug', 'description', 'metatitle', 'metadesc', 'metatag', 'home' , 'template', 'parent', 'lang', 'menu', 'css', 'js', 'access_level', 'trashed', 'header', 'hdrlayout', 'title', 'titlelayout', 'breadcrumbs', 'layout', 'bodystyle', 'leftside', 'rightside', 'ftrlayout', 'ftrwid', 'btmftr', 'updated_at'];
}
