$(function(){
	$('.edit-com').each(function(){
		$(this).on('click',function(e){
			e.preventDefault();
			var $this = $(this);

			// hiding siblings edit box
			$this.closest('.comment-box').siblings('.comment-box').find('.edit-comment').hide()
				.end().find('.edit-com-btn').hide(0, function(){
					$this.closest('.comment-box').siblings('.comment-box').find('.comment').show();
					$this.closest('.comment-box').siblings('.comment-box').find('.update-com-btn').show();
			});

			// hiding parent edit box
			$this.closest('.comment-box').parents('.comment-box').find('.edit-comment').hide()
				.end().find('.edit-com-btn').hide(0, function(){
					$this.closest('.comment-box').parents('.comment-box').find('.comment').show();
					$this.closest('.comment-box').parents('.comment-box').find('.update-com-btn').show();
			});

			// hiding parents siblings edit box
			$this.closest('.comment-box').parents('.comment-box').siblings('.comment-box').find('.edit-comment').hide()
				.end().find('.edit-com-btn').hide(0, function(){
					$this.closest('.comment-box').parents('.comment-box').siblings('.comment-box').find('.comment').show();
					$this.closest('.comment-box').parents('.comment-box').siblings('.comment-box').find('.update-com-btn').show();
			});

			// hiding child edit box
			$this.closest('.comment-box').find('.edit-comment').hide()
				.end().find('.edit-com-btn').hide(0, function(){
					$this.closest('.comment-box').find('.comment').show();
					$this.closest('.comment-box').find('.update-com-btn').show();
			});

			// hiding siblings child edit box
			$this.closest('.comment-box').siblings('.comment-box').find('.edit-comment').hide()
				.end().find('.edit-com-btn').hide(0, function(){
					$this.closest('.comment-box').siblings('.comment-box').find('.comment').show();
					$this.closest('.comment-box').siblings('.comment-box').find('.update-com-btn').show();
			});

			// showing the main edit box
			var com_val = $this.closest('.comment-box').find('.comment:first').text();

			$this.closest('.comment-box').find('.comment:first').hide().
				end().find('.update-com-btn:first').hide(0, function(){
					$this.closest('.comment-box').find('.edit-comment:first').find('.editcomment').val($.trim(com_val));


					$this.closest('.comment-box').find('.edit-comment:first').show();
					$this.closest('.comment-box').find('.edit-com-btn:first').show();

			});
		});
	});

	$('.cancel-com').each(function(){
		$(this).on('click',function(e){
			e.preventDefault();
			var $this = $(this);

			$this.closest('.comment-box').find('.edit-comment:first').hide(0, function(){
				$this.closest('.comment-box').find('.comment:first').show();
				$this.closest('.comment-box').find('.update-com-btn:first').show();
			});
		});
	});

	$('.reply-com').each(function(){
		$(this).on('click',function(e){
			e.preventDefault();
			var $this = $(this);

			$this.closest('.comment-box').find('.reply-box:first').show();
		});
	});

	$('.cancel-reply').each(function(){
		$(this).on('click',function(e){
			e.preventDefault();
			var $this = $(this);

			$this.parents('.reply-box').hide();
		});
	});

});