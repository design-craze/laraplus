<?php $__env->startSection('body'); ?>
	<?php /* <?php if($data->access_level == -1 && $userlevel > 0): ?> */ ?>
	    <?php /* <?php echo e(accessunloggeduser('en')); ?> */ ?>
	<?php /* <?php elseif($data->access_level > 0 && $data->access_level > $userlevel): ?> */ ?>
	    <?php /* <?php echo e(accesscompare($data->access_level,'en')); ?> */ ?>
	<?php /* <?php else: ?> */ ?>
			<div id="page-content">
			<?php echo generate_shortcode($data->description); ?>

			</div>
			<?php $__env->startSection('templatesection'); ?>
         		@parent
         	<?php $__env->stopSection(); ?>
	<?php /* <?php endif; ?> */ ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.'.$settinghelper['template'].'.page-template.'. ifavailable([$data->template, allsetting('template')]), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>