<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('headcode'); ?>
	<?php echo e(Html::style('assets/admin/css/menu.css')); ?>

	<?php echo e(Html::style('assets/admin/vendor/select2/select2.min.css')); ?>

	<style>
		.small-box .icon{
			font-size: 70px;
			padding-top:8px;
		}
		.small-box:hover .icon{
			font-size: 90px;
			padding-top:0px;
		}
	</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcambs', '<i class="fa fa-dashboard"></i> Dashboard'); ?>

<?php $__env->startSection('bodycode'); ?>
	<!-- Small boxes (Stat box) -->
      <div class="row">
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3><?php echo e($countblogs); ?></h3>

              <p>Blogs</p>
            </div>
            <div class="icon">
              <i class="fa fa-book"></i>
            </div>
            <a target="_blank" href="<?php echo e(route('blogmanager')); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <h3><?php echo e($countpages); ?> <sup style="font-size: 20px">%</sup></h3>

              <p>Pages</p>
            </div>
            <div class="icon">
              <i class="fa fa-file-text"></i>
            </div>
            <a target="_blank" href="<?php echo e(route('pagemanager')); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3><?php echo e($countusers); ?></h3>

              <p>Users</p>
            </div>
            <div class="icon">
              <i class="fa fa-users"></i>
            </div>
            <a target="_blank" href="<?php echo e(route('userlist')); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
              <h3><?php echo e($countcomments); ?></h3>

              <p>Comments</p>
            </div>
            <div class="icon">
              <i class="fa fa-comments"></i>
            </div>
            <a target="_blank" href="<?php echo e(route('managecomment')); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
      </div>
      <!-- /.row -->

	<div class="row">
		<div class="col-md-4 col-sm-6">
			<div class="box box-primary" style="padding: 0 10px 5px;">
              <div class="box-body">
              	<h4 class="clearfix" style="padding-bottom: 5px">
                  Recent Blogs
                  <a target="_blank" style="margin-top: -7px" class="btn btn-primary pull-right btn-sm" href="<?php echo e(route('blogmanager')); ?>">Blog Manager</a>
                </h4>
              	<?php foreach($blogs as $rp): ?>
	              	<hr style="margin: 10px 0;">
              		<div class="box-comment">
		                <div class="comment-text">
	                      <h5 style="margin: 0;">
	                        	<a target="_blank" href="<?php echo e(route('editblog', ['id'=>$rp->id])); ?>"> <?php echo e(strip_tags($rp->name)); ?></a>
	                        	<span class="text-muted pull-right small"><?php echo e(time_elapsed_string($rp->updated_at)); ?></span>
	                      </h5><!-- /.username -->
		                  <?php echo e(substr(strip_tags($rp->description), 0, 51)); ?>...
		                </div>
		                <!-- /.comment-text -->
	              	</div>
				<?php endforeach; ?>
              </div><!-- /.box-body -->
          </div>
		</div>

		<div class="col-md-4 col-sm-6">
			<div class="box box-primary" style="padding: 0 10px 5px;">
              <div class="box-body">
              	<h4 class="clearfix" style="padding-bottom: 5px">
                  Recent Pages
                  <a style="margin-top: -7px" class="btn btn-primary pull-right btn-sm" target="_blank" href="<?php echo e(route('pagemanager')); ?>">Page Manager</a>
                </h4>
              	<?php foreach($pages as $rp): ?>
	              	<hr style="margin: 10px 0;">
              		<div class="box-comment">
		                <div class="comment-text">
	                      <h5 style="margin: 0;">
	                        	<a target="_blank" href="<?php echo e(route('editpage', ['id'=>$rp->id])); ?>"> <?php echo e(strip_tags($rp->name)); ?></a>
	                        	<span class="text-muted pull-right small"><?php echo e(time_elapsed_string($rp->updated_at)); ?></span>
	                      </h5><!-- /.username -->
		                  <?php echo e(substr(strip_tags($rp->description), 0, 51)); ?>...
		                </div>
		                <!-- /.comment-text -->
	              	</div>
				<?php endforeach; ?>
              </div><!-- /.box-body -->
          </div>
		</div>

		<div class="col-md-4 col-sm-6">
			<div class="box box-primary" style="padding: 0 10px 5px;">
              <div class="box-body">
              	<h4 class="clearfix" style="padding-bottom: 5px">
					Recent Users
					<a target="_blank" style="margin-top: -7px" class="btn btn-primary pull-right btn-sm" href="<?php echo e(route('userlist')); ?>">User Manager</a>
                </h4>
                <?php if(isset($users) && !empty($users)): ?>
	              	<?php foreach($users as $rp): ?>
		              	<hr style="margin: 5.5px 0;">
			                <div class="row">
								<div class="col-sm-2">
									<?php if(isset($rp->userinfo->avatar) && !empty($rp->userinfo->avatar)): ?>
									<img src="<?php echo e(asset(path_profile(). $rp->userinfo->avatar)); ?>" alt="<?php echo e($rp->userinfo->avatar); ?>" class="img-responsive img-circle">
									<?php elseif(isset($rp->userinfo->sex) &&  $rp->userinfo->sex == 'f'): ?>
									<img src="<?php echo e(asset(path_profile().'female.jpg')); ?>" alt="female.jpg" class="img-responsive img-circle">
									<?php else: ?>
									<img src="<?php echo e(asset(path_profile().'male.jpg')); ?>" alt="male.jpg" class="img-responsive img-circle">
									<?php endif; ?>
								</div>
								<div class="col-sm-8">
									<h5 style="margin-top:0; margin-bottom:0px"><a target="_blank" href="<?php echo e(route('viewuserinfo',['id'=>$rp->id])); ?>">Name: <?php echo e($rp->fname); ?> <?php echo e($rp->lname); ?></a></h5>
									<h6 style="margin-top:5px">EMail: <?php echo e($rp->email); ?></h6>
								</div>
							</div>
					<?php endforeach; ?>
				<?php endif; ?>
              </div><!-- /.box-body -->
          </div>
		</div>
		
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jscode'); ?>
	<?php echo e(Html::script('assets/admin/vendor/select2/select2.full.min.js')); ?>

	<?php echo e(Html::script('assets/admin/js/jquery.mjs.nestedSortable.js')); ?>

	<?php echo e(Html::script('assets/admin/js/adminmenuhandler.js')); ?>


	<script>
		$(function () {
	        //Initialize Select2 Elements
	        $(".select2").select2();
	    })
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>