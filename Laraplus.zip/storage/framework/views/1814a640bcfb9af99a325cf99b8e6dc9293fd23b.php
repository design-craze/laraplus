<?php echo $__env->make('template.'.$settinghelper['template'].'.includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('templatesection'); ?>
	<?php if($dataerror==0): ?>
	<div class="row">
        <div class="col-md-12 profile-aside">
            <div class="row">
            	 <div class="col-md-4">
                    <h1 class="profile-name">Hey! I'm <?php echo e($user->lname); ?></h1>
					<?php if(isset($userinfo) && !empty($userinfo)): ?>
                    <p><i class="fa fa-map-marker text-green"></i> <?php echo e($userinfo->city); ?> - <?php echo e(country($userinfo->country)); ?>, Member since <?php echo e(getDateFormat($userinfo->created_at)); ?></p>
					<?php endif; ?>
                </div>
                <div class="col-md-4">
                    <div class="dc-pro-img">
			        	<?php if(isset($userinfo) && !empty($userinfo->avatar) && !is_int($userinfo->avatar)): ?>
						<img src="<?php echo e(asset(path_profile().$userinfo->avatar)); ?>" alt="<?php echo e($userinfo->avatar); ?>" class="img-responsive img-rounded">
						<?php elseif($userinfo->sex == 'f'): ?>
						<img src="<?php echo e(asset(path_profile().'female.jpg')); ?>" alt="female.jpg" class="img-responsive img-rounded">
						<?php else: ?>
						<img src="<?php echo e(asset(path_profile().'male.jpg')); ?>" alt="male.jpg" class="img-responsive img-rounded">
						<?php endif; ?>
			        </div>
                </div> 
            	<div class="col-md-4">
                    <div class="panel panel-default custom-panel">
                        <div class="panel-heading">Verification</div>
                        <div class="panel-body">
                        	<ul class="list-group">
                        		<li class="list-group-item">
                        			Email Address :
                        			<?php if($user->verified==1): ?>
				                    	<span class="label label-danger"><?php echo e(isemailverified($user->verified)); ?></span>
				                    <?php elseif($user->verified==2): ?>
				                    	<span class="label label-success"><?php echo e(isemailverified($user->verified)); ?></span>
				                    <?php endif; ?>
                        		</li>
                        		<li class="list-group-item">
                        			Account Status: 
                        			<?php if($user->active==1): ?>
				                    	<span class="label label-danger"><?php echo e(activelevel($user->active)); ?></span>	
				                    <?php elseif($user->active==2): ?>
				                    	<span class="label label-warning"><?php echo e(activelevel($user->active)); ?></span>	
				                    <?php elseif($user->active==3): ?>
				                    	<span class="label label-info"><?php echo e(activelevel($user->active)); ?></span>
				                    <?php elseif($user->active==4): ?>
				                    	<span class="label label-success"><?php echo e(activelevel($user->active)); ?></span>
				                    <?php endif; ?>
                        		</li>
                        	</ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-12">
                	<?php if($logged_id == $user->id): ?>
                    <p><a href="<?php echo e(route('editprofile')); ?>" class="text-info small"> <i class="fa fa-pencil"></i> Edit Profile</a></p>
                    <?php endif; ?>
                    <div class="panel panel-default custom-panel">
                        <div class="panel-heading">Details</div>
                        <div class="panel-body">
                            <table class="table table-striped">
								<tr>
									<td class="col-xs-3 col-sm-6">Name</td>
									<td>: <?php echo e($user->fname); ?> <?php echo e($user->lname); ?></td>
								</tr>
								 <?php if($logged_id == $user->id): ?>
								<tr>
									<td>Username</td>
									<td>: <?php echo e($user->username); ?></td>
								</tr>
								<?php endif; ?>
								<tr>
									<td>Email</td>
									<td>: <a href="mailto:<?php echo e($user->email); ?>"><?php echo e($user->email); ?></a></td>
								</tr>
								<tr>
									<td>Role</td>
									<td>: <?php echo e(roleaccess($user->role)); ?></td>
								</tr>
								<?php if(isset($userinfo)): ?>
								<tr>
									<td>Addres Line 1</td>
									<td>: <?php echo e($userinfo->street1); ?></td>
								</tr>
								<tr>
									<td>Addres Line 2</td>
									<td>: <?php echo e($userinfo->street2); ?></td>
								</tr>
								<tr>
									<td>City</td>
									<td>: <?php echo e($userinfo->city); ?></td>
								</tr>
								<tr>
									<td>State</td>
									<td>: <?php echo e($userinfo->state); ?></td>
								</tr>
								<tr>
									<td>Zip</td>
									<td>: <?php echo e($userinfo->zip); ?></td>
								</tr>
								<tr>
									<td>Country</td>
									<td>: <?php echo e(country($userinfo->country)); ?></td>
								</tr>
								<tr>
									<td>Sex</td>
									<td>: <?php echo e(gender($userinfo->sex)); ?></td>
								</tr>
								<tr>
									<td>Contact No.</td>
									<td>: <a href="tel:<?php echo e($userinfo->contact); ?>"><?php echo e($userinfo->contact); ?></a></td>
								</tr>
								<tr>
									<td>Description</td>
									<td>: <?php echo e($userinfo->description); ?></td>
								</tr>
								<tr>
									<td>Date Of Birth</td>
									<td>:
										<?php if($userinfo->dob): ?>
											<?php echo e(getDateFormat($userinfo->dob,'d M, Y')); ?>

										<?php else: ?>
										Not Defined
										<?php endif; ?>
									</td>
								</tr>
								<tr>
									<td>Last Update</td>
									<td>: <?php echo e(getDateFormat($userinfo->updated_at)); ?></td>
								</tr>
								<?php endif; ?>
							</table>
	            		</div>
                    </div>
                </div>
            </div>
        </div>
    </div>    
    <?php else: ?>
	<div class="col-md-12">
		<div class="panel panel-default custom-panel">
            <div class="panel-body">
				<h4 class="text-center">
					No user found to view.
				</h4>
			</div>
		</div>
	</div>
	<?php endif; ?>
<?php echo $__env->yieldSection(); ?>
<?php echo $__env->make('template.'.$settinghelper['template'].'.includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>