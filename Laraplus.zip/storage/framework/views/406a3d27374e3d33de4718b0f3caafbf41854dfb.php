<?php 
	$settinghelper =allsetting(); 
	$webtitle = 'Error 404';
    $breadcrumb = breadcrumb(
        array(
            [$webtitle,'home']
        ),
        $settinghelper['brdcrmb_sep']
    );
?>
<?php echo $__env->make('template.'.$settinghelper['template'].'.error404', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>