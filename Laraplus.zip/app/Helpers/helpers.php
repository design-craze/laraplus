<?php
use App\Http\Controllers\Nav\NavController;
use App\Http\Controllers\Setting\SettingController;
use App\Http\Controllers\Widget\WidgetController;
use App\Models\Page;
use App\Models\Setting;

//START : COMMON FUNCTIONS------------------------------------------------------------------------------------

//function backspace
function custombackspace(){
	$a = '\ ';
	$a = str_replace(' ', '', $a);
	return $a;
}

//function getviewpath
function getviewpath(){
	return Config::get('view.paths')[0];
}

//Random Screen
function randomString($a=10){
    $x = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'; $c=strlen($x)-1; $z='';
    for($i=0; $i<$a; $i++){ $y= rand(0, $c); $z .=substr($x, $y, 1); }
    return $z;
}

// getRandKey setting prefix and suffix with string and number
function getRandKey($string=NULL,$limit=NULL,$preFix=NULL,$sufFix=NULL)
{
    // checking if string NULL or NOT
    (!empty($string)) ? $string = $string : $string = "AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz1234567890";  
    // checking if $limit Null or NOT
    (empty($limit) && !empty($string)) ? $limit = (strlen($string)-1) : $limit = ($limit-1);
    // checking if $preFix NULL or NOT
    $oneRand = NULL;
    (!empty($preFix)) ? $oneRand .= $preFix : NULL;
    // Generating Random Key
    for($i = 0; $i <= $limit; $i++)
    {
        $randNum = rand(0, strlen($string)-1);
        $oneRand .= $string[$randNum];
        ($i==$limit && !empty($sufFix)) ? $oneRand .= $sufFix : $oneRand .= NULL;
    }
    // returning Generated Key
    return $oneRand;
}

//Start: Clean String without space
function cleanslug($post=''){
    $post =  preg_replace('/\s\s+/', ' ', $post);
    $post = str_replace(' ', '-', $post); // Replaces all spaces with hyphens.
    $post = preg_replace('/[^A-Za-z0-9\-]/', '', $post); // Removes special chars.
    $post = preg_replace('/-+/', '-', $post);
    $a = substr($post, -1);
    if($a== '-'){
         $post= rtrim($post, '-');
         $post= clean_fields($post);
    }
    return $post;
}

//print_r with pre tag for development
function checkpre($a){
	echo '<pre>';
	print_r($a);
	echo '</pre>';
}

//available data
function ifavailable($a, $b=''){
	$out=false;
	for($i=0; $i<count($a); $i++){
		if(isset($a[$i]) && $a[$i]!=null && $a[$i]!='' && $out==false){
			$out=true;
			return $a[$i];
		}
	}
	if($out==false){
		return $b;
	}
}
//END : COMMON FUNCTIONS--------------------------------------------------------------------------------------


//START : COMNTROLLER FUNCTIONS-------------------------------------------------------------------------------

//get nav for view
function navset($a=null, $id=null){
	$navset = new NavController(); 
	if($a!=null){
		$navset = $navset->allmenu($a);
		return $navset[$a];
	}
	else if($id!=null){
		$navset = $navset->allmenu(null,$id);
		return $navset;
	}
}

//Page menu places for work
function pagemenuplace($a, $id=null){
	$data = explode(',', $a);
	$pageplace = array();

	foreach($data as $val){
		$item = explode('>', $val);
		if(isset($item)){
		$pageplace[$item[0]] = $item[1];
		}
	}
	if($id==null){
		return $pageplace;
	}
	else{
		return $pageplace[$id];
	}
}

//Menu Output for view
function navview($menu, $place){
	if($menu!=''){
		$a = pagemenuplace($menu);
		if(is_array($a) && array_key_exists ($place , $a) && $a[$place]!=0){
			return navset(null, pagemenuplace($menu, $place));
		}
		else{
			return navset($place);
		}
	}
	else{
		return navset($place);
	}
}

//Grab all setting value
function allsetting($a=null){
	$allsetting = new SettingController();
	if($a==null){
		$allsetting = $allsetting->allsetting();
		return $allsetting;
	}
	else{
		$allsetting = $allsetting->singlesetting($a);
		return $allsetting[$a];
	}
}

function getpage($id)
{
	$output = Page::where('id',$id)->first();
	if($output){
		return $output->slug;
	}
}

//Grab Social Icon
// function socialicons($class=''){
// 	$a='';
// 	$socialicons = new SettingController();
// 	$socialicons = $socialicons->socialicons();
// 	if($socialicons!=''){
// 		$a ='<ul class="'.$class.'">';
// 		$a .= $socialicons;
// 		$a .= '</ul>';
// 	}
// 	return $a;
// }

//END : COMNTROLLER FUNCTIONS---------------------------------------------------------------------------------


//START : FUNCTIONS FOR CONTROLLER----------------------------------------------------------------------------

//Language list for work
function language($a=null){
	$language= array(
			'en' => 'English'
		);
	if($a==null){
		return $language;
	}
	else{
		return $language[$a];
	}
}

//Sex list for work
function gender($a=null, $lang='en'){
	$sex= array(
		'en' =>array(
			'nan' => 'Not Defined',
			'm' => 'Male',
			'f' => 'Female'
			)
		);
	if($a==null){
		return $sex[$lang];
	}
	else{
		return $sex[$lang][$a];
	}
}

// active level
function activelevel($active=null, $lang='en')
{
	$level= [
		'en' => [
			1 => 'Deleted',
			2 => 'Suspended',
			3 => 'Inactive',
			4 =>'Active'
		]
	];

	if($active==null){
		return $level[$lang];
	}
	else{
		return $level[$lang][$active];
	}
}

// verification email
function isemailverified($val=null, $lang='en')
{
	$isverified= [
		'en' => [
			1 => 'Not Verified',
			2 => 'Verified'
		]
	];

	if($val==null){
		return $isverified[$lang];
	}
	else{
		return $isverified[$lang][$val];
	}
}

//Country list for work
function country($a=null, $lang='en'){
	$country= array(
		'en' => array(
			'nan' => 'Not Defined',
			'bd' => 'Bangladesh',
			'us' => 'USA'
			)
		);
	if($a==null){
		return $country[$lang];
	}
	else{
		return $country[$lang][$a];
	}
}

//List key
function keystring($array, $seperator){
	$string ='';
	$sep = '';
	foreach($array as $key => $val){
		$string .= $sep.$key;
		$sep=$seperator;
	}
	return $string;
}

//Country list for work
function role($lang='en'){
	$myrole= array(
		'en' =>array(
			'0' => 'All',
			'1' => 'Subscriber',
			'2' => 'Social Member',
			'3' => 'Worker',
			'4' => 'Client',
			'5' => 'Customer',
			'6' => 'Seller',
			'7' => 'Author',
			'8' => 'Editor',
			'9' => 'User Supporter',
			'10' => 'Manager',
			'11' => 'Admin',
			'12' => 'Super Admin',
		   '-1' => 'Unlogged User'
			)
		);
	return $myrole[$lang];
}

function roleaccess($a, $b='en'){
	$c = role($b);
	return $c[$a];
}

//Country list for work
function accesslevel($a, $lang='en', $b='All'){
	$myrole= array(
		'en' =>role($lang='en')
		// array(
		// 	'0' => $b,
		// 	'1' => 'User',
		// 	'2' => 'Editor',
		// 	'3' => 'Manager',
		// 	'4' => 'Administrator',
		//    '-1' => 'Unlogged User'
		// 	)
		);
	return $myrole[$lang][$a];
}

function commentstatus($lang='en'){
	$status = array(
		'en' =>array(
			'0' => 'Unapprove',
			'1' => 'Approve'
			)
		);
	return $status[$lang];
}

function accesscommentstatus($a, $lang='en'){
	$status= array(
		'en' =>commentstatus($lang='en')
		);
	return $status[$lang][$a];
}

//Access Level comparison for work
function accesscompare($userlevel, $lang='en'){
	
	$accesslevel= array(
		'en' => 'You Need To Be Minimum At ' . accesslevel($userlevel, $lang) . ' Level To Access This Page.'
		);
	
	return $accesslevel[$lang];
}

//Access Level comparison for Unlogged user
function accessunloggeduser($lang='en'){
		$accesslevel= array(
			'en' => 'You Need To Be Unlogged User To Access This Page.'
			);
	return $accesslevel[$lang];
}
//Access Level comparison for work
function accessexactuser($user, $lang='en'){
		$accesslevel= array(
			'en' => 'You Need To Be ' . $user . ' To Access This Page.'
			);
	return $accesslevel[$lang];
}

//Check if a page is home page for admin work
function ishome($a, $b=null){
	if($a==1){
		if($b==null){
			return 'Home';
		}
		else{
			return ' '.$b.' <strong>( Selected As HOME )</strong>';
		}
	}
}

//Template list for work
function templates($a=null){
	// $path = base_path().'\resources\views\template';
	$path = getviewpath().'/template';
	$initial = scandir($path);
	$directories = array();
	$directories['default'] = 'default';
	foreach($initial as $init){
		if($init !='.' && $init !='..' && $init !='default'){
			$directories[$init] =  $init;
		}
	}
	if($a==null){
		return $directories;
	}
	else{
		return $directories[$a];
	}
}

//Page Template list for work
function pagetemplates($a=null){
	// $path = base_path().'\resources\views\template' . custombackspace() . allsetting('template') . '\page-template';
	$path = getviewpath().'/template/'. allsetting('template') . '/page-template';
	$initial = scandir($path);
	$files = array();
	$files['default'] = 'default';
	foreach($initial as $init){
		if($init !='.' && $init !='..' && $init !='default.blade.php'){
			$files[substr($init, 0,-10)] =  substr($init, 0,-10);
		}
	}
	if($a==null){
		return $files;
	}
	else{
		return $files[$a];
	}
}

//END : FUNCTIONS FOR CONTROLLER------------------------------------------------------------------------------

function widget_area($a=null){
	$widget_area = array(
		'sg' => 'Sidebar-general',
		'sb' => 'Sidebar-blog',
		'ss' => 'Sidebar-store',
		'f1' => 'Footer-1',
		'f2' => 'Footer-2',
		'f3' => 'Footer-3',
		'f4' => 'Footer-4'
	);
	if($a==null){
		return $widget_area;
	}
	else{
		return $widget_area[$a];
	}
}

function widget_type($key){
	$output = array('item', 'detail', 'menu', 'searchblog', 'loginuser', 'metatag');
	return $output[$key];
}

function getwidget($widgetslug){
	$a='<div class="'.widget_area($widgetslug).'">';
	$allwidget = new WidgetController();
	$allwidget = $allwidget->widgetset($widgetslug);
	if($allwidget){
		foreach($allwidget as $val){
			$b = widget($val->widget_slug, $val->content, $val->name);
			$a .= $b[0];
		}
	}
	$a .='</div>';
	return $a;
}

function widget($key=null, $data=null, $data2=null){
	$a=array();
	if($key=='recent_post'){
		$widget = array('recent_post' => [recent_posts_widget($data, $data2), widget_type(0), 'Recent Post']);
	}
	else if($key=='popular_post'){
		$widget = array('popular_post' => [popular_posts_widget($data, $data2), widget_type(0), 'Popular Post']);
	}
	else if($key=='html_widget'){
		$widget = array('html_widget' => [html_widget($data, $data2), widget_type(1), 'HTML Text']);
	}
	else if($key=='menu_widget'){
		$widget = array('menu_widget' => [menu_widget($data, $data2), widget_type(2), 'Menu Item']);
	}
	else if($key=='search_blog'){
		$widget = array('search_blog' => [searchblog_widget($data, $data2), widget_type(3), 'Search Blog']);
	}
	else if($key=='user_login'){
		$widget = array('user_login' => [login_widget($data, $data2), widget_type(4), 'User Login']);
	}
	else if($key=='meta_keytag'){
		$widget = array('meta_keytag' => [metakey_widget($data, $data2), widget_type(4), 'Meta Key']);
	}
	else{
		$widget = array(
			'recent_post' => [recent_posts_widget($data, $data2), widget_type(0), 'Recent Post'],
			'popular_post' => [popular_posts_widget($data, $data2), widget_type(0), 'Popular Post'],
			'html_widget' => [html_widget($data, $data2), widget_type(1), 'HTML Text'],
			'menu_widget' => [menu_widget($data, $data2), widget_type(2), 'Menu Item'],
			'search_blog' => [searchblog_widget($data, $data2), widget_type(3), 'Search Blog'],
			'user_login' => [login_widget($data, $data2), widget_type(4), 'User Login'],
			'meta_keytag' => [metakey_widget($data, $data2), widget_type(5), 'Meta Key']
		);
	}
	if($key != null && $data !=null){
		return $widget[$key];
	}
	elseif($key != null && $data ==null){
		array_push($a, $widget[$key][1]);
		array_push($a, $widget[$key][2]);
		return $a;
	}
	else{
		foreach($widget as $key => $val){
			$a[$key] = array($val[1], $val[2]);
		}
		return $a;
	}
}

function recent_posts_widget($data, $data2=null){
	$recent_posts = new WidgetController();
	$recent_posts = $recent_posts->recent_posts($data);
	$output ='<div class="recent-post widget">';
	if($data2!=null){
		$output .='<h3>'.$data2.'</h3>';
	}
	if($recent_posts!=null){
		foreach($recent_posts as $rp){
			$output .= 	'<div class="post-thumb-widget">'.
							'<div class="blog-mini-thumb">'.
								'<img src="';
				if($rp->thumb!=''){
				$output .= 	e($rp->thumb);
				}
				else{
				$output .= 	asset('assets/common/images/no-thumb.jpg');
				}
				$output .= '" alt="';
				if($rp->thumb!=''){
				$output .= 	e($rp->thumb);
				}
				$output .= 	'">'.
							'</div>'.
							'<div class="blog-mini-thumb-content">'.
								'<h4 class="blog-mini-thumb-title"><a href="' . route('blog', ['slug'=>$rp->slug]).'">'.strip_tags($rp->name) . '</a></h4>'.
								'<p class="blog-mini-thumb-text">' . substr(strip_tags($rp->description), 0, 50) . '</p>'.
								'<p class="blog-mini-thumb-time">'. time_elapsed_string($rp->updated_at) . '</p>'.
							'</div>'.
						'</div>';
		}
	}
	$output .= '</div>';
	return $output;
}

function popular_posts_widget($data, $data2=null){
	$popular_posts = new WidgetController();
	$popular_posts = $popular_posts->popular_posts($data);
	$output ='<div class="popular-post widget">';
	if($data2!=null){
		$output .='<h3>'.$data2.'</h3>';
	}
	if($popular_posts!=null){
		foreach($popular_posts as $rp){
			$output .= 	'<div class="post-thumb-widget">'.
							'<div class="blog-mini-thumb">'.
								'<img src="';
				if($rp->thumb!=''){
				$output .= 	e($rp->thumb);
				}
				else{
				$output .= 	asset('assets/common/images/no-thumb.jpg');
				}
				$output .= '" alt="';
				if($rp->thumb!=''){
				$output .= 	e($rp->thumb);
				}
				$output .= 	'">'.
							'</div>'.
							'<div class="blog-mini-thumb-content">'.
								'<h4 class="blog-mini-thumb-title"><a href="' . route('blog', ['slug'=>$rp->slug]).'">'.strip_tags($rp->name) . '</a></h4>'.
								'<p class="blog-mini-thumb-text">' . substr(strip_tags($rp->description), 0, 50) . '</p>'.
								'<p class="blog-mini-thumb-time">'. time_elapsed_string($rp->updated_at) . '</p>'.
							'</div>'.
						'</div>';
		}
	}
	$output .= '</div>';
	return $output;
}

function menu_widget($data, $data2=null){
	$output ='<div class="widget-menu widget">';
	if($data2!=null){
		$output .='<h3>'.$data2.'</h3>';
	}
	$output .= navset(null, $data);
	$output .= '</div>';
	return $output;
}

function html_widget($data, $data2=null){
	$output ='<div class="html-text widget">';
	if($data2!=null){
		$output .='<h3>'.$data2.'</h3>';
	}
	$output .= '<div>';
	$output .= $data;
	$output .= '</div>';
	$output .= '</div>';
	return $output;
}
function searchblog_widget($data, $data2=null){
	$search_blog = new WidgetController();
	$search_blog = $search_blog->blogsearch($data);
	$output ='<div class="search-blog widget">';
	if($data2!=null){
		$output .='<h3>'.$data2.'</h3>';
	}
	$output .= $search_blog;
	$output .= '</div>';
	return $output;
}

function login_widget($data, $data2=null){
	$user_login = new WidgetController();
	$user_login = $user_login->usermeta($data);
	$output ='<div class="login-user widget">';
	if($data2!=null){
		$output .='<h3>'.$data2.'</h3>';
	}
	$output .= $user_login;
	$output .= '</div>';
	return $output;
}

function metakey_widget($data, $data2=null){
	$output ='<div class="meta-key widget">';
	if($data2!=null){
		$output .='<h3>'.$data2.'</h3>';
	}
	$output .= '<div class="dc-metatag"></div>';
	$output .= '</div>';
	return $output;
}

// image path------------------------
function path_favicon(){
 return 'assets/common/images/favicon/';
}

function path_logo(){
 return 'assets/common/images/logo/';
}

function path_images(){
 return 'assets/common/images/';
}

function path_thumbs(){
 	return path_images().'thumbs/';
}

function path_profile(){
 	return path_images().'profile/';
}
// image uploading system
function uploadimage($img,$path,$width=null,$height=null)
{
    // saving image in target path
	$imgName = uniqid() . '.' . $img->getClientOriginalExtension();
	$imgPath = public_path($path.$imgName);

	// configure with favored image driver (gd by default)
	// Image::configure(array('driver' => 'imagick'));

	// making image
	$makeImg = Image::make($img);
	if($width!=null && $height!=null && is_int($width) && is_int($height))
	{
		// $makeImg->resize($width, $height);
		$makeImg->fit($width, $height);
	}

	if($makeImg->save($imgPath))
	{
		return $imgName;
	}
	return false;
}
// for deleting uploaded image in server folder
function removeuploadedimage($imgName, $path)
{
	$imagePath = public_path($path).$imgName;
	$deletedImg = File::delete($imagePath);

	if($deletedImg)
	{
	    return true;
	}
	return false;
}




// date fuction
function getDateFormat($date = null, $format = 'd M, Y @ h:ia', $timezone = 'Europe/London')
{
	if($date == null)
	{
		$date = date('d-m-Y H:i:s');
	}

	date_default_timezone_set($timezone);
	echo date_format(date_create($date),$format);
}

function time_elapsed_string($datetime, $full = false) {
    $now = new DateTime;
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    $diff->w = floor($diff->d / 7);
    $diff->d -= $diff->w * 7;

    $string = array(
        'y' => 'year',
        'm' => 'month',
        'w' => 'week',
        'd' => 'day',
        'h' => 'hour',
        'i' => 'minute',
        's' => 'second',
    );
    foreach ($string as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
        } else {
            unset($string[$k]);
        }
    }

    if (!$full) $string = array_slice($string, 0, 1);
    return $string ? implode(', ', $string) . ' ago' : 'just now';
}

function google_map_type()
{
	$type = array(
		1 => 'ROADMAP',
		2 => 'SATELLITE',
		3 => 'HYBRID',
		4 => 'TERRAIN'
	);

	return $type;
}

function pagination($myposts, $getelements, $param = array()){
	if(array_key_exists('route', $param)==false){$param['route']='home';}
	if(array_key_exists('routeslug', $param)==false){$param['routeslug']='';}
	if(array_key_exists('first', $param)==false){$param['first']='First';}
	if(array_key_exists('last', $param)==false){$param['last']='Last';}
	if(array_key_exists('prev', $param)==false){$param['prev']='Prev';}
	if(array_key_exists('next', $param)==false){$param['next']='Next';}
?>
	<div class="common-pagination">
		<?php 
			$pagifpname = $param['first']; $pagippname = $param['prev']; $pagilpname = $param['last']; $paginpname = $param['next'];
			if($myposts->currentPage() == '1'){
				$pagifp = '<span>'.$pagifpname.'</span>'; $pagipp = '<span>'.$pagippname.'</span>';
			}
			else{
				if($param['routeslug']==''){
					$pagifp = '<a href="'.route($param['route']).'?';
				}
				else{
					$pagifp = '<a href="'.route($param['route'],$param['routeslug']).'?';
				}
				foreach($getelements as $key => $val){
	            	$pagifp .= $key.'='.$val.'&';
		        }
				$pagifp .= 'page=1'.'">'.$pagifpname.'</a>'; $pagipp = '<a href="'.$myposts->previousPageUrl().'">'.$pagippname.'</a>';
			}
			if($myposts->lastPage() == $myposts->currentPage()){
				$pagilp = '<span>'.$pagilpname.'</span>'; $paginp = '<span>'.$paginpname.'</span>';
			}
			else{
				if($param['routeslug']==''){
					$pagilp = '<a href="'.route($param['route']).'?';
				}
				else{
					$pagilp = '<a href="'.route($param['route'],$param['routeslug']).'?';
				}
				foreach($getelements as $key => $val){
	            	$pagilp .= $key.'='.$val.'&';
		        }
				$pagilp .= 'page='.$myposts->lastPage().'">'.$pagilpname.'</a>'; $paginp = '<a href="'.$myposts->nextPageUrl().'">'.$paginpname.'</a>';
			}
		?>
		<?php if($myposts->total()>$myposts->count()){ ?>
			<ul class="prevsec">
				<li><?php echo $pagifp; ?></li>
				<li><?php echo $pagipp; ?></li>
			</ul>
			<?php echo $myposts->links(); ?>
			<ul class="nextsec">
				<li><?php echo $paginp; ?></li>
				<li><?php echo $pagilp; ?></li>
			</ul>
			<div style="clear:both"></div>
		<?php } ?>
	</div>
<?php
}


function social_media($settinghelper, $title='', $class=''){
	if($settinghelper['facebook'] !='' || $settinghelper['twitter'] !='' || $settinghelper['linkedin'] !='' || $settinghelper['google'] !='' || $settinghelper['skype'] !='' || $settinghelper['youtube'] !='' || $settinghelper['vimeo'] !='' || $settinghelper['pinterest'] !='' || $settinghelper['flickr'] !='' || $settinghelper['instagram'] !='' || $settinghelper['rss'] !=''){
	?>
	    <div class="dc-social">
		    <?php if( $title!=''){ ?>
		        <h5>
		            <strong><?php echo $title; ?></strong>
		        </h5>
		    <?php } ?>
	        <ul<?php if($class!=''){echo ' class="'. $class .'"';}?>>
	            <?php
	                if($settinghelper['facebook'] !=''){
	                    echo '<li class="fb"><a href="'.$settinghelper['facebook'].'" target="_blank"><i class="fa fa-facebook"></i></a></li>';
	                }
	                if($settinghelper['twitter'] !=''){
	                    echo '<li class="tw"><a href="'.$settinghelper['twitter'].'" target="_blank"><i class="fa fa-twitter"></i></a></li>';
	                }
	                if($settinghelper['linkedin'] !=''){
	                    echo '<li class="in"><a href="'.$settinghelper['linkedin'].'" target="_blank"><i class="fa fa-linkedin"></i></a></li>';
	                }
	                if($settinghelper['google'] !=''){
	                    echo '<li class="gp"><a href="'.$settinghelper['google'].'" target="_blank"><i class="fa fa-google-plus"></i></a></li>';
	                }
	                if($settinghelper['skype'] !=''){
	                    echo '<li class="sk"><a href="'.$settinghelper['skype'].'" target="_blank"><i class="fa fa-skype"></i></a></li>';
	                }
	                if($settinghelper['youtube'] !=''){
	                    echo '<li class="yt"><a href="'.$settinghelper['youtube'].'" target="_blank"><i class="fa fa-youtube"></i></a></li>';
	                }
	                if($settinghelper['vimeo'] !=''){
	                    echo '<li class="vm"><a href="'.$settinghelper['vimeo'].'" target="_blank"><i class="fa fa-vimeo"></i></a></li>';
	                }
	                if($settinghelper['pinterest'] !=''){
	                    echo '<li class="pn"><a href="'.$settinghelper['pinterest'].'" target="_blank"><i class="fa fa-pinterest"></i></a></li>';
	                }
	                if($settinghelper['flickr'] !=''){
	                    echo '<li class="fl"><a href="'.$settinghelper['flickr'].'" target="_blank"><i class="fa fa-flickr"></i></a></li>';
	                }
	                if($settinghelper['instagram'] !=''){
	                    echo '<li class="ins"><a href="'.$settinghelper['instagram'].'" target="_blank"><i class="fa fa-instagram"></i></a></li>';
	                }
	                if($settinghelper['rss'] !=''){
	                    echo '<li class="rss"><a href="'.$settinghelper['rss'].'" target="_blank"><i class="fa fa-rss"></i></a></li>';
	                }
	            ?>
	        </ul>
	    </div>
	<?php } 
}

function taglink($tag){
	return route('searchblog') . '/?tag='.$tag;
}


function arrayvalidation($pram, $extra=''){
    $output = array();
    foreach($pram as $key => $val){
        array_push($output, $key);
    }
    return $extra.implode(',', $output);
}

function breadcrumb($input, $seperator='/'){ // (name, routename, routeslug array) 

	// array(
			// 0 => $name,
			// 1 => $routename,
			// 2 => $routekeyarray(),
	// )
	$output = '<div class="dc-breadcrumb"><ul class="clearfix">';
	$sep = '';
	foreach ($input as $brcrarray) 
	{
		$output .= '<li>';
		$output .= trim($sep) . '<a href="';
		if (array_key_exists(2,$brcrarray)){
			$output .= route($brcrarray[1], $brcrarray[2]);
		}
		else{
			$output .= route($brcrarray[1]);
		}

		$output .= '">';
		$output .= $brcrarray[0];
		$output .= '</a></li>';
		$sep = ' ' . $seperator . ' ';
	}

	$output .= '</ul></div>';
	return $output;
}

function generate_shortcode($data){
	return App::make('App\Http\Controllers\Shortcode\Shortcodes')->do_shortcode($data);
}