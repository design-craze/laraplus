<?php

namespace App\Models;

// use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    protected $fillable =['username', 'email', 'password', 'fname', 'lname', 'role', 'active', 'verified', 'logcode', 'vfcode', 'updated_at'];
    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = ['remember_token'];

    public function userinfo()
    {
        return $this->hasOne('App\Models\Userinfo');
    }
    
    public function blogs(){
    	return $this->hasMany('App\Models\Blog');
    }

    public function comments(){
    	return $this->hasManyThrough('App\Models\Comment', 'App\Models\Blog', 'user_id', 'blog_id');
    }

    public function  givencomments(){
    	return $this->hasMany('App\Models\Comment', 'user_id', 'id');
    }
}
