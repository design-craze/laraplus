<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Comment extends Model
{
    protected $fillable =['blog_id','user_id', 'parent_id','description', 'is_approved', 'updated_at'];

    public function blog(){
    	return $this->belongsTo('App\Models\Blog');
    }

    public function user(){
    	return $this->belongsTo('App\Models\User');
    }

    public function userinfo(){
    	return $this->belongsTo('App\Models\Userinfo', 'user_id', 'user_id');
    }
}
