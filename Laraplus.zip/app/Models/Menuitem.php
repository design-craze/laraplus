<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Menuitem extends Model
{
    protected $fillable = ['parent_id', 'menu_id', 'name', 'page_id', 'blog_id', 'link', 'class', 'newtab', 'megamenu', 'serial', 'updated_at'];
}
