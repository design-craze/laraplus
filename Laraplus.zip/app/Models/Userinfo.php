<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Userinfo extends Model
{
	protected $fillable =['user_id', 'street1', 'street2', 'city', 'state', 'zip', 'country', 'sex', 'contact', 'description', 'dob', 'avatar', 'updated_at'];
    public function user()
    {
        return $this->belongsTo('App\Models\User');
    }
}
