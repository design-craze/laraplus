<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Validator;
use App\Models\User;
use Mail;

class SuspendedController extends Controller
{
	public function __construct()
    {
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin')->send();
        }
    }

    public function suspended()
    {
    	if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
			if(Auth::user()->role >= 10)
			{
				if((Auth::user()->verified ==2 && Auth::user()->active == 4) || Auth::user()->role == 12) 
				{
					return redirect()->route('admindashboard');
				}
				else{
					return view('admin.suspended');
				}
			}
        }
    }

    public function suspendedmessageprocess(Request $request)
    {
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10)
            {
            	$rules = [ 
                    'usermessage'=>'required'
                ];

                $messages = [ 
                    'usermessage.required' => 'Message field can not be empty!',
                ];

                $validator = Validator::make($request->all(), $rules, $messages);
                if ($validator->fails()) {
                    return redirect()->back()->withErrors($validator)->withInput();
                }
                else
                {
                	// sending mail
                	$settinghelper = allsetting();

                	$admin = User::where('role',12)->first();
        			$userName = $admin->fname . ' ' . $admin->lname;

                    if($settinghelper['contact_email']!='')
                    {
                    	$userEmail = $settinghelper['contact_email']; 
                    }
                    else
                    {
                    	$userEmail = $admin->email;
                    }

                    $subject = 'Account Active Request | Larapress';

                    $sentmail = Mail::send(
                        'admin.emails.requestactive',
                        ['admin' => $admin,'user' => Auth::user(),'usermessage' => $request->usermessage],
                        function ($message) use ($userName, $userEmail, $subject)
                        {
                            $message->to($userEmail, $userName)->subject($subject)->replyTo(
                                Auth::user()->email, Auth::user()->fname . ' ' . Auth::user()->lname
                            );
                        }
                    );

                    if($sentmail)
                    {
                    	return redirect()->back()->with('success','Message has been successfully sent. We will get in touch in soon.');
                    }
                    else{
                    	return redirect()->back()->with('dissmiss','Message can not be sent now. Please try again.');
                    }

                }
            }
        }
    }
}
