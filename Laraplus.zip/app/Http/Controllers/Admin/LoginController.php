<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Validator;
use Session;

class LoginController extends Controller
{
    public function login(){
        if (Auth::user()){                                     //Authentication for logged users
            if(Auth::user()->role >= 10){
                // code goes here.
                return redirect()->route('admindashboard');
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    	return view('admin.login');
    }

    public function logout(){
    		if (Auth::user()){                                //Authentication for logged users
        		Auth::logout();
            }
    		return redirect()->back();
    }

    public function loginprocess(Request $request){

       if(!Auth::user()){
        	$rules = [ 
                'user'=>'required', 
                'password'=>'required'
                ];
            $messages = [ 
                'user.required' => 'Fill up user field', 
                'password.required'   => 'Fill up password.'
                ];
                
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return redirect()->back()->withErrors($validator)->withInput();
            }
            else{
                // remember user setting
            	if(filter_var($request->user, FILTER_VALIDATE_EMAIL) == false){
            		if(Auth::attempt(['username'=>$request->user, 'password'=>$request->password],$request->has('remember_me'))){
                        // checking if account deleted or not
                        if(Auth::user()->active == 1 && Auth::user()->role != 12)
                        {
                            Auth::logout();
                            return redirect()->back()->with(['dissmiss'=> 'Oops, The user is deleted.'])->withInput();
                        }
            			return redirect()->back()->with(['success'=> 'Successfully logged in']);
            		}
            	}
            	else{
            		if(Auth::attempt(['email'=>$request->user, 'password'=>$request->password],$request->has('remember_me')))
                    {
                        // checking if account deleted or not
                        if(Auth::user()->active == 1 && Auth::user()->role != 12)
                        {
                            Auth::logout();
                            return redirect()->back()->with(['dissmiss'=> 'Oops, The user is deleted.'])->withInput();
                        }
                        return redirect()->back()->with(['success'=> 'Successfully logged in']);
            		}
            	}
            	return redirect()->back()->with(['dissmiss'=> 'Login Unsuccessful! Try Again']);
        	}
        }
        else{
            return redirect()->back();
        }
    }
}
