<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;

use App\Http\Requests;
use Validator;
use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\BlogCategory;
use Illuminate\Support\Facades\Auth;

class CategoryController extends Controller
{
    public function managecategory()
    {
    	if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
             if(Auth::user()->role >= 10){                      //Authentication for Minimum Managers
                // $data['getelements'] = array(
                //     'sdf' =>''
                // );
                // foreach($data['getelements'] as $key => $val){
                //     if ($val == ''){
                //         unset($data['getelements'][$key]);
                //     }
                // }
                $data['catges'] = Category::where(['trashed' => '0'])->paginate(10);
                //->appends($data['getelements']);
                return view('admin.categories', $data);
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    public function trashcategory()
    {
    	if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
             if(Auth::user()->role >= 10){                      //Authentication for Minimum Managers
                // $data['getelements'] = array(
                //     'sdf' =>''
                // );
                // foreach($data['getelements'] as $key => $val){
                //     if ($val == ''){
                //         unset($data['getelements'][$key]);
                //     }
                // }
                $data['trashcatgs'] = Category::where(['trashed' => '1'])->paginate(10);
                //->appends($data['getelements']);
                return view('admin.trashcategories', $data);
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    // trash category
    public function tempcatgdelete($id)
    {
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else
        {
            if(Auth::user()->role >= 10){
                $update = Category::where(['id'=> $id,'trashed' => 0])->update(['trashed' => 1]);
                if($update){
                    return redirect()->route('managecategory')->with(['success'=> 'The Category Has Been Sent To Trash Successfully']);
                }
                else{
                    return redirect()->route('managecategory')->with(['dissmiss'=> 'This Category Can not be Sent to Trash for Some Reasons']);
                }
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    public function restorecatg($id){
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else
        {
            if(Auth::user()->role >= 10){
                $ctg = Category::where(['id' => $id, 'trashed' => 1])->first();

                if($ctg){
                    $update = Category::where('id', $id)->update(['trashed' => 0]);
                    if($update){
                        return redirect()->route('trashcategory')->with(['success'=> 'This Category Has Been Restored Successfully']);
                    }
                    else{
                        return redirect()->route('trashcategory')->with(['dissmiss'=> 'This Category Can not be Restored for Some Reasons']);
                    }
                }
                else{
                    return redirect()->route('trashcategory')->with(['dissmiss'=> 'There is no Such Category to Restore']);
                }
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    // permanently deleting category 
    public function permcatgdelete($id){
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else
        {
            if(Auth::user()->role >= 10){
                $ctg = Category::where(['id' => $id, 'trashed' => 1])->first();

                if($ctg){
                    // checking value if exist in pivot table or not
                    $ctgBlog = $ctg->blogs()->count();
                    
                    if($ctgBlog == 0){
                        $delete = Category::where('id', $ctg->id)->delete();
                        if($delete){
                            return redirect()->route('trashcategory')->with(['success'=> 'This Category Has Been Deleted Successfully.']);
                        }
                        else{
                            return redirect()->route('trashcategory')->with(['dissmiss'=> 'This Category Can not be deleted for some reason.']);
                        }
                    }
                    else{
                        return redirect()->route('trashcategory')->with(['dissmiss'=> 'This Category Can not be deleted as it has Blogs.']);
                    }
                }
                else{
                    return redirect()->route('trashcategory')->with(['dissmiss'=> 'There is no Such Category to Delete']);
                }
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    // createing new category
    public function createnewcategory()
    {
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10)
            {
                return view('admin.newcategory');
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    // category creating process
    public function createcategoryprocess(Request $request)
    {

        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10)
            {
                $rules = [ 
                    'name'=>'required', 
                    'ctgslug'=>'required' 
                    ];
                $messages = [ 
                    'name.required' => 'Fill up Category Name Field', 
                    'ctgslug.required'   => 'Fill up Category Slug Field.'
                    ];
                    
                $validator = Validator::make($request->all(), $rules, $messages);
                if ($validator->fails()) {
                    return redirect()->back()->withErrors($validator)->withInput();
                }
                else {
                    $slug = cleanslug($request->ctgslug);
                    $finalslug = $slug;
                    for($i=0; $i>-1; $i++){
                        $sameslug = Category::where('ctgslug', $finalslug)->count();
                        if($sameslug > 0){
                            $finalslug = $slug . '-' . ($i+1);
                        }
                        else{
                            $i= -10;
                        }
                    }
                    $input = $request->except('_token', 'ctgslug');
                    $input['ctgslug'] = $finalslug;
                    $inserted = Category::create($input)->id;
                    if($inserted){
                        return redirect()->route('editcategory', ['id' => $inserted])->with(['success'=> 'Category Has been Created Successfully']);
                    }
                    else{
                        return redirect()->back()->with(['dissmiss'=> 'Category Can not be created for some reason']);
                    }
                }       
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    // category edit function 
    public function editcategory ($id)
    {
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10)
            {
                $data['singlecategory'] = Category::where(['id' => $id, 'trashed' => 0])->firstOrFail();
                return view('admin.editcategory',$data);       
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    // edit category process
    public function editcategoryprocess($id, Request $request)
    {
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10)
            {
                $rules = [ 
                    'name'=>'required', 
                    'ctgslug'=>'required' 
                    ];
                $messages = [ 
                    'name.required' => 'Fill up Category Name Field', 
                    'ctgslug.required'   => 'Fill up Category Slug Field.'
                    ];
                    
                $validator = Validator::make($request->all(), $rules, $messages);
                if ($validator->fails()) {
                    return redirect()->back()->withErrors($validator)->withInput();
                }
                else {
                    if($request->ctgslug!=null){
                        $slug = cleanslug($request->ctgslug);
                        $finalslug = $slug;
                        for($i=0; $i>-1; $i++){
                            $sameslug = Category::where('ctgslug', $finalslug)->first();
                            if(count($sameslug) > 0 && $sameslug->id != $id){
                                $finalslug = $slug . '-' . ($i+1);
                            }
                            else{
                                $i= -10;
                            }
                        }
                    }

                    $update = $request->except('_token', 'ctgslug');
                    if($request->ctgslug!=null){
                        $update['ctgslug'] = $finalslug;
                    }
                    $edited = Category::where('id', $id)->update($update);
                    if($edited){
                        return redirect()->route('editcategory', ['id' => $id])->with(['success'=> 'Category Has been Edited Successfully']);
                    }
                    else{
                        return redirect()->back()->with(['dissmiss'=> 'Category Can not be edited for some reason']);
                    }
                }           
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }
}
