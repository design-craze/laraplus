<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\Menu;
use App\Models\Menuplace;
use App\Models\Menuitem;
use App\Models\Page;
use App\Models\Blog;
use Validator;
use Illuminate\Support\Facades\Auth;

class NavController extends Controller
{
    protected $serial=0;
    protected $sign='';
    protected $mainid='';
    protected $parentid='';
    protected $menuid='';
    protected $name='';
    protected $pageid='';
    protected $blogid='';
    protected $link='';
    protected $class='';
    protected $newtab='';
    protected $megamenu='';
    protected $myserial='';

    public function index(){
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10){                  //Authentication for Minimum Managers
                $data['logged_id'] = Auth::user()->id;
                $data['logged_role'] = Auth::user()->role;

                $data['selectnavs'] = Menu::get();
                $data['getpage'] = Page::orderBy('name', 'desc')->get();
                $data['getblog'] = Blog::orderBy('created_at', 'desc')->skip(0)->take(50)->get();

                $a = Menu::where('selected', 1)->first();
                $b = $a->menuitems;
                $data['mainmenuid'] =$a->id;
                $data['menu'] = '<ol class="mymenu">';
                if($b){
                    $data['menu'] .= $this->innermenu($a);
                }
                $data['menu'] .= '</ol>';
                $data['menuinputs'] = '<input type="hidden" name="mainid" id="mainid" value="'.$this->mainid.'">'.
                                      '<input type="hidden" name="parentid" id="parentid" value="'.$this->parentid.'">'.
                                      '<input type="hidden" name="menuid" id="menuid" value="'.$this->menuid.'">'.
                                      '<input type="hidden" name="name" id="name" value="'.$this->name.'">'.
                                      '<input type="hidden" name="pageid" id="pageid" value="'.$this->pageid.'">'.
                                      '<input type="hidden" name="blogid" id="blogid" value="'.$this->blogid.'">'.
                                      '<input type="hidden" name="link" id="link" value="'.$this->link.'">'.
                                      '<input type="hidden" name="class" id="class" value="'.$this->class.'">'.
                                      '<input type="hidden" name="newtab" id="newtab" value="'.$this->newtab.'">'.
                                      '<input type="hidden" name="megamenu" id="megamenu" value="'.$this->megamenu.'">'.
                                      '<input type="hidden" name="myserial" id="myserial" value="'.$this->myserial.'">'.
                                      '<input type="hidden" name="deletedid" id="deletedid" value="">';
                return view('admin.menu', $data);
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    protected function innermenu($dbdata, $parent_id=0, $result=NULL){
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10){                  //Authentication for Minimum Managers
                $data['logged_id'] = Auth::user()->id;
                $data['logged_role'] = Auth::user()->role;

                foreach ($dbdata->menuitems as $row){
                    $count=0;
                    if($row->parent_id == $parent_id){
                        $ol=FALSE;
                        $b = $row->serial;

                        $this->serial++;
                        $this->mainid .=$this->sign . $row->id;
                        $this->parentid .=$this->sign . $row->parent_id;
                        $this->menuid .=$this->sign . $row->menu_id;
                        $this->name .=$this->sign . $row->name;
                        $this->pageid .=$this->sign . $row->page_id;
                        $this->blogid .=$this->sign . $row->blog_id;
                        $this->link .=$this->sign . $row->link;
                        $this->class .=$this->sign . $row->class;
                        $this->newtab .=$this->sign . $row->newtab;
                        $this->megamenu .=$this->sign . $row->megamenu;
                        $this->myserial .=$this->sign . $row->serial;
                        $this->sign='>';

                        $result .= '<li data-id="'.$row->id.'" data-parentid="'.$row->parent_id.'" data-menuid="'.$row->menu_id.'" data-name="'.$row->name.'" data-pageid="'.$row->page_id.'" data-blogid="'.$row->blog_id.'" data-link="'.$row->link.'" data-class="'.$row->class.'" data-newtab="'.$row->newtab.'" data-megamenu="'.$row->megamenu.'" data-serial="'.$this->serial.'">';
                        $result .= '<div class="innermenu">'.
                                        '<div class="innermenuhead">'.
                                            '<div class="title">';
                        if($row->name !=''){
                            $result .= $row->name;
                        }
                        else{
                            $result .= 'Unnamed';
                        }
                        $result .=          '</div>'.
                                            '<div class="type"><span class="arrow-icon">';
                        if($row->page_id > 0){
                            $result .= 'Page';
                        }
                        elseif($row->blog_id > 0){
                            $result .= 'Blog';
                        }
                        else{
                            $result .= 'Custom';
                        }
                        $result .=          ' <i class="fa fa-caret-right"></i></span></div>'.
                                        '</div>'.
                                        '<div class="innermenubody">';
                        $result .=                  '<p><label>Navigation Label<br></label><input type="text" class="name" value="'.$row->name.'"></p>';

                        //Create Links for menu anchor tag
                        if($row->page_id == 0 && $row->blog_id == 0){
                            $result .= '<p><label>Link<br></label><input type="text" class="link" value="'.$row->link.'"></p>';
                        }
                        //End Links for menu anchor tag
                            $result .= '<p><label>Extra Class<br></label><input type="text" class="class" value="'.$row->class.'"></p>';

                        $result .=                  '<p><label for=""></label><input type="checkbox" class="newwindow"';
                        if($row->newtab==1){
                            $result .=              ' checked';
                        }
                        $result .=                  '><em>Open link in a new window/tab</em></p>'.
                                                    '<p class="mymgmenu"><label for=""></label><input type="checkbox" class="megamenu"';
                        if($row->megamenu==1){
                            $result .=              ' checked';
                        }
                        $result .=                  '><em>Use As Mega Menu</em></p>';
                        $result .=                  '<hr class="myhrborder">'.
                                                    '<button class="deletebutton">Remove</button>'.
                                                '</div>'.
                                            '</div>';
                        
                        foreach ($dbdata->menuitems as $row){
                            if($row->parent_id ==$b && $count<1){
                                if($ol==FALSE){
                                $result .= '<ol>';
                                    $ol=TRUE;
                                }
                                $count++;
                                $result .= $this->innermenu($dbdata, $b);
                            }
                        }
                        if($ol==TRUE){
                            $result .= '</ol>';
                            $ol==FALSE;
                        }
                        $result .= '</li>';
                    }
                }
                return $result;
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    protected function savenav(Request $request){
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10){                  //Authentication for Minimum Managers
                $data['logged_id'] = Auth::user()->id;
                $data['logged_role'] = Auth::user()->role;

                $mysign = '>';
                if($request->changemenu!=null){
                    Menu::where('selected', '1')->update(array('selected' => '0'));
                    Menu::where('id', $request->getmenu)->update(array('selected' => '1'));
                    return redirect()->route('adminnav');
                }
                else if($request->savemenu!=null){
                    $mainid=explode($mysign,$request->mainid);
                    $parentid=explode($mysign,$request->parentid);
                    $menuid=explode($mysign,$request->menuid);
                    $name=explode($mysign,$request->name);
                    $pageid=explode($mysign,$request->pageid);
                    $blogid=explode($mysign,$request->blogid);
                    $link=explode($mysign,$request->link);
                    $class=explode($mysign,$request->class);
                    $newtab=explode($mysign,$request->newtab);
                    $megamenu=explode($mysign,$request->megamenu);
                    $myserial=explode($mysign,$request->myserial);
                    $deletedid=explode($mysign,$request->deletedid);
                    $count = count($menuid);
                    // checkpre($myserial);
                    if(count($mainid)==$count && count($parentid)==$count && count($name)==$count && count($pageid)==$count && count($blogid)==$count && count($link)==$count && count($class)==$count && count($newtab)==$count && count($megamenu)==$count && count($myserial)==$count){
                        for($i=0; $i<$count; $i++){
                            $data= array(
                                'parent_id'=>$parentid[$i],
                                'menu_id'=>$menuid[$i],
                                'name'=>$name[$i],
                                'page_id'=>$pageid[$i],
                                'blog_id'=>$blogid[$i],
                                'link'=>$link[$i],
                                'class'=>$class[$i],
                                'newtab'=>$newtab[$i],
                                'megamenu'=>$megamenu[$i],
                                'serial'=>$myserial[$i]
                            );

                            if($mainid[$i] !=''){
                                Menuitem::where('id', $mainid[$i])->update($data);
                            }else{
                                Menuitem::create($data);
                            }
                        }
                        foreach($deletedid as $id){
                            Menuitem::where('id', $id)->delete();
                        }
                        return redirect()->route('adminnav')->with(['success'=> 'Your Menu has been saved successfully']);
                    }
                    else{
                        return redirect()->route('adminnav')->with(['dissmiss'=> 'Menu can not be saved for some reason']);
                    }
                }
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    public function managemenu(){
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10){                  //Authentication for Minimum Managers
                $data['logged_id'] = Auth::user()->id;
                $data['logged_role'] = Auth::user()->role;

                $data['selectnavs'] = Menu::get();
                $data['navplaces'] = Menuplace::get();
                return view('admin.managemenu', $data);
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }

    protected function createdeletenav(Request $request){
        if (!Auth::user()){                                     //Authentication for unlogged users
            return redirect()->route('adminlogin'); 
        }
        else{
            if(Auth::user()->role >= 10){                  //Authentication for Minimum Managers
                $data['logged_id'] = Auth::user()->id;
                $data['logged_role'] = Auth::user()->role;

                if($request->submitdelete!=null){
                    if($request->deletemenu ==1){
                        return redirect()->route('managemenu')->with(['defaultmenu'=> 'Default Menu can not be deleted']);
                    }
                    else{
                        $active = Menu::where('id', $request->deletemenu)->first();
                        $a = Menu::where('id', $request->deletemenu)->delete();
                        if($a){
                            Menu::where('id', '1')->update(array('selected' => '1'));
                            return redirect()->route('managemenu')->with(['success'=> 'Selected menu has been deleted successfully']);
                        }
                        else{
                            return redirect()->route('managemenu')->with(['dissmiss'=> 'Selected menu can not be deleted for some reason']);
                        }
                    }
                }
                else if($request->submitcreate!=null){
                    $rules = [ 
                    // 'slug'=>'required|unique:menus', 
                    'name'=>'required|unique:menus' 
                    ];
                    $messages = [ 
                        // 'slug.required' => 'Menu slug is required',
                        // 'slug.unique' => 'Menu slug must be unique',
                        'name.unique' => 'Menu name must be unique',
                        'name.required'  => 'Menu Name is requred' 
                        ];
                        
                    $validator = Validator::make($request->all(), $rules, $messages);
                    if ($validator->fails()) {
                        return redirect()->route('managemenu')->withErrors($validator)->withInput();
                    }
                    else{
                        $input = array(
                            'name'=>$request->name
                            );
                        $a=Menu::create($input)->id;
                        if($a){
                            return redirect()->route('managemenu')->with(['success'=> 'Menu Has been created successfully']);
                        }
                        else{
                            return redirect()->route('managemenu')->with(['dissmiss'=> 'Menu can not be created for some reason']);
                        }
                    }
                }
                else if($request->submitmenuplace!=null){
                    $menuplaces = Menuplace::get();
                    foreach ($menuplaces as $value) {
                        $a= 'menu_id'.$value->id;
                        if($value->menu_id != $request->$a){   
                            Menuplace::where('id', $value->id)->update(array('menu_id' => $request->$a));
                        }
                    }
                    return redirect()->route('managemenu')->with(['success'=> 'Menu Places has been reassigned successfully']);
                }
                else if($request->updatemenuitems!=null){
                    $menuitems = Menu::get();
                    foreach ($menuitems as $value) {
                        $a= 'editmenuname'.$value->id;
                        $b= 'editmenuclass'.$value->id;
                        if($request->$a !=''){
                            if($value->name != $request->$a || $value->class != $request->$b){   
                                Menu::where('id', $value->id)->update(array('name' => $request->$a, 'class' => $request->$b));
                            }
                        }
                    }
                    return redirect()->route('managemenu')->with(['success'=> 'Menu Info has been Updated successfully']);
                }
            }
            else{                                               //Authentication for User Less than managers
                return redirect()->route('dashboard');
            }
        }
    }
}