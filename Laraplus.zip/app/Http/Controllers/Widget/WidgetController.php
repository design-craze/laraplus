<?php

namespace App\Http\Controllers\Widget;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Models\Page;
use App\Models\Blog;
use App\Models\Comment;
use App\Models\Widget;
use Session;

class WidgetController extends Controller
{
    public function recent_posts($number = 5){
        if(ctype_digit($number)){
            $output = Blog::where(['trashed' => '0', 'type' => 'blog', 'archived' => '0'])->orderBy('updated_at', 'desc')->skip(0)->take($number)->get();
        }
        else{
            $output=null;
        }
    	return $output;
    }

    public function popular_posts($number = 5){
        if(ctype_digit($number)){
            $output = Blog::where(['trashed' => '0', 'type' => 'blog', 'archived' => '0', 'featured' => 1])->orderBy('updated_at', 'desc')->skip(0)->take($number)->get();
        }
        else{
            $output=null;
        }
        return $output;
    }

    public function blogsearch($address='searchblog'){
        if($address=='searchblog'){
            $output = '<form role="search" method="GET" action="'.route('searchblog').'">'
                            .'<div class="widget-search-form">'
                                .'<input type="text" class="search-text" name="search" placeholder="Search...">'
                                    .'<button class="dc-btn" type="submit">'
                                        .'<i class="fa fa-search"></i>'
                                    .'</button>'
                            .'</div>'
                      .'</form>';
        }
        else{
            $output=null;
        }
        return $output;
    }

    public function usermeta($address='login'){
        if($address=='login'){
            if(Auth::user()){
                $output = '<div class="current-user">';
                if(Auth::user()->fname != '' && Auth::user()->lname != ''){
                    $userinfo = '<p class="user-name">Name: <span>'. Auth::user()->fname. ' ' .Auth::user()->lname .'</span></p>';
                }
                else{
                    $userinfo = '<p class="user-name">Username: <span>' . Auth::user()->username .'</span></p>';
                }
                $userinfo .= '<p class="user-email">Email: <span>' . Auth::user()->email .'</span></p>';
                $userinfo .= '<p class="user-role">Logged in as <span>' . roleaccess(Auth::user()->role) .'</span></p>';
                $output .= $userinfo . '<p class="user-logout"><a href="'.route('logout').'">logout</a></p>';
                $output .= '</div>';
            }
            else{
                $settinghelper = allsetting();
                if($settinghelper['identify_page']!=''){
                    $address = getpage($settinghelper['identify_page']);
                }
                else{
                    $address = 'adminlogin';
                }
                $output ='<form method="POST" action="'.route('adminloginprocess').'" accept-charset="UTF-8">'
                                .'<input name="_token" value="'.Session::token().'" type="hidden">'
                                    .'<input class="widget-user" placeholder="Email or Username" name="user" value="" type="text">'
                                    .'<input class="widget-pass" placeholder="Password" name="password" value="" type="password">'
                                    .'<p class="widget-label">'
                                        .'<label>'
                                            .'<input name="remember_me" type="checkbox"> Remember Me'
                                        .'</label>'
                                    .'</p>';
                            if($address!=''){
                                $output .= '<p class="widget-forget"><a href="'.route('page',['slug'=>$address]).'">'
                                            .'Forgotten Account?'
                                        .'</a></p>';
                            }
                        $output .= '<button type="submit" class="dc-btn" name="login">Login</button>'
                            .'</form>';
            }
        }
        else{
            $output=null;
        }
        return $output;
    }

    public function widgetset($a){
        $output = Widget::where(['slug'=> $a, 'disabled' =>0])->orderBy('serial', 'asc')->get();
        return $output;
    }
}
