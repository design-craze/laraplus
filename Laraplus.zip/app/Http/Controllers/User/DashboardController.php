<?php

namespace App\Http\Controllers\User;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Validator;

use App\Models\User;
use App\Models\Userinfo;
use App\Models\Blog;
use App\Models\Category;


class DashboardController extends Controller
{
    public function __construct()
    {
        if(Auth::user() && Auth::user()->active == 2 && Auth::user()->role != 12)
        {
            return redirect()->route('suspended')->send();
        }
    }

    public function user(){
    	return redirect()->route('dashboard');
    }

  //   public function dashboard(){
  //       $data['settinghelper'] = $settinghelper = allsetting();
  //       if(Auth::user() && Auth::user()->role < 10 && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
  //           return redirect()->route('home');
  //       }
  //       else if(!Auth::user() && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
  //           return redirect()->route('home');
  //       }

  //       if (!Auth::user()){                                     //Authentication for unlogged users
  //           if($settinghelper['login_page']!=''){
  //               return redirect()->route('page', ['slug'=>getpage($settinghelper['login_page'])]); 
  //           }
  //           else{
  //               return redirect()->route('adminlogin'); 
  //           }
  //       }
  //       else
  //       {   
  //           $data['data'] = '';                                              //Authentication for All users
  //           $data['logged_id'] = Auth::user()->id;
  //           $data['logged_role'] = Auth::user()->role;
  //           $data['userlevel'] = 0;
  //           if(Auth::user())
  //           {
  //               $data['userlevel'] = Auth::user()->role;
  //           }


  //           $data['webtitle'] = $webtitle = 'User Dashboard';

  //           $data['breadcrumb'] = breadcrumb(
  //               array(
  //                   ['Home','home'],
  //                   [$webtitle,'dashboard']
  //               ),
  //               $settinghelper['brdcrmb_sep']
  //           );


  //           return view('template.' . $settinghelper['template'] . '.user.dashboard',$data);
		// }
  //   }

    public function profile($id=null)
    {
        $data['settinghelper'] = $settinghelper = allsetting();
        if(Auth::user() && Auth::user()->role < 10 && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }
        else if(!Auth::user() && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }

        if (!Auth::user()){                                     //Authentication for unlogged users
            if($settinghelper['login_page']!=''){
                return redirect()->route('page', ['slug'=>getpage($settinghelper['login_page'])]); 
            }
            else{
                return redirect()->route('adminlogin'); 
            }
        }
        else
        {   
            $data['data'] = '';                                           //Authentication for All users
            $data['userlevel'] = 0;
            if($id==null)
            {
                $userid = Auth::user()->logcode;
            }
            else{
                $userid = $id;
            }
                $data['dataerror'] = 0;
                $data['logged_id'] = Auth::user()->id;
                $data['logged_role'] = Auth::user()->role;
                $data['user'] = User::where('logcode',$userid)->first();
                if($data['user'])
                {
                    $data['userinfo'] = $data['user']->userinfo;
                }
                else{
                    $data['dataerror'] = 1;
                }

                if($id==null){
                    $data['webtitle'] = $webtitle = 'User Dashboard';

                    $data['breadcrumb'] = breadcrumb(
                        array(
                            ['Home','home'],
                            [$webtitle,'dashboard']
                        ),
                        $settinghelper['brdcrmb_sep']
                    );                    
                }
                else{
                    $data['webtitle'] = $webtitle = 'User Profile';

                    $data['breadcrumb'] = breadcrumb(
                        array(
                            ['Home','home'],
                            ['User Dashboard','dashboard'],
                            [$webtitle,'profile',['id'=>$id]]
                        ),
                        $settinghelper['brdcrmb_sep']
                    );   
                }

            return view('template.' . $settinghelper['template'] . '.user.profile',$data);
        }   
    }

    public function editprofile()
    {
        $data['settinghelper'] = $settinghelper = allsetting();
        if(Auth::user() && Auth::user()->role < 10 && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }
        else if(!Auth::user() && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }

        if (!Auth::user()){                                     //Authentication for unlogged users
            if($settinghelper['login_page']!=''){
                return redirect()->route('page', ['slug'=>getpage($settinghelper['login_page'])]); 
            }
            else{
                return redirect()->route('adminlogin'); 
            }
        }
        else
        {   
            $data['data'] = '';                                           //Authentication for All users
            $data['userlevel'] = 0;
            if(Auth::user())
            {
                $data['dataerror'] = 0;
                $data['logged_id'] = Auth::user()->id;
                $data['logged_role'] = Auth::user()->role;
                $data['user'] = User::where('id',Auth::user()->id)->first();
                if($data['user'])
                {
                    $data['userinfo'] = $data['user']->userinfo;
                }
                else{
                    $data['dataerror'] = 1;
                }
            }
            $data['webtitle'] = $webtitle = 'Edit Profile';

            $data['breadcrumb'] = breadcrumb(
                array(
                    ['Home','home'],
                    ['User Dashboard','dashboard'],
                    [$webtitle,'editprofile']
                ),
                $settinghelper['brdcrmb_sep']
            ); 
            return view('template.' . $settinghelper['template'] . '.user.editprofile',$data);
        }  
    }

    public function editprofileprocess(Request $request)
    {
        $data['settinghelper'] = $settinghelper = allsetting();
        if(Auth::user() && Auth::user()->role < 10 && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }
        else if(!Auth::user() && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }

        if (!Auth::user()){                                     //Authentication for unlogged users
            if($settinghelper['login_page']!=''){
                return redirect()->route('page', ['slug'=>getpage($settinghelper['login_page'])]); 
            }
            else{
                return redirect()->route('adminlogin'); 
            }
        }
        else
        {   
            $rules = [ 
                'fname'=>'required', 
                'lname'=>'required',
                'city'=>'required',
                'country'=>'required|in:'.keystring(country(),','),
                'sex'=>'in:'.keystring(gender(),','),
                'contact' => 'required|numeric|unique:userinfos,contact,'.Auth::user()->id,
                'dob' => 'required|date_format:yy-m-d|before: -5 Years'
            ];

            $messages = [ 
                'fname.required' => 'First Name field is required', 
                'lname.required' => 'Last Name field is required.',
                'country.required'     => 'Country field is required, Please select your country.',
                'country.in'     => 'Selected Country is not available in the list.',
                'sex.in'     => 'Selected Gender is not available in the list.',
                'contact.required'     => 'Contact Number is required.',
                'contact.unique'     => 'The Contact Number already exists, Please choose another contact number.',
                'contact.numeric'     => 'Contact Number must consist of Numbers.',

                'dob.required' => 'Date of Birth field is required.',
                'dob.date_format' => 'Date of Birth contains invalid format. Date Format must consist of yyyy-mm-dd.',
                'dob.before' => 'Date of Birth must be minimum five years old.'
            ];

            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return redirect()->back()->withErrors($validator)->withInput();
            }
            else {
                $userupdate['fname'] = $request->fname;
                $userupdate['lname'] = $request->lname;
                $updated = User::where('id', Auth::user()->id)->update($userupdate);
                if($updated){
                    $userinfoupdate = array(
                        'street1' => $request->street1,
                        'street1' => $request->street2,
                        'city' => $request->city,
                        'state' => $request->state,
                        'zip' => $request->zip,
                        'country' => $request->country,
                        'sex' => $request->sex,
                        'contact' => $request->contact,
                        'description' => $request->description,
                        'dob'=>$request->dob
                    );
                    $searchuser = Userinfo::where('user_id', Auth::user()->id)->count();
                    if($searchuser>0){
                        $edited = Userinfo::where('user_id', Auth::user()->id)->update($userinfoupdate);

                        if($edited)
                        {
                            return redirect()->route('dashboard')->with(['success'=> 'All submited data Has been Edited Successfully']);
                        }else{
                            return redirect()->back()->with(['success'=> 'Only Primary data has been Edited Successfully but not the user personal data.']);
                        }
                    }
                    else{
                        $userinfoupdate['user_id'] = Auth::user()->id;
                        $created = Userinfo::create($userinfoupdate);
                        if($created){
                            return redirect()->route('dashboard')->with(['success'=> 'All submited data Has been Edited Successfully']);
                        }else{
                            return redirect()->back()->with(['success'=> 'Only Primary data has been Edited Successfully but not the user personal data.']);
                        }
                    }
                }
                else{
                    return redirect()->back()->with(['dissmiss'=> 'User Data Can not be edited for some reason']);
                }
            }

        }
    }

    public function usersetting()
    {
        $data['settinghelper'] = $settinghelper = allsetting();
        if(Auth::user() && Auth::user()->role < 10 && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }
        else if(!Auth::user() && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }
        
        if (!Auth::user()){                                     //Authentication for unlogged users
            if($settinghelper['login_page']!=''){
                return redirect()->route('page', ['slug'=>getpage($settinghelper['login_page'])]); 
            }
            else{
                return redirect()->route('adminlogin'); 
            }
        }
        else
        {
            $data['data'] = '';
            $data['logged_id'] = Auth::user()->id;
            $data['logged_role'] = Auth::user()->role;

            $data['webtitle'] = $webtitle = 'Password Setting';

            $data['breadcrumb'] = breadcrumb(
                array(
                    ['Home','home'],
                    ['User','dashboard'],
                    [$webtitle,'usersetting']
                ),
                $settinghelper['brdcrmb_sep']
            );

            return view('template.' . $settinghelper['template'] . '.user.changepassword',$data);
        }
    }
}
