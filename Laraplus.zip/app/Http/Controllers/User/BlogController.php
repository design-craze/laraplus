<?php

namespace App\Http\Controllers\User;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

use App\Models\Blog;
use App\Models\Category;
use App\Models\BlogCategory;
use App\Models\Comment;
use Validator;

class BlogController extends Controller
{
	public function myblogs()
    {
        $data['settinghelper'] = $settinghelper = allsetting();
        if(Auth::user() && Auth::user()->role < 10 && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }
        else if(!Auth::user() && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }

        if (!Auth::user()){                                     //Authentication for unlogged users
            if($settinghelper['login_page']!=''){
                return redirect()->route('page', ['slug'=>getpage($settinghelper['login_page'])]); 
            }
            else{
                return redirect()->route('adminlogin'); 
            }
        }
        else
        {
            $data['data'] = '';                                           //Authentication for All users
            $data['userlevel'] = 0;
            if(Auth::user())
            {
                $data['dataerror'] = 0;
                $data['logged_id'] = Auth::user()->id;
                $data['logged_role'] = Auth::user()->role;
                $data['getelements'] = array(
                        'sort' =>''
                );
                foreach($data['getelements'] as $key => $val){
                    if ($val == ''){
                        unset($data['getelements'][$key]);
                    }
                }
                $data['categories'] = Category::where(['trashed' => '0'])->get();
                $data['myposts'] = Blog::where(['user_id'=>Auth::user()->id, 'trashed' => '0', 'archived' => '0'])->orderBy('updated_at', 'desc')->paginate(12)->appends($data['getelements']);
                if(count($data['myposts'])==0)
                {
                    $data['dataerror'] = 1;
                }
            }

            $data['webtitle'] = $webtitle = 'My Blogs';

            $data['breadcrumb'] = breadcrumb(
                array(
                    ['Home','home'],
                    ['User','dashboard'],
                    [$webtitle,'myblogs']
                ),
                $settinghelper['brdcrmb_sep']
            );

            return view('template.' . $settinghelper['template'] . '.user.myblogs',$data);
        }
    }

    // user create blog
	public function createblog()
	{
		$data['settinghelper'] = $settinghelper = allsetting();
        if(Auth::user() && Auth::user()->role < 10 && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }
        else if(!Auth::user() && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }

        if (!Auth::user()){                                     //Authentication for unlogged users
            if($settinghelper['login_page']!=''){
                return redirect()->route('page', ['slug'=>getpage($settinghelper['login_page'])]); 
            }
            else{
                return redirect()->route('adminlogin'); 
            }
        }
        else
        {   
            $data['data'] = '';                                           //Authentication for All users
            $data['userlevel'] = 0;
            if(Auth::user())
            {
                $data['dataerror'] = 0;
                $data['logged_id'] = Auth::user()->id;
                $data['logged_role'] = Auth::user()->role;
                $data['categories'] = Category::where('trashed',0)->get();
            }

            $data['webtitle'] = $webtitle = 'Create Blog';

            $data['breadcrumb'] = breadcrumb(
                array(
                    ['Home','home'],
                    ['User','dashboard'],
                    [$webtitle,'createblog']
                ),
                $settinghelper['brdcrmb_sep']
            );

            return view('template.' . $settinghelper['template'] . '.user.createblog',$data);
        }  	
	}

    // user create blog process
	public function createblogprocess(Request $request)
	{
        $data['settinghelper'] = $settinghelper = allsetting();
		if(Auth::user() && Auth::user()->role < 10 && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }
        else if(!Auth::user() && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }

        if (!Auth::user()){                                     //Authentication for unlogged users
            if($settinghelper['login_page']!=''){
                return redirect()->route('page', ['slug'=>getpage($settinghelper['login_page'])]); 
            }
            else{
                return redirect()->route('adminlogin'); 
            }
        }
        else
        {   
			$rules = [ 
                'name'=>'required',
	            'category'=>'size:1',
                'thumb'=>'url',
	            'commentable' => 'required|integer|between:0,1'
	            ];
	        $messages = [ 
	            'name.required' => 'Fill up Blog Name',
                'category.size' => 'You can select only one category.',
                'thumb.url' => 'Please use a valide url for Blog Thumb.',
	            'commentable.integer' => 'Active Comment must be Yes or No',
	            'commentable.between' => 'Active Comment must be Yes or No'
	            ];
	            
	        $validator = Validator::make($request->all(), $rules, $messages);
	        if ($validator->fails()) {
	            return redirect()->back()->withErrors($validator)->withInput();
	        }
	        else{
	        	$slug = cleanslug(strtolower($request->name));
	            $finalslug = $slug;
	            for($i=0; $i>-1; $i++){
	                $sameslug = Blog::where('slug', $finalslug)->count();
	                if($sameslug > 0){
	                    $finalslug = $slug . '-' . ($i+1);
	                }
	                else{
	                    $i= -10;
	                }
	            }
	            $input = $request->except('_token', 'slug', 'category', 'create-blog');
	            // Here need the user ID;
	            $input['slug'] = $finalslug;
	            $input['user_id'] = Auth::user()->id;
	            $inserted = Blog::create($input)->id;
	            if($inserted){
	                if($request->category != null){
	                    foreach($request->category as $category){
	                        $existedcategory = Category::where('id', $category)->count();
	                        if($existedcategory==1){
	                            BlogCategory::create(['blog_id' => $inserted , 'category_id' => $category]);
	                        }
	                    }
	                }
	                return redirect()->route('blog', ['slug' => $input['slug']])->with(['success'=> 'Article Has been Created Successfully']);
	            }
	            else{
	                return redirect()->back()->with(['dissmiss'=> 'Article Can not be created for some reason']);
	            }
	       	}
	    }
	}

    // user edit blog
	public function editblog($id)
	{
		$data['settinghelper'] = $settinghelper = allsetting();
        if(Auth::user() && Auth::user()->role < 10 && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }
        else if(!Auth::user() && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }

        if (!Auth::user()){                                     //Authentication for unlogged users
            if($settinghelper['login_page']!=''){
                return redirect()->route('page', ['slug'=>getpage($settinghelper['login_page'])]); 
            }
            else{
                return redirect()->route('adminlogin'); 
            }
        }
        else
        {   
        	$data['data'] = '';                                           //Authentication for All users
            $data['userlevel'] = 0;
            if(Auth::user())
            {
                $data['dataerror'] = 0;
                $data['logged_id'] = Auth::user()->id;
                $data['logged_role'] = Auth::user()->role;
                $data['categories'] = Category::where('trashed',0)->get();
            }
        	$data['singleblog'] = Blog::where(['id' => $id, 'trashed' => 0])->first();
            if(count($data['singleblog'])==0)
	        {
	            $data['dataerror'] = 1;
	        }
	        else{
	        	$data['categories'] = Category::where(['trashed' => '0'])->get();
	        	$data['dbcategory'] = $data['singleblog']->categories;
	        }


            $data['webtitle'] = $webtitle = 'Edit Blog';

            $data['breadcrumb'] = breadcrumb(
                array(
                    ['Home','home'],
                    ['User','dashboard'],
                    [$webtitle,'editpost',['id'=>$id]]
                ),
                $settinghelper['brdcrmb_sep']
            );

            return view('template.' . $settinghelper['template'] . '.user.editblog',$data);
        }  	
	}

    // user edit blog process
	public function editblogprocess($id, Request $request)
	{
        $data['settinghelper'] = $settinghelper = allsetting();
        if(Auth::user() && Auth::user()->role < 10 && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }
        else if(!Auth::user() && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }

        if (!Auth::user()){                                     //Authentication for unlogged users
            if($settinghelper['login_page']!=''){
                return redirect()->route('page', ['slug'=>getpage($settinghelper['login_page'])]); 
            }
            else{
                return redirect()->route('adminlogin'); 
            }
        }
        else
        {
    		$rules = [ 
                'name'=>'required',
                'category'=>'size:1',
                'thumb'=>'url',
                'commentable' => 'required|integer|between:0,1'
                ];
            $messages = [ 
                'name.required' => 'Fill up Blog Name',
                'category.size' => 'You can select only one category.',
                'thumb.url' => 'Please use a valide url for Blog Thumb.',
                'commentable.integer' => 'Active Comment must be Yes or No',
                'commentable.between' => 'Active Comment must be Yes or No'
                ];
                
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return redirect()->back()->withErrors($validator)->withInput();
            }
            else{
            	$update = $request->except('_token','category', 'update');
    			$updated = Blog::where('id',$id)->update($update);
                if($updated){
                    if($request->category != null){
                        $reservedcatgs = BlogCategory::where(['blog_id' => $id])->delete();

                        foreach($request->category as $category){
                            $existedcategory = Category::where('id', $category)->count();
                            if($existedcategory==1){
                                BlogCategory::create(['blog_id' => $id , 'category_id' => $category]);
                            }
                        }
                    }
                    else{
                        $reservedcatgs = BlogCategory::where(['blog_id' => $id])->delete();
                    }
                    
                    return redirect()->route('editpost', ['id' => $id])->with(['success'=> 'Article Has been Created Successfully']);
                }
                else{
                    return redirect()->back()->with(['dissmiss'=> 'Article Can not be created for some reason']);
                } 
           	}
        } 	
	}

    public function submitcomment( $blogid ,Request $request)
    {
        $data['settinghelper'] = $settinghelper = allsetting();
        if(Auth::user() && Auth::user()->role < 10 && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }
        else if(!Auth::user() && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }

        if (!Auth::user()){                                     //Authentication for unlogged users
            if($settinghelper['login_page']!=''){
                return redirect()->route('page', ['slug'=>getpage($settinghelper['login_page'])]); 
            }
            else{
                return redirect()->route('adminlogin'); 
            }
        }
        else
        {   
            $rules = [ 
                'comment'=>'required',
                ];
            $messages = [ 
                'comment.required' => 'Comment can not be empty.'
                ];
                
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return redirect()->back()->withErrors($validator)->withInput();
            }
            else{

                // check if the blog exists or not
                $blog = Blog::where('id',$blogid)->first();
                if($blog)
                {
                    $comment['blog_id'] = $blogid;
                    $comment['user_id'] = Auth::user()->id;
                    $comment['description'] = $request->comment;

                    $inserted = Comment::create($comment);
                    if($inserted){
                        return redirect()->back()->with(['success'=> 'Comment has beed posted successfully']);
                    }
                    else{
                        return redirect()->back()->with(['dissmiss'=> 'Comment can not be created for some reason']);
                    }
                }
                else{
                    return redirect()->back()->with(['dissmiss'=> 'Comment can not be created for missing blog']);
                }
            }
        }      
    }

    public function updatecomment( $blogid, $comid ,Request $request)
    {
        $data['settinghelper'] = $settinghelper = allsetting();
        if(Auth::user() && Auth::user()->role < 10 && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }
        else if(!Auth::user() && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }

        if (!Auth::user()){                                     //Authentication for unlogged users
            if($settinghelper['login_page']!=''){
                return redirect()->route('page', ['slug'=>getpage($settinghelper['login_page'])]); 
            }
            else{
                return redirect()->route('adminlogin'); 
            }
        }
        else
        {   
            $rules = [ 
                'editcomment'=>'required',
            ];
            $messages = [ 
                'editcomment.required' => 'Comment box can not be empty.'
            ];
                
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return redirect()->back()->withErrors($validator)->withInput();
            }
            else{

                // check if the user's comment and the same blog or not
                $blog = Blog::where('id',$blogid)->first();

                $data = Comment::where(['id'=>$comid,'blog_id'=>$blogid,'user_id'=>Auth::user()->id])->first();

                if($data && $blog)
                {
                    $inserted = Comment::where('id',$comid)->update(['description'=>$request->editcomment]);
                    if($inserted){
                        return redirect()->back()->with(['success'=> 'Comment has beed updated successfully']);
                    }
                    else{
                        return redirect()->back()->with(['dissmiss'=> 'Comment can not be updated now for some reason']);
                    }
                }
                else
                {
                    return redirect()->back()->with(['dissmiss'=> 'Comment can not be updated now for some reason']);
                }
            }
        }      
    }

    public function deletecomment( $blogid, $comid ,Request $request)
    {
        $data['settinghelper'] = $settinghelper = allsetting();
        if(Auth::user() && Auth::user()->role < 10 && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }
        else if(!Auth::user() && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }

        if (!Auth::user()){                                     //Authentication for unlogged users
            if($settinghelper['login_page']!=''){
                return redirect()->route('page', ['slug'=>getpage($settinghelper['login_page'])]); 
            }
            else{
                return redirect()->route('adminlogin'); 
            }
        }
        else
        {   

            // checking if the comment exists and same user or not and sub comment exists or not 
            $blog = Blog::where('id',$blogid)->first();
            $data = Comment::where(['id'=>$comid,'blog_id'=>$blogid,'user_id'=>Auth::user()->id])->first();
            
            if($blog && $data)
            {
                $delete = Comment::where('id',$comid)->orWhere('parent_id',$comid)->delete();
                if($delete){
                    return redirect()->back()->with(['success'=> 'Comment has beed deleted successfully']);
                }
                else{
                    return redirect()->back()->with(['dissmiss'=> 'Comment can not be deleted now for some reason']);
                }
            }
            
        }      
    }

    public function replycomment($blogid, $parentid ,Request $request)
    {
        $data['settinghelper'] = $settinghelper = allsetting();
        if(Auth::user() && Auth::user()->role < 10 && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }
        else if(!Auth::user() && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }
        
        if (!Auth::user()){                                     //Authentication for unlogged users
            if($settinghelper['login_page']!=''){
                return redirect()->route('page', ['slug'=>getpage($settinghelper['login_page'])]); 
            }
            else{
                return redirect()->route('adminlogin'); 
            }
        }
        else
        {   
            $rules = [ 
                'replycomment'=>'required',
            ];
            $messages = [ 
                'replycomment.required' => 'Comment box can not be empty.'
            ];
                
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return redirect()->back()->withErrors($validator)->withInput();
            }
            else{

                // checking if blog exists or not

                // checking if parent comment exists or not
                // check if the user's comment and the same blog or not
                $blog = Blog::where('id',$blogid)->first();

                $data = Comment::where(['id'=>$parentid,'blog_id'=>$blogid])->first();

                if($blog && $data)
                {
                    $comment['blog_id'] = $blogid;
                    $comment['user_id'] = Auth::user()->id;
                    $comment['parent_id'] = $parentid;
                    $comment['description'] = $request->replycomment;

                    $inserted = Comment::create($comment);
                    if($inserted){
                        return redirect()->back()->with(['success'=> 'Comment has beed posted successfully']);
                    }
                    else{
                        return redirect()->back()->with(['dissmiss'=> 'Comment can not be posted now for some reason']);
                    }
                }
                else
                {
                    return redirect()->back()->with(['dissmiss'=> 'Comment can not be posted now for some reason']);
                }
            }
        }
    }
}
