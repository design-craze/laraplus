<?php

namespace App\Http\Controllers\User;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use Illuminate\Support\Facades\Auth;

class SuspendedController extends Controller
{
    public function suspended()
    {
        $data['settinghelper'] = $settinghelper = allsetting();
        if(Auth::user() && Auth::user()->role < 10 && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }
        else if(!Auth::user() && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }
        
        if (!Auth::user()){                                     //Authentication for unlogged users
             if($settinghelper['login_page']!=''){
                return redirect()->route('page', ['slug'=>getpage($settinghelper['login_page'])]); 
            }
            else{
                return redirect()->route('adminlogin'); 
            }
        }
        else
        { 
            $data['data'] = '';

            if(Auth::user()->active == 2 && Auth::user()->role != 12)
            {
                $data['dataerror'] = 0;
                $data['logged_id'] = Auth::user()->id;
                $data['logged_role'] = Auth::user()->role;

                $data['webtitle'] = $webtitle = 'Account Status';

                $data['breadcrumb'] = breadcrumb(
                    array(
                        ['Home','home'],
                        ['User','dashboard'],
                        [$webtitle,'suspended']
                    ),
                    $settinghelper['brdcrmb_sep']
                );
                return view('template.' . $settinghelper['template'] . '.user.suspended',$data);
            }

            return redirect()->back();
        }
    }
}
