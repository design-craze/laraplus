<?php

namespace App\Http\Controllers\Nav;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\Menu;
use App\Models\Menuplace;

class NavController extends Controller
{
	protected $id;

    public function allmenu($slug=null, $id=null){
        if($slug!=null){
            $output = array();
            $singlemenu= array();
            $menuplace = Menuplace::where('slug', $slug)->first();
            if($menuplace){
                $i=$menuplace->menu_id;
                $x = $menuplace->slug;
                if($i!=0){
                    if(array_key_exists ($i , $singlemenu)==false){
                        $this->id= $i;
                        $a = $this->mymenu();
                        $singlemenu[$i] = $a;
                    }
                    $output[$x] = $singlemenu[$i];
                }
                else{
                    $output[$x] = '';
                }
            }
            else{
                $output[$slug] = '';
            }
        }
        elseif($id!=null){
            $this->id= $id;
            $output = $this->mymenu();
        }
        return $output;

    }

    public function mymenu(){
    	$a = Menu::where('id', $this->id)->first();
        if($a){
        	$b = $a->menuitems;
        	if(!$b){
        		$output = '<ul class="' . $a->class . '">';   // id="navul-' . $a->id . '"
                $output .= '<li><a href="' . route('home') . '">Home</a></li>';
                $output .= '</ul>';
        	}
        	else{
        		$output = '<ul class="' . $a->class . '">'; // id="navul-' . $a->id . '" 
                $output .= $this->innermenu($a);
                $output .= '</ul>';
        	}
        	return $output;
        }
        else{
            return '';
        }
    }

    protected function innermenu($dbdata, $parent_id=0, $result=NULL){
    	foreach ($dbdata->menuitems as $row){
            $count=0;
            if($row->parent_id == $parent_id){
                $ul=FALSE;
                $b = $row->serial;
                $classess='';
                if($row->parent_id==0 && $row->megamenu==1){
                    $classess .= 'dc-megamenu';
                }
                if($classess==''){
                    $classess= $row->class;
                }
                else{
                    $classess .= ' '.$row->class;
                }
                $result .= '<li class="' . $classess . '"><a href="'; //  id="menu-item-'. $row->id .'"
                


                //Create Links for menu anchor tag
                if($row->page_id > 0){
                    foreach($dbdata->mypages() as $mypage){
                        if($row->id == $mypage->id){
                            $result .= e(route('page', ['slug'=>$mypage->slug]));
                        }
                    }
                }
                elseif($row->blog_id > 0){
                    foreach($dbdata->myblogs() as $myblog){
                        if($row->id == $myblog->id){
                            $result .= e(route('blog', ['slug'=>$myblog->slug]));
                        }
                    }
                }
                else{
                    $result .= e($row->link);
                }
                //End Links for menu anchor tag



                $result .='"';
                if($row->newtab!=0){
                    $result .= ' target="_blank"';
                }
                if($row->class!=''){
                    $result .= ' class="' . $row->class . '"';
                }
                $result .='>';



                //Create Names for menu anchor tag
                if($row->name!=''){
                    $result .=  e($row->name);
                }
                elseif($row->page_id > 0){
                    foreach($dbdata->mypages() as $mypage){
                        if($row->id == $mypage->id){
                            $result .= e($mypage->slug);
                        }
                    }
                }
                elseif($row->blog_id > 0){
                    foreach($dbdata->myblogs() as $myblog){
                        if($row->id == $myblog->id){
                            $result .= e($myblog->slug);
                        }
                    }
                }
                else{
                    $result .= 'Custom Link';
                }
                //End Names for menu anchor tag



                $result .= '</a>';
                
                foreach ($dbdata->menuitems as $row){
                    if($row->parent_id ==$b && $count<1){
                        if($ul==FALSE){
                        $result .= '<ul>';
                            $ul=TRUE;
                        }
                        $count++;
                        $result .= $this->innermenu($dbdata, $b);
                    }
                }
                if($ul==TRUE){
                    $result .= '</ul>';
                    $ul==FALSE;
                }
                $result .= '</li>';
            }
        }
        return $result;
    }

}
