<?php

namespace App\Http\Controllers\Front;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\Blog;
use App\Models\Category;
use Illuminate\Support\Facades\Auth;

class SearchController extends Controller
{
    public function searchblog()
	{
		$data['data'] = '';                                           //Authentication for All users
        $data['settinghelper'] = $settinghelper = allsetting();
        if(Auth::user() && Auth::user()->role < 10 && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }
        else if(!Auth::user() && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }
        $data['userlevel'] = 0;
        $data['dataerror'] = 0;
        if(Auth::user())
        {
            $data['logged_id'] = Auth::user()->id;
            $data['logged_role'] = Auth::user()->role;
        }

        $search = \Request::get('search');
        $searcharray = explode(' ', $search);
        
        $data['getelements'] = array(
            'search' =>$search
        );
        foreach($data['getelements'] as $key => $val){
            if ($val == ''){
                unset($data['getelements'][$key]);
            }
        }

        $data['categories'] = Category::where(['trashed' => '0'])->get();
        
        if(\Request::get('tag')!=null){
            $tagval = \Request::get('tag');
            $data['myposts'] = Blog::where([ 'trashed' => '0'])->where('metatag','like','%'.$tagval.'%')->orderBy('updated_at', 'desc')->paginate(12)->appends($data['getelements']);
        }
        else{
            $current = 1;
            $data['myposts'] = Blog::where('trashed',0)->where(function($query) use($searcharray,$current){
                                    foreach ($searcharray as $wh){
                                        if($current==1){
                                            $query->where('name','like','%'.$wh.'%');
                                        }else {
                                            $query->orWhere('name','like','%'.$wh.'%');
                                        }
                                        $query->orWhere('description','like','%'.$wh.'%');
                                        $query->orWhere('metatag','like','%'.$wh.'%');
                                        $current =0;
                                    }
                                })->orderBy('updated_at', 'desc')->paginate(12)->appends($data['getelements']);
        }


        if(count($data['myposts'])==0)
        {
            $data['dataerror'] = 1;
        }

        $data['webtitle'] = $webtitle = 'Blog Search';

        $data['breadcrumb'] = breadcrumb(
            array(
                ['Home','home'],
                [$webtitle,'searchblog']
            ),
            $settinghelper['brdcrmb_sep']
        );

		return view('template.' . $settinghelper['template'] . '.searchblog',$data);
	}
}
