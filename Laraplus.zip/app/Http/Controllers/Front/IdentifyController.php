<?php

namespace App\Http\Controllers\Front;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\User;
use Validator;
use Mail;
use Hash;


class IdentifyController extends Controller
{
    public function identifyemailprocess(Request $request)
    {
        $data['settinghelper'] = $settinghelper = allsetting();
        if(Auth::user() && Auth::user()->role < 10 && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }
        else if(!Auth::user() && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }
    	$rules = ['email'=> 'required|email|max:255|min:5'];

    	$errorMessages = [
    			'email.required' => 'Email field is required.',
                'email.email' => 'Email field contains invalid Email Address.',
                'email.max' => 'Email field consists of maximum 50 characters', 
                'email.min' => 'Email field consists of minimum 5 characters'
    	]; 

    	$validation = Validator::make($request->all(), $rules, $errorMessages);
            
        if($validation->fails())
        {
            return redirect()->back()->withErrors($validation)->withInput();
        }
        else
        {
        	// checking if user exist or not with email
        	$user = User::where('email',$request->email)->first();

        	if($user)
        	{
        		// sending mail
                $userName = $user->fname . ' ' . $user->lname;
                $userEmail = $user->email;
                $subject = 'Password Recovery | Larapress';

        		$sentmail = Mail::send(
                    'template.default.emails.recoverymail',
                    ['data' => $user],
                    function ($message) use ($userName, $userEmail, $subject)
                    {
                        $message->to($userEmail, $userName)->subject($subject)->replyTo(
                            'DoNotReply@design-craze.com', 'Design Craze'
                        );
                    }
                );

                if($sentmail)
                {
                	return redirect()->back()->with('success','An mail has been sent to this ' . $user->email .' including a password recovery link. Please check you email. If you did not get any email,Please use again the below form for getting recovery link.');
                }
                else{
                	return redirect()->back()->with('dissmiss','Server Error! Could not send mail, Please try again.');
                }
        	}
        	else
        	{
        		return redirect()->back()->with('dissmiss','Oops! No user is found with this email, Please enter email again.');
        	}
        }
    }

    public function recovery($vfcode)
    {
    	$data['settinghelper'] = $settinghelper = allsetting();
        if(Auth::user() && Auth::user()->role < 10 && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }
        else if(!Auth::user() && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }
    	$data['vfcode'] = $vfcode; 

        $data['webtitle'] = $webtitle = 'Password Recovery';
        $data['breadcrumb'] = breadcrumb(
            array(
                ['Home','home'],
                [$webtitle,'recovery',['vfcode'=>$vfcode]]
            ),
            $settinghelper['brdcrmb_sep']
        );

    	return view('template.' . $settinghelper['template'] . '.page-template.recovery',$data);
    }

    public function recoveryemailprocess($vfcode,Request $request)
    {
        $data['settinghelper'] = $settinghelper = allsetting();
        if(Auth::user() && Auth::user()->role < 10 && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }
        else if(!Auth::user() && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }
    	// validating form data
        $rules = [
            'new_pass'=> 'required|string|confirmed|max:255|min:6'
        ];
        
        $errorMessages = [ 
            'new_pass.required' => 'Password field is required.',
            'new_pass.string' => 'Password must be string.',
            'new_pass.confirmed' => 'Password fields didn\'t match.',
            'new_pass.max' => 'Email field consists of maximum 255 characters', 
            'new_pass.min' => 'Email field consists of minimum 6 characters'
        ];

        
        $validation = Validator::make($request->all(), $rules, $errorMessages);
        
        if($validation->fails())
        {
            return redirect()->back()->withErrors($validation);
        }
        else{
        	$user = User::where('vfcode',$vfcode)->first();

        	if($user)
        	{
        		$newpassword = Hash::make($request->new_pass);

        		$passupdate = User::where(['id' => $user->id, 'vfcode' => $vfcode])->update(['password' => $newpassword, 'vfcode'=>md5($user->email.uniqid())]);

        		if($passupdate)
        		{
        			$settinghelper = allsetting();
		            if($settinghelper['login_page']!=''){
		                return redirect()->route('page', ['slug'=>getpage($settinghelper['login_page'])])->with('success', 'Your New password has been updated successfully. Please login with your new choosen password.'); 
		            }
		            else{
		                return redirect()->route('adminlogin')->with('success', 'Your New password has been updated successfully. Please login with your new choosen password.'); 
		            }
        		}
        		else{
        			return redirect()->back()->with('dissmiss', 'Oops, Server Error! Could not update your new password! Please try again.');
        		}
        	}
        	else{
        		return redirect()->back()->with('dissmiss', 'Oops! User Verification is Failed! Please ask again for password recovery link through email.');
        	}
        }
    }
}
