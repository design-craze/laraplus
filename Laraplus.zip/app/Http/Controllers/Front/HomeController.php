<?php

namespace App\Http\Controllers\Front;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\Page;
use Illuminate\Support\Facades\Auth;

class HomeController extends Controller
{
    public function index($lang='en'){
        $data['settinghelper'] = $settinghelper = allsetting();
        if(!Auth::user() && $settinghelper['web_status'] == 2){
            $data['data'] = page::where(['slug' => getpage($settinghelper['coming_soon']), 'lang' => $lang, 'trashed' => 0])->firstOrFail();
        }
        else if(!Auth::user() && $settinghelper['web_status'] == 3){
            $data['data'] = page::where(['slug' => getpage($settinghelper['under_dev']), 'lang' => $lang, 'trashed' => 0])->firstOrFail();
        }
        else if(Auth::user() && Auth::user()->role < 10 && $settinghelper['web_status'] == 2){
            $data['data'] = page::where(['slug' => getpage($settinghelper['coming_soon']), 'lang' => $lang, 'trashed' => 0])->firstOrFail();
        }
        else if(Auth::user() && Auth::user()->role < 10 && $settinghelper['web_status'] == 3){
            $data['data'] = page::where(['slug' => getpage($settinghelper['under_dev']), 'lang' => $lang, 'trashed' => 0])->firstOrFail();
        }
        else{
    	   $data['data'] = Page::where(['home' => 1])->firstOrFail();
        }
    	$data['userlevel'] = 0;
		if(Auth::user())
		{
            $data['logged_id'] = Auth::user()->id;
            $data['userlevel'] = Auth::user()->role;
		}
        $data['breadcrumb'] = breadcrumb(
            array(
                ['Home','home']
            ),
            $settinghelper['brdcrmb_sep']
        );
    	return view('template.' . $settinghelper['template'] . '.home', $data);
    }
}