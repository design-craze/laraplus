<?php

namespace App\Http\Controllers\Front;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Models\Userinfo;
use Session;
use Hash;
use Validator;
use Mail;

class SignupController extends Controller
{
    public function signupprocess(Request $request)
    {
        if(!Auth::user()){
            $settinghelper = allsetting();
            
            if($settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
                return redirect()->route('home');
            }

            $maxSignable = 0;
            if($settinghelper['signable'] != ''){
                $signable = explode(',', $settinghelper['signable']);
                $maxSignable = count($signable);    
            }
            
        	// validating form data
            $rules = [
                'fname'=>'required|max:50|min:2', 
                'lname'=>'required|max:50|min:2',
                'username'=> 'required|alpha_dash|unique:users,username|max:50|min:3',
                'email'=> 'required|email|confirmed|unique:users,email|max:255|min:5',
                'password'=> 'required|string|confirmed|max:255|min:6'
            ];
            
            $errorMessages = [
                'fname.required' => 'First Name field is required', 
                'fname.max' => 'First Name field consists of maximum 50 characters', 
                'fname.min' => 'First Name field consists of minimum 2 characters', 
                'lname.required' => 'Last Name field is required.',
                'lname.max' => 'Last Name field consists of maximum 50 characters', 
                'username.required' => 'Username field is required.',
                'username.alpha_dash' => 'Username field must be alphabate number, as well as dashes and underscores.',
                'username.unique' => 'Oops! This Username already exists, Please choose unique Username.',
                'username.max' => 'Username field consists of maximum 50 characters', 
                'username.min' => 'Username field consists of minimum 3 characters', 
                'email.required' => 'Email field is required.',
                'email.email' => 'Email field contains invalid Email Address.',
                'email.confirmed' => 'Email fields didn\'t match.',
                'email.unique' => 'Oops! This Email already exists, Please choose unique Email.',
                'email.max' => 'Email field consists of maximum 50 characters', 
                'email.min' => 'Email field consists of minimum 5 characters', 
                'password.required' => 'Password field is required.',
                'password.string' => 'Password must be string.',
                'password.confirmed' => 'Password fields didn\'t match.',
                'password.max' => 'Email field consists of maximum 255 characters', 
                'password.min' => 'Email field consists of minimum 6 characters'
            ];

            if($maxSignable > 0)
            {
                $rules['role'] = 'required|integer|in:' . $settinghelper['signable'];
                $errorMessages['role.required'] = 'Role field is required.';
                $errorMessages['role.integer'] = 'Role field contains invalid value.';
                $errorMessages['role.in'] = 'Role field contains invaild value';
            }

            
            $validation = Validator::make($request->all(), $rules, $errorMessages);
            
            if($validation->fails())
            {
                return redirect()->back()->withErrors($validation)->withInput();
            }
            else{
            	$insert = $request->except('_token','email_confirmation','password_confirmation');
                $insert['password'] = Hash::make($request->password);
                $insert['active'] = 4;
                $insert['verified'] = 1;
                $insert['logcode'] = md5($request->email.uniqid());
                $insert['vfcode'] = md5($request->email.uniqid());

                if($maxSignable==0)
                {
                    $insert['role'] = 1;
                }
                
                // inserting data in table
                $inserted = User::create($insert)->id;
                
                if($inserted)
                {
                    // inserting data in user info table
                    $userinfoinput['user_id'] = $inserted;
                    $userinfoinserted = Userinfo::create($userinfoinput); 

                    // sending mail
                    $userName = $insert['fname'] . ' ' . $insert['lname'];
                    $userEmail = $insert['email'];
                    $subject = 'Welcome Message';
                    

                    if(Auth::attempt(['id'=>$inserted,'password'=>$request->password]))
                    {
                        $emaildata = (object) $insert; 
                        Mail::send(
                                    'template.default.emails.verify',
                                    ['data' => $emaildata],
                                    function ($message) use ($userName, $userEmail, $subject)
                                    {
                                        $message->to($userEmail, $userName)->subject($subject)->replyTo(
                                            'DoNotReply@design-craze.com', 'Design Craze'
                                        );
                                    }
                                );
                        
                        // redirectiong to desire link
                        return redirect()->route('dashboard');
                    }
                }
                else{
                    return redirect()->back()->with('servererror', 'Whoops!! looks like something went wrong.');
                }
            }

        }
        else{
            return redirect()->back();
        }
    }
}
