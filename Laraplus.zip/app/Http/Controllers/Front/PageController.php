<?php

namespace App\Http\Controllers\Front;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\Page;
use App\Models\Setting;
use App\Models\Category;
use App\Models\BlogCategory;
use App\Models\Blog;
use Illuminate\Support\Facades\Auth;
use Cornford\Googlmapper\MapperServiceProvider;
use Mapper;
use Validator;
use Mail;

class PageController extends Controller
{
    public function index($slug, $lang='en'){
        $data['settinghelper'] = $settinghelper = allsetting();
        if(Auth::user() && Auth::user()->role < 10 && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }
        else if(!Auth::user() && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }

            $data['data'] = page::where(['slug' => $slug, 'lang' => $lang, 'trashed' => 0])->firstOrFail();

        $data['userlevel'] = 0;
        $data['dataerror'] = 0;

        if(Auth::user())
        {
            if($data['data'] && $data['data']->id == $settinghelper['login_page'])
            {
                return redirect()->route('dashboard');
            }
            elseif($data['data'] && $data['data']->id == $settinghelper['signup_page'])
            {
                return redirect()->route('dashboard');
            }
            $data['logged_id'] = Auth::user()->id;
            $data['userlevel'] = Auth::user()->role;
        }

        if($data['data'] && $data['data']->template == "contact"){
            if(isset($settinghelper['contact_map']) && $settinghelper['contact_map']==1)
            {
                //checking map address
                $address = isset($settinghelper['contact_address']) && $settinghelper['contact_address'] != null ? $settinghelper['contact_address'] : "83 U.S. 1, Bridgeport, Connecticut, USA";
                if(isset($settinghelper['contact_latlong']) && $settinghelper['contact_latlong'] != null)
                {
                    $latlong = explode(',', $settinghelper['contact_latlong']);
                    
                    $latitude = trim($latlong[0]);
                    $longitude = trim($latlong[1]);
                }else{
                    $latitude = 22.819047;
                    $longitude = 89.555788;
                }

                // google map option 
                $zoom = isset($settinghelper['google_map_zoom']) && $settinghelper['google_map_zoom'] != null ? $settinghelper['google_map_zoom'] : 10;
                $type = isset($settinghelper['google_map_type']) && $settinghelper['google_map_type'] != ''  ? google_map_type()[$settinghelper['google_map_type']] : google_map_type()[1];
                $marker = isset($settinghelper['google_map_marker_show']) && $settinghelper['google_map_marker_show'] != 1  ? false : true;
                $scrollWheelZoom = isset($settinghelper['google_scrollzoom']) && $settinghelper['google_scrollzoom'] != 1  ? false : true;
                $overlay = 'TRAFFIC';
                $center = true;
                $locate = true;
                $ui = true;

                if(isset($settinghelper['makr_title']) && $settinghelper['makr_title'] != "")
                {
                    $mark_title = $settinghelper['makr_title']; 
                }elseif(isset($settinghelper['contact_address']) && $settinghelper['contact_address'] != "")
                {
                    $mark_title = $settinghelper['contact_address'];
                }else{
                    $mark_title = "";
                }

                $mark_icon = isset($settinghelper['google_mark_icon']) && $settinghelper['google_mark_icon'] != null ? $settinghelper['google_mark_icon'] : asset('assets/common/images/marker.png');
                $mark_animation = "DROP";
                if(isset($settinghelper['contact_map_show_by']) && $settinghelper['contact_map_show_by']==1)
                {
                    Mapper::map($latitude,$longitude,
                        [
                            'zoom' => $zoom,
                            'marker' => $marker,
                            'type' => $type,
                            'overlay' => $overlay,
                            'scrollWheelZoom' => $scrollWheelZoom,
                            'center' => $center,
                            'locate' => $locate,
                            'ui' => $ui,
                            'markers' => [
                                            'title' => $mark_title,
                                            'icon' => $mark_icon,
                                            'animation' => $mark_animation
                                        ],
                            'clusters' => [
                                            'size' => 10,
                                            'center' => true,
                                            'zoom' => 20
                                        ]
                        ]
                    );
                }
                else{
                    Mapper::location($address)->map(
                        [
                            'zoom' => $zoom,
                            'marker' => $marker,
                            'type' => $type,
                            'overlay' => $overlay,
                            'scrollWheelZoom' => $scrollWheelZoom,
                            'center' => $center,
                            'locate' => $locate,
                            'ui' => $ui,
                            'markers' => [
                                            'title' => $mark_title,
                                            'icon' => $mark_icon,
                                            'animation' => $mark_animation
                                        ],
                            'clusters' => [
                                            'size' => 10,
                                            'center' => true,
                                            'zoom' => 20
                                        ]
                        ]
                    );
                }
            }
        }

        else if($data['data'] && $data['data']->template == "blogcategories"){
            $data['getelements'] = array(
                    'sort' =>''
            );
            foreach($data['getelements'] as $key => $val){
                if ($val == ''){
                    unset($data['getelements'][$key]);
                }
            }

            $data['categories'] = Category::where(['trashed' => '0'])->orderBy('created_at', 'desc')->paginate(12);
            if(count($data['categories'])==0)
            {
                $data['dataerror'] = 1;
            }
        }

        else if($data['data'] && $data['data']->template == "searchblog"){
            $search = \Request::get('search');

            $searcharray = explode(' ', $search);
            
            $data['getelements'] = array(
                'search' =>$search
            );
            foreach($data['getelements'] as $key => $val){
                if ($val == ''){
                    unset($data['getelements'][$key]);
                }
            }

            $data['categories'] = Category::where(['trashed' => '0'])->get();
            
            if(\Request::get('tag')!=null){
                $tagval = \Request::get('tag');
                $data['myposts'] = Blog::where([ 'trashed' => '0'])->where('metatag','like','%'.$tagval.'%')->orderBy('updated_at', 'desc')->paginate(12)->appends($data['getelements']);
            }
            else{
            $current = 1;
            $data['myposts'] = Blog::where('trashed',0)->where(function($query) use($searcharray,$current){
                                    foreach ($searcharray as $wh){
                                        if($current==1){
                                            $query->where('name','like','%'.$wh.'%');
                                        }else {
                                            $query->orWhere('name','like','%'.$wh.'%');
                                        }
                                        $query->orWhere('description','like','%'.$wh.'%');
                                        $query->orWhere('metatag','like','%'.$wh.'%');
                                        $current =0;
                                    }
                                })->orderBy('updated_at', 'desc')->paginate(12)->appends($data['getelements']);
            }
            if(count($data['myposts'])==0)
            {
                $data['dataerror'] = 1;
            }
        }

        if($data['data']->home==1){
            $data['breadcrumb'] = breadcrumb(
                array(
                    ['Home','home']
                ),
                $settinghelper['brdcrmb_sep']
            );
        }
        else{
            $data['breadcrumb'] = breadcrumb(
                array(
                    ['Home','home'],
                    [$data['data']->name,'page',['slug'=>$slug]]
                ),
                $settinghelper['brdcrmb_sep']
            );
        }
        
        return view('template.' . $settinghelper['template'] . '.home', $data);
    }

    public function blogcategories($slug, $lang='en'){
        $data['settinghelper'] = $settinghelper = allsetting();
        if(Auth::user() && Auth::user()->role < 10 && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }
        else if(!Auth::user() && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }
        $data['data'] = page::where(['id' => $settinghelper['blogctg_page'], 'lang' => $lang, 'trashed' => 0])->firstOrFail();

        $data['userlevel'] = 0;
        $data['dataerror'] = 0;
        $data['urlslug'] = $slug;
        if(Auth::user())
        {
            if($data['data'] && $data['data']->id == $settinghelper['login_page'])
            {
                return redirect()->route('dashboard');
            }
            elseif($data['data'] && $data['data']->id == $settinghelper['signup_page'])
            {
                return redirect()->route('dashboard');
            }
            $data['logged_id'] = Auth::user()->id;
            $data['userlevel'] = Auth::user()->role;
        }

        if($data['data'] && $data['data']->template == "blogcategories"){
            $data['getelements'] = array(
                    'sort' =>''
            );
            foreach($data['getelements'] as $key => $val){
                if ($val == ''){
                    unset($data['getelements'][$key]);
                }
            }
            $data['categories'] = Category::where(['ctgslug' => $slug,'trashed' => '0'])->first();
            if($data['categories'] !=null){
                // dd($data['categories']);
                $data['myposts'] = $data['categories']->blogs()->orderBy('created_at', 'desc')->paginate(12);
                if(count($data['myposts'])==0)
                {
                    $data['dataerror'] = 1;
                }
            }
            else{
                $data['dataerror'] = 1;
            }
        }

        $data['webtitle'] = $webtitle = 'Blog Category - ' . $data['categories']->name;

        $data['breadcrumb'] = breadcrumb(
            array(
                ['Home','home'],
                [$data['data']->name,'page',['slug'=>$data['data']->slug]],
                [$data['categories']->name,'blogcategory',['slug'=>$slug]]
            ),
            $settinghelper['brdcrmb_sep']
        );
        return view('template.' . $settinghelper['template'] . '.home', $data);
    }
}