<?php

namespace App\Http\Controllers\Front;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Cornford\Googlmapper\MapperServiceProvider;
use Mapper;
use Validator;
use Mail;

class ContactController extends Controller
{
    //contact page
  //   public function contact($lang='en'){
  //       $data['settinghelper'] = $settinghelper = allsetting();
  //       if(Auth::user() && Auth::user()->role < 10 && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
  //           return redirect()->route('home');
  //       }
  //       else if(!Auth::user() && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
  //           return redirect()->route('home');
  //       }
  //       $data['userlevel'] = 0;
		// if(Auth::user())
		// {
  //           $data['logged_id'] = Auth::user()->id;
  //           $data['userlevel'] = Auth::user()->role;
		// }

		// if(isset($settinghelper['contact_map']) && $settinghelper['contact_map']==1)
		// {
		// 	//checking map address
		// 	$address = isset($settinghelper['contact_address']) && $settinghelper['contact_address'] != null ? $settinghelper['contact_address'] : "83 U.S. 1, Bridgeport, Connecticut, USA";

		// 	if(isset($settinghelper['contact_latlong']) && $settinghelper['contact_latlong'] != null)
		// 	{
		// 		$latlong = explode(',', $settinghelper['contact_latlong']);
				
		// 		$latitude = trim($latlong[0]);
		// 		$longitude = trim($latlong[1]);
		// 	}else{
		// 		$latitude = 22.819047;
		// 		$longitude = 89.555788;
		// 	}
		// 	// google map option 
		// 	$zoom = isset($settinghelper['google_map_zoom']) && $settinghelper['google_map_zoom'] != null ? $settinghelper['google_map_zoom'] : 10;
		// 	$type = isset($settinghelper['google_map_type']) && $settinghelper['google_map_type'] != ''  ? google_map_type()[$settinghelper['google_map_type']] : google_map_type()[1];
		// 	$marker = isset($settinghelper['google_map_marker_show']) && $settinghelper['google_map_marker_show'] != 1  ? false : true;
		// 	$scrollWheelZoom = isset($settinghelper['google_scrollzoom']) && $settinghelper['google_scrollzoom'] != 1  ? false : true;
		// 	$overlay = 'TRAFFIC';
		// 	$center = true;
		// 	$locate = true;
		// 	$ui = true;

		// 	if(isset($settinghelper['makr_title']) && $settinghelper['makr_title'] != "")
		// 	{
		// 		$mark_title = $settinghelper['makr_title'];	
		// 	}elseif(isset($settinghelper['contact_address']) && $settinghelper['contact_address'] != "")
		// 	{
		// 		$mark_title = $settinghelper['contact_address'];
		// 	}else{
		// 		$mark_title = "";
		// 	}

		// 	$mark_icon = isset($settinghelper['google_mark_icon']) && $settinghelper['google_mark_icon'] != null ? $settinghelper['google_mark_icon'] : "";
		// 	$mark_animation = "DROP";


		// 	if(isset($settinghelper['contact_map_show_by']) && $settinghelper['contact_map_show_by']==1)
		// 	{
		// 		Mapper::map($latitude,$longitude,
		// 			[
		// 				'zoom' => $zoom,
		// 				'marker' => $marker,
		// 				'type' => $type,
		// 				'overlay' => $overlay,
		// 				'scrollWheelZoom' => $scrollWheelZoom,
		// 				'center' => $center,
		// 				'locate' => $locate,
		// 				'ui' => $ui,
		// 				'markers' => [
		// 								'title' => $mark_title,
		// 								'icon' => $mark_icon,
		// 								'animation' => $mark_animation
		// 							],
		// 				'clusters' => [
		// 								'size' => 10,
		// 								'center' => true,
		// 								'zoom' => 20
		// 							]
		// 			]
		// 		);
		// 	}
		// 	else{
		// 		Mapper::location($address)->map(
		// 			[
		// 				'zoom' => $zoom,
		// 				'marker' => $marker,
		// 				'type' => $type,
		// 				'overlay' => $overlay,
		// 				'scrollWheelZoom' => $scrollWheelZoom,
		// 				'center' => $center,
		// 				'locate' => $locate,
		// 				'ui' => $ui,
		// 				'markers' => [
		// 								'title' => $mark_title,
		// 								'icon' => $mark_icon,
		// 								'animation' => $mark_animation
		// 							],
		// 				'clusters' => [
		// 								'size' => 10,
		// 								'center' => true,
		// 								'zoom' => 20
		// 							]
		// 			]
		// 		);
		// 	}
		// }

		
  //   	return view('template.' . $settinghelper['template'] . '.contactus', $data);
  //   }

    // contact process page
    public function contactusprocess(Request $request)
    {
        $data['settinghelper'] = $settinghelper = allsetting();
        // if(Auth::user() && Auth::user()->role < 10 && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
        //     return redirect()->route('home');
        // }
        // else if(!Auth::user() && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
        //     return redirect()->route('home');
        // }
		// validating form data
        $rules = [
            'name'=>'required|max:100|min:2',
            'email'=> 'required|email|max:255|min:5',
            'subject'=>'required|max:100|min:2',
            'message'=> 'required|max:3000|min:1',
            'g-recaptcha-response' => 'required|captcha'
        ];
        
        $errorMessages = [
            'name.required' => 'Name field is required', 
            'name.max' => 'Name field must consists of maximum 100 characters', 
            'name.min' => 'Name field must consists of minimum 2 characters', 
            'email.required' => 'Email field is required.',
            'email.email' => 'Email field contains invalid Email Address.',
            'email.max' => 'Email field must consists of maximum 50 characters', 
            'email.min' => 'Email field must consists of minimum 5 characters',
            'message.required' => 'Message field is required.', 
            'message.max' => 'Message field must consists of maximum 3000 characters',
            'message.min' => 'Message field must consists of minimum 1 characters',
            'g-recaptcha-response.required' => 'Recaptcha field is required.'
        ];

        
        $validation = Validator::make($request->all(), $rules, $errorMessages);
        
        if($validation->fails())
        {
            return redirect()->back()->withErrors($validation)->withInput();
        }
        else
        {
        	if($settinghelper['contact_email'] != null && $settinghelper['contact_company'] != null)
        	{
	        	// sending mail
        		$userName = $request->name;
        		$userEmail = $request->email;
        		$subject = $request->subject;

	            $emaildata = array(
	            	'username' => $request->name,
	            	'useremail' => $request->email,
	            	'subject' => $request->subject,
	            	'msg' => $request->message,
	            	'contact_email' => $settinghelper['contact_email'],
	            	'contact_company' => $settinghelper['contact_company']
	            );

	            $emaildata = (object) $emaildata;

	            $sentMail = Mail::send(
				                'template.default.emails.contact',
				                ['data' => $emaildata],
				                function ($message) use ($userName, $userEmail, $subject,$settinghelper)
				                {
				                    $message->to($settinghelper['contact_email'], $settinghelper['contact_company'])->subject($subject)->replyTo(
				                        $userEmail, $userName
				                    );
				                }
				            );
	            if($sentMail)
	            {
	            	return redirect()->back()->with('success', 'Message has been sent successfuyll! We will contact you soon.');
	            }else{
	            	return redirect()->back()->with('dissmiss', 'Message can not be sent now. Pelase try later.');
	            }
	        }else
	        {
	        	return redirect()->back()->with('dissmiss', 'Something is wrong with Email Setting. Please try later.');
	        }
        }
    }
}
