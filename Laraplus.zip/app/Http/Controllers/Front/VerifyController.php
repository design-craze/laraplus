<?php

namespace App\Http\Controllers\Front;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Mail;

class VerifyController extends Controller
{
    public function verify($vfcode)
    {
    	$settinghelper = allsetting();
        if(Auth::user() && Auth::user()->role < 10 && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }
        else if(!Auth::user() && $settinghelper['web_status'] !='' && $settinghelper['web_status'] > 1){
            return redirect()->route('home');
        }
        
        if (!Auth::user()){                                    //Authentication for unlogged users 
    		if($settinghelper['login_page']!=''){
            	return redirect()->route('page', [$settinghelper['login_page']]); 
    		}
    		else{
            	return redirect()->route('adminlogin'); 
    		}
        }
        else{
    		$verified = User::where(['id'=>Auth::user()->id,'vfcode'=>$vfcode])->update(['verified' => 2, 'vfcode'=>md5(Auth::user()->email.uniqid())]);
    		if($verified)
    		{
    			return redirect()->route('dashboard')->with('success','Congratulation! Your Email Address Has Been Verfied Successfully.');
    		}
    		else{
    			return redirect()->route('dashboard')->with('dissmiss','Could not verify your email address for accessing wrong verification link.');
    		}
        }
    }

    public function resendverifymail()
    {
        if (!Auth::user()){                                    //Authentication for unlogged users 
            $settinghelper = allsetting();
            if($settinghelper['login_page']!=''){
                return redirect()->route('page', [$settinghelper['login_page']]); 
            }
            else{
                return redirect()->route('adminlogin'); 
            }
        }
        else{
            // sending mail
            $userName = Auth::user()->fname . ' ' . Auth::user()->lname;
            $userEmail = Auth::user()->email;
            $subject = 'Email Verification | Larapress';
            
            $sentmail = Mail::send(
                            'template.default.emails.verify',
                            ['data' => Auth::user()],
                            function ($message) use ($userName, $userEmail, $subject)
                            {
                                $message->to($userEmail, $userName)->subject($subject)->replyTo(
                                    'DoNotReply@design-craze.com', 'Design Craze'
                                );
                            }
                        );

            if($sentmail)
            {
                return redirect()->back()->with('success','Mail sent Successfully to '. Auth::user()->email . ' with verification code. Please check your mail. If did not get any mail please click again the below link. '); 
            }
            else{
                return redirect()->back()->with('dissmiss','Oops! Could not send verification for some reasons.');
            }
        }
    }
}
