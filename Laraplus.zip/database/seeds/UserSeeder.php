<?php

use Illuminate\Database\Seeder;
use App\Models\User;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $user = new User();
        $user->username = 'superadmin';
        $user->email = 'superadmin@superadmin.com';
        $user->password = Hash::make('123456');
        $user->fname = "Super";
        $user->lname = "Admin";
        $user->role = 12;
        $user->logcode = md5('superadmin@superadmin.com'.uniqid().randomString(20));
        $user->vfcode = randomString(20);
        $user->save();
    }
}