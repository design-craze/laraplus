<?php

use Illuminate\Database\Seeder;
use App\Models\Menuplace;

class MenuplaceSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $menuplace = new Menuplace();
        $menuplace->slug = 'topmenu-1';
        $menuplace->menu_id = 1;
        $menuplace->save();

        $menuplace = new Menuplace();
        $menuplace->slug = 'topmenu-2';
        $menuplace->menu_id = 0;
        $menuplace->save();

        $menuplace = new Menuplace();
        $menuplace->slug = 'topmenu-3';
        $menuplace->menu_id = 0;
        $menuplace->save();

        $menuplace = new Menuplace();
        $menuplace->slug = 'mainmenu-1';
        $menuplace->menu_id = 0;
        $menuplace->save();

        $menuplace = new Menuplace();
        $menuplace->slug = 'mainmenu-2';
        $menuplace->menu_id = 0;
        $menuplace->save();

        $menuplace = new Menuplace();
        $menuplace->slug = 'mainmenu-3';
        $menuplace->menu_id = 0;
        $menuplace->save();

        $menuplace = new Menuplace();
        $menuplace->slug = 'sidemenu-1';
        $menuplace->menu_id = 0;
        $menuplace->save();

        $menuplace = new Menuplace();
        $menuplace->slug = 'sidemenu-2';
        $menuplace->menu_id = 0;
        $menuplace->save();

        $menuplace = new Menuplace();
        $menuplace->slug = 'sidemenu-3';
        $menuplace->menu_id = 0;
        $menuplace->save();

        $menuplace = new Menuplace();
        $menuplace->slug = 'sidemenu-4';
        $menuplace->menu_id = 0;
        $menuplace->save();

        $menuplace = new Menuplace();
        $menuplace->slug = 'bottommenu-1';
        $menuplace->menu_id = 0;
        $menuplace->save();

        $menuplace = new Menuplace();
        $menuplace->slug = 'bottommenu-2';
        $menuplace->menu_id = 0;
        $menuplace->save();

        $menuplace = new Menuplace();
        $menuplace->slug = 'bottommenu-3';
        $menuplace->menu_id = 0;
        $menuplace->save();
    }
}
