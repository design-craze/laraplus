<?php

use Illuminate\Database\Seeder;
Use App\Models\Menu;

class MenuSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $menu = new Menu();
        // $menu->slug = 'mainnav';
        $menu->name = 'Main Nav';
        $menu->selected = 1;
        $menu->save();
    }
}
