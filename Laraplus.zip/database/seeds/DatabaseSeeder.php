<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $this->call(BlogSeeder::class);
        $this->call(CategorySeeder::class);
        $this->call(CommentSeeder::class);
        $this->call(LikeSeeder::class);
        $this->call(MenuitemSeeder::class);
        $this->call(MenuplaceSeeder::class);
        $this->call(MenuSeeder::class);
        $this->call(PageSeeder::class);
        $this->call(SettingSeeder::class);
        $this->call(ThemeoptionSeeder::class);
        $this->call(UserinfoSeeder::class);
        $this->call(UserSeeder::class);
        $this->call(WidgetSeeder::class);
        $this->call(MediaSeeder::class);
    }
}
