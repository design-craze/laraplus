<?php

use Illuminate\Database\Seeder;
Use App\Models\Menuitem;

class MenuitemSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $menuitem = new Menuitem;
        $menuitem->parent_id = 0;
        $menuitem->menu_id = 1;
        $menuitem->name = 'Link1';
        $menuitem->page_id = 1;
        $menuitem->serial = 1;
        $menuitem->save();
    }
}
