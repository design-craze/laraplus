<?php

use Illuminate\Database\Seeder;
use App\Models\Setting;
class SettingSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        /*Theme setting---------------------------------------------*/
        
        $setting = new Setting();
        $setting->slug = 'template';
        $setting->value = 'default';
        $setting->save();

        /*General setting---------------------------------------------*/

        $setting = new Setting();
        $setting->slug = 'site_name';
        $setting->value = 'Larapress';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'logo_img';
        $setting->value = '';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'logo_type';
        $setting->value = 1;
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'favicon';
        $setting->value = '';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'primary_phone';
        $setting->value = '';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'primary_email';
        $setting->value = '';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'signable';
        $setting->value = 1;
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'web_status';
        $setting->value = 1;
        $setting->save();

        /*Web Structure Setting-----------------------------------------*/

        $setting = new Setting();
        $setting->slug = 'page_header';
        $setting->value = 1;
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'header_layout';
        $setting->value = 1;
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'page_title';
        $setting->value = 1;
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'title_layout';
        $setting->value = 2;
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'body_layout';
        $setting->value = 2;
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'breadcrumbs';
        $setting->value = 2;
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'brdcrmb_sep';
        $setting->value = '/';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'footer_layout';
        $setting->value = 1;
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'footer';
        $setting->value = 4;
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'bottom_footer';
        $setting->value = 1;
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'copyright_text';
        $setting->value = '&copy; 2017 | Design-craze | All Right Reserved';
        $setting->save();

        /*Page Setting-------------------------------------------------*/

        $setting = new Setting();
        $setting->slug = 'page_leftsidebar';
        $setting->value = '';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'page_rightsidebar';
        $setting->value = '';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'page_layout';
        $setting->value = '1';
        $setting->save();

        /*Blog Setting-------------------------------------------------*/

        $setting = new Setting();
        $setting->slug = 'blog_leftsidebar';
        $setting->value = '';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'blog_rightsidebar';
        $setting->value = '';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'blog_layout';
        $setting->value = '1';
        $setting->save();

        /*page link setting -----------------------------------------------*/

        $setting = new Setting();
        $setting->slug = 'login_page';
        $setting->value = '';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'signup_page';
        $setting->value = '';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'identify_page';
        $setting->value = '';
        $setting->save();


        $setting = new Setting();
        $setting->slug = 'coming_soon';
        $setting->value = '';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'under_dev';
        $setting->value = '';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'search_page';
        $setting->value = '';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'blogctg_page';
        $setting->value = '';
        $setting->save();

        /*Social Media --------------------------------------------------*/

        $setting = new Setting();
        $setting->slug = 'facebook';
        $setting->value = '';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'twitter';
        $setting->value = '';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'linkedin';
        $setting->value = '';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'google';
        $setting->value = '';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'skype';
        $setting->value = '';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'youtube';
        $setting->value = '';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'vimeo';
        $setting->value = '';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'pinterest';
        $setting->value = '';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'flickr';
        $setting->value = '';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'instagram';
        $setting->value = '';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'rss';
        $setting->value = '';
        $setting->save();

        /*Contact info setting-----------------------------------------*/

        $setting = new Setting();
        $setting->slug = 'contact_email';
        $setting->value = '';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'contact_phone';
        $setting->value = '';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'contact_company';
        $setting->value = '';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'contact_address';
        $setting->value = '';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'contact_map';
        $setting->value = '1';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'contact_latlong';
        $setting->value = '';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'contact_map_show_by';
        $setting->value = '1';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'google_map_zoom';
        $setting->value = '10';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'google_map_type';
        $setting->value = '1';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'google_map_marker_show';
        $setting->value = '1';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'google_mark_icon';
        $setting->value = null;
        $setting->save();

       /*CSS JS setting -----------------------------------------------*/

        $setting = new Setting();
        $setting->slug = 'custom_css';
        $setting->value = '';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'large_min_css';
        $setting->value = '';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'large_max_css';
        $setting->value = '';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'medium_min_css';
        $setting->value = '';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'medium_max_css';
        $setting->value = '';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'small_min_css';
        $setting->value = '';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'small_max_css';
        $setting->value = '';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'user_css';
        $setting->value = '';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'guest_css';
        $setting->value = '';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'custom_js';
        $setting->value = '';
        $setting->save();

        /*SEO setting -----------------------------------------------*/

        $setting = new Setting();
        $setting->slug = 'meta_title';
        $setting->value = 'Larapress';
        $setting->save();
        
        $setting = new Setting();
        $setting->slug = 'meta_tag';
        $setting->value = 'larapress, laravel, design craze, cms, laravel cms';
        $setting->save();
        
        $setting = new Setting();
        $setting->slug = 'meta_desc';
        $setting->value = 'Larapress is a Well Developed CMS designed with laravel. All Right reserved to Design Craze tm';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'google_vf_code';
        $setting->value = '';
        $setting->save();

        /*Responsive setting -----------------------------------------------*/

        $setting = new Setting();
        $setting->slug = 'large_breakpoint';
        $setting->value = 1199;
        $setting->save();
                
        $setting = new Setting();
        $setting->slug = 'medium_breakpoint';
        $setting->value = 991;
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'small_breakpoint';
        $setting->value = 767;
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'container_width_lg';
        $setting->value = 1170;

        $setting = new Setting();
        $setting->slug = 'container_width_md';
        $setting->value = 962;

        $setting = new Setting();
        $setting->slug = 'container_width_sm';
        $setting->value = 738;

        /*Mobile menu setting -----------------------------------------------*/

        $setting->save();

        $setting = new Setting();
        $setting->slug = 'mobile_breakpoint';
        $setting->value = 767;
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'menu_type';
        $setting->value = 'classic';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'classic_menutext';
        $setting->value = 'My Menu';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'sticky_header';
        $setting->value = 'yes';
        $setting->save();

        $setting = new Setting();
        $setting->slug = 'sticky_top';
        $setting->value = 300;
        $setting->save();

        // $setting = new Setting();
        // $setting->slug = 'sticky_id';
        // $setting->value = '';
        // $setting->save();
    }
}
