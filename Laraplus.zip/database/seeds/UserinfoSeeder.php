<?php

use Illuminate\Database\Seeder;
use App\Models\Userinfo;

class UserinfoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $userinfo = new Userinfo();
        $userinfo->user_id = 1;
        $userinfo->street1 = '';
        $userinfo->street2 = '';
        $userinfo->city = '';
        $userinfo->state = '';
        $userinfo->zip = '';
        $userinfo->country = '';
        $userinfo->sex = '';
        $userinfo->contact = '';
        $userinfo->description = '';
        $userinfo->save();
    }
}
