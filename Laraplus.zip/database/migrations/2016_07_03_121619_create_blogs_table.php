<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateBlogsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('blogs', function (Blueprint $table) {
            $table->increments('id');
            $table->string('slug')->unique();
            $table->string('type', 100)->default('blog');
            $table->string('name', 255);
            $table->string('thumb')->nullable();
            $table->text('description')->nullable();
            $table->text('metatag')->nullable();
            $table->integer('user_id');
            $table->tinyInteger('access_level')->default(0);
            $table->boolean('archived')->default(0);
            $table->boolean('trashed')->default(0);
            $table->tinyInteger('commentable')->default(1);
            $table->tinyInteger('featured')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('blogs');
    }
}
