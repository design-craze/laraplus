<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMenuitemsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('menuitems', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('parent_id')->default(0);
            $table->integer('menu_id')->default(0);
            $table->string('name')->nullable();
            $table->integer('page_id')->default(0);
            $table->integer('blog_id')->default(0);
            $table->string('link', 255)->nullable();
            $table->string('class', 255)->nullable();
            $table->boolean('newtab')->default(0);
            $table->boolean('megamenu')->default(0);
            $table->integer('serial');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('menuitems');
    }
}
