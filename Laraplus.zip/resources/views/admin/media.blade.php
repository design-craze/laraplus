@extends('admin.master.master')

@section('title', 'Media Manager')

@section('headcode')
	{{ Html::style('assets/common/css/pagination.css') }}
	{{ Html::style('assets/common/js/datatables/dataTables.bootstrap.css') }}
@endsection

@section('breadcambs', '<i class="fa fa-dashboard"></i> Media Manager')

@section('bodycode')
<div class="box admin-table">
    <div class="box-body">
	    <div class="box-header">
	        <div style="padding:17px;"></div>
	    </div>
  		<table id="pagetable" class="table table-bordered table-striped">
            <thead>
          		<tr>
                    <th>Item</th>
                    <th>URL</th>
                    <th>Manage</th>
              	</tr>
            </thead>
            <tbody>
            	@if($media)
					@foreach($media as $page)
	              	<tr>
	                    <td>
	                    	<div style="overflow:hidden; width:75px; height:75px; border-radius:10px; margin:0 auto;">
	                    		<img style="width:100%;" src="{{route('home')}}/{{$page->filepath}}thumbs/{{$page->filename}}" alt="">
                    		</div>
	                    </td>
	                    <td style="vertical-align:middle; white-space: pre-wrap;">{{route('home')}}/{{$page->filepath}}{{$page->filename}}</td>
	                    <td style="vertical-align:middle;">
	                    	<ul class="menu-manager">
	                    		<li><a class="imageview" data-fullimage="{{route('home')}}/{{$page->filepath}}{{$page->filename}}" href="#" data-toggle="tooltip" title="View Image"><i class="fa fa-picture-o"></i></a></li>
	                    		<li><a href="{{route('mediadelete', ['id' => $page->id])}}" class="confirmation" data-toggle="tooltip" title="Delete This Image" data-alert="Do you really want to delete this item?"><i class="fa fa-trash-o"></i></a></li>
	                    	</ul>
	                    </td>
	              	</tr>
					@endforeach
				@endif
            </tbody>
            <tfoot>
              	<tr>
                    <th>item</th>
                    <th>URL</th>
                    <th>Manage</th>
              	</tr>
            </tfoot>
  		</table>
    </div><!-- /.box-body -->
</div><!-- /.box -->
	<div class="common-pagination">
		<?php 
			$pagifpname = 'First'; $pagippname = 'prev'; $pagilpname = 'Last'; $paginpname = 'Next';
			if($media->currentPage() == '1'){
				$pagifp = '<span>'.$pagifpname.'</span>'; $pagipp = '<span>'.$pagippname.'</span>';
			}
			else{
				$pagifp = '<a href="'.route('mediamanager').'?';
				if(isset($getelements)){
					foreach($getelements as $key => $val){
		            	$pagifp .= $key.'='.$val.'&';
			        }
				}
				$pagifp .= 'page=1'.'">'.$pagifpname.'</a>'; $pagipp = '<a href="'.$media->previousPageUrl().'">'.$pagippname.'</a>';
			}
			if($media->lastPage() == $media->currentPage()){
				$pagilp = '<span>'.$pagilpname.'</span>'; $paginp = '<span>'.$paginpname.'</span>';
			}
			else{
				$pagilp = '<a href="'.route('mediamanager').'?';
				if(isset($getelements)){
					foreach($getelements as $key => $val){
		            	$pagilp .= $key.'='.$val.'&';
			        }
		        }
				$pagilp .= 'page='.$media->lastPage().'">'.$pagilpname.'</a>'; $paginp = '<a href="'.$media->nextPageUrl().'">'.$paginpname.'</a>';
			}
		?>
		@if($media->total()>$media->count())
			<ul class="prevsec">
				<li>{!!$pagifp!!}</li>
				<li>{!!$pagipp!!}</li>
			</ul>
			{{$media->links()}}
			<ul class="nextsec">
				<li>{!!$paginp!!}</li>
				<li>{!!$pagilp!!}</li>
			</ul>
			<div style="clear:both"></div>
		@endif
	</div>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div>
					<img id="previewframe" src="" alt="" style="max-width:500px; display:block; margin:0 auto">
				</div>
			</div>
		</div>
	</div>
</div>
@endsection

@section('jscode')
	{{ Html::script('assets/common/js/datatables/jquery.dataTables.min.js') }}
	{{ Html::script('assets/common/js/datatables/dataTables.bootstrap.min.js') }}
	<script>
	    $(function () {
	      	$("#pagetable").DataTable({
	      		"paging": false,
	      		"info": false,
	      	});
	    });
		$(function () {
		  	$('[data-toggle="tooltip"]').tooltip()
		})
		$(function () {
			$('.imageview').on('click', function(e){
				e.preventDefault();
				var $this = $(this);
				$('#previewframe'). attr('src', $this.attr('data-fullimage'))
			})
		})
    </script>
@endsection