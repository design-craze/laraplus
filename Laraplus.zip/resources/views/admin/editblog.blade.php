@extends('admin.master.master')

@section('title', 'Edit Blog')

@section('headcode')
    {{ Html::style('assets/common/js/tags/tagmanager.css') }}
    {{ Html::style('assets/admin/vendor/select2/select2.min.css') }}
    {{ Html::style('assets/common/js/dropzone/dropzone.min.css') }}
    {{ Html::style('assets/admin/css/mediamanager.css') }}
@endsection

@section('breadcambs', '<i class="fa fa-dashboard"></i> Edit Blog')

@section('bodycode')
    <div class="row">
        <div class="col-md-12">
            <a href="{{route('blogmanager')}}" class="btn btn-default btn-flat">Go To Blog lists</a>
        </div>
    </div>
    <!-- <strong>Show Page : </strong> <a href="" target="_blank">Pagelink</a> -->
    @if(isset($singleblog) && !empty($singleblog))
    {{ Form::open(array('route'=>['blogeditprocess','id'=>$singleblog->id], 'method'=>'post')) }}
        <div class="row">
            <div class="col-md-8">
                <div class="panel-body page-editor">
                    <div class="form-horizontal">
                        <div class="form-group">
                            <input type="text" name="name" class="form-control input-lg" placeholder="Enter Title Here" value="<?php if(old('name')!=''){echo old('name');} elseif(!empty($singleblog->name)){echo $singleblog->name;} ?>">
                        </div>
                    </div>
                    <div class="form-horizontal">
                        <div class="form-group">
                            <input type="text" name="slug" class="form-control input-lg" placeholder="enter-slug-here" value="<?php if(old('slug')!=''){echo old('slug');} elseif(!empty($singleblog->slug)){echo $singleblog->slug;} ?>">
                        </div>
                    </div>
                </div>
                <div class="panel-body page-editor">
                    <div class="form-horizontal">
                        <div class="form-group">
                            <textarea id="maintext" name="description" class="form-control" placeholder="Free Content goes here..."><?php if(old('description')!=''){echo old('description');} elseif(!empty($singleblog->description)){echo $singleblog->description;} ?></textarea>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 ">
                <div class="page-editor">

                    <div class="panel">
                        <div class="panel-heading">
                            <div class="panel-title"> <i class="fa fa-pencil"></i> Tags</div>
                        </div>
                        <div class="panel-body">
                            <div class="form-horizontal">
                                <div class="form-group">
                                        <div class="col-md-12">
                                            <input type="text" placeholder="Add a new tag.." class="form-control tm-input" id="tagmanager">
                                            <div class="tag-container"></div>
                                        </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="panel">
                        <div class="panel-heading">
                            <div class="panel-title"> <i class="fa fa-pencil"></i> User Level</div>
                        </div>
                        <div class="panel-body">
                            <div class="form-horizontal">
                                <div class="form-group">
                                        <div class="col-md-12">
                                            <select class="form-control" style="width: 100%;" name="access_level">
                                                <?php
                                                    $a =role($lang='en');
                                                ?>
                                                @foreach($a as $key => $val)
                                                    <option value="{{$key}}"<?php if(old('access_level')==$key){echo ' selected';} elseif($singleblog->access_level==$key){echo ' selected';}?>>{{$val}}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="panel">
                        <div class="panel-heading">
                            <div class="panel-title"> <i class="fa fa-pencil"></i> Allow Comment</div>
                        </div>
                        <div class="panel-body">
                            <div class="form-horizontal">
                                <div class="form-group">
                                        <div class="col-md-12">
                                            <select class="form-control" style="width: 100%;" name="commentable">
                                                    <option value="1"<?php if(old('commentable')=='1'){echo ' selected';} elseif($singleblog->commentable=='1'){echo ' selected';}?>>Yes</option>
                                                    <option value="0" <?php if(old('commentable')=='0'){echo ' selected';} elseif($singleblog->commentable=='0'){echo ' selected';}?>>No</option>
                                            </select>
                                        </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="panel">
                        <div class="panel-heading">
                            <div class="panel-title"> <i class="fa fa-pencil"></i> Categories</div>
                        </div>
                        <div class="panel-body">
                            <div class="form-horizontal">
                                <div class="form-group">
                                    <div class="col-md-12">
                                        <select multiple class="form-control select2" name="category[]" data-placeholder="Select categories" style="width: 100%;">
                                            @foreach($categories as $cat)
                                                <?php
                                                $singlecat='';

                                                if(old('category')!=null){
                                                    foreach($catgs as $scat){
                                                        if($cat->id==$scat){
                                                            $singlecat= ' selected';
                                                        }
                                                    }
                                                }
                                                elseif($dbcategory!=null){
                                                    foreach($dbcategory as $scat){
                                                        if($cat->id==$scat->id){
                                                            $singlecat= ' selected';
                                                        }
                                                    }
                                                }
                                                ?>
                                                <option value="{{$cat->id}}"{{$singlecat}}>{{$cat->name}}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="panel">
                        <div class="panel-heading">
                            <div class="panel-title"> <i class="fa fa-pencil"></i> Thumbnail</div>
                        </div>
                        <div class="panel-body">
                            <div class="form-horizontal">
                                <div class="form-group">
                                    <div class="col-md-12">
                                        <input type="text" class="form-control" name="thumb" placeholder="image path for thumbnail" value="<?php if(old('thumb')!=''){echo old('thumb');} elseif(!empty($singleblog->thumb)){echo $singleblog->thumb;} ?>">
                                        <a href="#" class="mediafiledupload btn btn-primary btn-flat" style="margin-top: 15px;">Upload thumb</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="panel">
                        <div class="panel-heading">
                            <div class="panel-title"> <i class="fa fa-pencil"></i> Create Blog</div>
                        </div>
                        <div class="panel-body">
                            <div class="form-horizontal">
                                <div class="form-group">
                                    <div class="col-md-12">
                                        <input type="submit" name="update" class="btn btn-primary btn-flat" value="Update Blog">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    {{ Form::close() }}
    @endif
    <!-- start: model -->
    <div id="mediapopup" data-backdrop="false" data-keyboard="false" class="modal bs-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                  <div class="modal-header">
                    <button id="mymediacancletbutton" type="button" class="btn btn-default pull-right" data-dismiss="modal">Close</button>
                    <h4 class="modal-title" id="myModalLabel">Media Manager</h4>
                  </div>
                  <div class="modal-body">
                    <div class="nav-tabs-custom">
                        <ul class="nav nav-tabs">
                          <li class="active"><a href="#tab_1" data-toggle="tab">Upload</a></li>
                          <li><a href="#tab_2" data-toggle="tab">Images</a></li>
                        </ul>
                        <div class="tab-content">
                          <div class="tab-pane active" id="tab_1">
                            {{ Form::open(array('route'=>['mediauploadprocess'], 'class'=> 'dropzone', 'id' => 'addImages', 'method'=>'post')) }}
                            {{Form::close()}}
                          </div><!-- /.tab-pane -->
                          <div class="tab-pane" id="tab_2">
                            <form action="#" method="post">
                             <div class="row">
                                 <div class="col-md-8">
                                    <ul class="listrap list-inline" id="medialibraryul" data-libraryimage="">
                                        @if(isset($mymedia) && $mymedia!='')
                                            @foreach($mymedia as $mysinglemedia)
                                                <li class="medialibraryli" data-libraryimage="{{route('home')}}/{{$mysinglemedia->filepath}}{{$mysinglemedia->filename}}">
                                                    <div class="listrap-toggle">
                                                        <span></span>
                                                        <img src="{{route('home')}}/{{$mysinglemedia->filepath}}thumbs/{{$mysinglemedia->filename}}" />
                                                    </div>
                                                </li>
                                            @endforeach
                                        @endif
                                    </ul>
                                 </div>
                                 <div class="col-md-4" style="border-left: 1px solid #eeeeee;">
                                     <h4>Attachment Details</h4>
                                     <hr>
                                     <div class="form-horizontal">
                                        <div class="form-group">
                                            <div class="col-sm-12 clearfix">
                                                <button id="mymediaselectbutton" class="btn btn-primary btn-sm pull-right">Add Image</button>
                                            </div>
                                        </div>
                                     </div>
                                     <img id="mediaimagepreview" src="https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcTPojpzonCfH7DzKVrniwYFN1NDo5ypcABz_S-13xRgeehz4c8CE33koAw" alt="IMG" class="img-responsive">
                                     <hr>
                                     <div class="form-horizontal">
                                        <div class="form-group">
                                            <label for="inputEmail3" class="col-sm-4">URL</label>
                                            <div class="col-sm-8">
                                                <input id="mediaimageurl" type="url" class="form-control input-sm" placeholder="URL">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="inputEmail3" class="col-sm-4">ALT TEXT</label>
                                            <div class="col-sm-8">
                                                <input id="mediaimagealttext" type="text" class="form-control input-sm" placeholder="Enter ALT Text">
                                            </div>
                                        </div>

                                    </div>
                                     
                                 </div>
                             </div>
                             </form>
                          </div><!-- /.tab-pane -->
                        </div><!-- /.tab-content -->
                      </div><!-- nav-tabs-custom -->
                  </div>
                </div>
        </div>
    </div>
@endsection


@section('jscode')
    {{ Html::script('assets/common/js/tinymce/tinymce.min.js') }}
    {{ Html::script('assets/common/js/tags/jquery.validate.min.js') }}
    {{ Html::script('assets/common/js/tags/tagmanager.js') }}
    {{ Html::script('assets/admin/vendor/select2/select2.full.min.js') }}
    {{ Html::script('assets/common/js/dropzone/dropzone.min.js') }}
    {{ Html::script('assets/admin/js/admintinymceintegration.js') }}
    <!-- tinymce -->

    <script>
        //Init jquery Date Picker
        // $('.datepicker').datepicker({
        //      format: 'dd/mm/yyyy',
        //      autoclose: true,
        //      orientation: 'bottom'
        //  });

        //Init jquery Tags Manager 
        $(".tm-input").tagsManager({
        tagsContainer: '.tag-container',
                prefilled: [
                    <?php
                        if(old('metatag')!=null)
                        {
                            $meta= explode(',', old('metatag'));
                            foreach($meta as $tag){
                                echo '"'.$tag.'",';
                            }
                        }elseif(isset($singleblog->metatag) && $singleblog->metatag!=null)
                        {
                            $meta= explode(',', $singleblog->metatag);
                            foreach($meta as $tag){
                                echo '"'.$tag.'",';
                            }
                        }
                    ?>
                ],
                tagClass: 'tm-tag-info',
                hiddenTagListName: 'metatag',
                hiddenTagListId: null
        });
        $(function () {
            //Initialize Select2 Elements
            $(".select2").select2();
        })
    </script>
    {{ Html::script('assets/admin/js/adminmedialibraryintegration.js') }}
@endsection