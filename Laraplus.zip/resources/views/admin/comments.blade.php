@extends('admin.master.master')

@section('title', 'Comment Manager')

@section('headcode')
	{{ Html::style('assets/common/css/pagination.css') }}
	{{ Html::style('assets/common/js/datatables/dataTables.bootstrap.css') }}
@endsection

@section('breadcambs', '<i class="fa fa-dashboard"></i> Comment Manager')

@section('bodycode')
<div class="box admin-table">
    <div class="box-header">
    	<h3>Comments</h3>
    </div>
    <div class="box-body">
  		<table id="pagetable" class="table table-bordered table-striped">
            <thead>
          		<tr>
                    <th>Author</th>
                    <th>Comment</th>
                    <th>In Response To</th>
                    <th>Sub Comment</th>
                    <th>Submited On</th>
                    <th>Manage</th>
              	</tr>
            </thead>
            <tbody>
            	@if($comments)
					@foreach($comments as $page)
					@if($page->parent_id == 0)
	              	<tr>
	                    <td>{{$page->user->fname}} {{$page->user->lname}}</td>
	                    <td>{{$page->description}}</td>
	                    <td>{{$page->blog['name']}}</td>
	                    <td>
	                    	<?php $count = 0 ?>
	                    	@foreach($comments as $val)
	                    		@if($val->parent_id == $page->id)
	                    		<?php $count = $count+1 ?>
	                    		@endif
	                    	@endforeach
	                    	@if($count > 0)
	                    	<a href="{{ route('subcomment',['id'=>$page->id]) }}">{{ $count }}</a>
	                    	@else
	                    	{{ $count }}
	                    	@endif
	                    </td>
	                    <td>{{time_elapsed_string($page->created_at)}}</td>
	                    <td>
	                    	<ul class="menu-manager">
	                    		<li><a href="{{route('commentedit', ['id' => $page->id])}}" data-toggle="tooltip" title="Edit This Comment"><i class="fa fa-pencil-square-o"></i></a></li>
	                    		<li><a href="{{route('commentdelete', ['id' => $page->id])}}" class="confirmation" data-alert="Do You Want To Delete This Comment?" data-toggle="tooltip" title="Delete This Comment"><i class="fa fa-trash-o"></i></a></li>
	                    	</ul>
	                    </td>
	              	</tr>
					@endif
					@endforeach
				@endif
            </tbody>
            <tfoot>
              	<tr>
                    <th>Author</th>
                    <th>Comment</th>
                    <th>In Response To</th>
                    <th>Sub Comment</th>
                    <th>Submited On</th>
                    <th>Manage</th>
              	</tr>
            </tfoot>
  		</table>
    </div><!-- /.box-body -->
</div><!-- /.box -->
	<div class="common-pagination">
		<?php 
			$pagifpname = 'First'; $pagippname = 'prev'; $pagilpname = 'Last'; $paginpname = 'Next';
			if($comments->currentPage() == '1'){
				$pagifp = '<span>'.$pagifpname.'</span>'; $pagipp = '<span>'.$pagippname.'</span>';
			}
			else{
				$pagifp = '<a href="'.route('managecategory').'?';
				// foreach($getelements as $key => $val){
	   //          	$pagifp .= $key.'='.$val.'&';
		  //       }
				$pagifp .= 'page=1'.'">'.$pagifpname.'</a>'; $pagipp = '<a href="'.$comments->previousPageUrl().'">'.$pagippname.'</a>';
			}
			if($comments->lastPage() == $comments->currentPage()){
				$pagilp = '<span>'.$pagilpname.'</span>'; $paginp = '<span>'.$paginpname.'</span>';
			}
			else{
				$pagilp = '<a href="'.route('managecategory').'?';
				// foreach($getelements as $key => $val){
	   //          	$pagilp .= $key.'='.$val.'&';
		  //       }
				$pagilp .= 'page='.$comments->lastPage().'">'.$pagilpname.'</a>'; $paginp = '<a href="'.$comments->nextPageUrl().'">'.$paginpname.'</a>';
			}
		?>
		@if($comments->total()>$comments->count())
			<ul class="prevsec">
				<li>{!!$pagifp!!}</li>
				<li>{!!$pagipp!!}</li>
			</ul>
			{{$comments->links()}}
			<ul class="nextsec">
				<li>{!!$paginp!!}</li>
				<li>{!!$pagilp!!}</li>
			</ul>
			<div style="clear:both"></div>
		@endif
	</div>
</div>
@endsection

@section('jscode')
	{{ Html::script('assets/common/js/datatables/jquery.dataTables.min.js') }}
	{{ Html::script('assets/common/js/datatables/dataTables.bootstrap.min.js') }}
	<script>
	    $(function () {
	      	$("#pagetable").DataTable({
	      		"paging": false,
	      		"info": false,
	      	});
	    });
		$(function () {
		  	$('[data-toggle="tooltip"]').tooltip()
		})
    </script>
@endsection