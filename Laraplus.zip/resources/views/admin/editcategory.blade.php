@extends('admin.master.master')

@section('title', 'Edit Category')

@section('headcode')
    {{ Html::style('assets/common/js/tags/tagmanager.css') }}
@endsection

@section('breadcambs', '<i class="fa fa-dashboard"></i> Edit Category')

@section('bodycode')
    <div class="row">
        <div class="col-md-12">
            <a href="{{route('managecategory')}}" class="btn btn-default btn-flat">Go To Category lists</a>
        </div>
    </div>
    <!-- <strong>Show Page : </strong> <a href="" target="_blank">Pagelink</a> -->
    
    {{ Form::open(array('route'=>['editcategoryprocess', 'id' => $singlecategory->id], 'method'=>'post')) }}
        <div class="row">
            <div class="col-md-8">
                <div class="panel-body page-editor">
                    <div class="form-horizontal">
                        <div class="form-group">
                            <input type="text" name="name" class="form-control input-lg" placeholder="Enter Title Here" value="<?php if(old('name')!=''){echo old('name');} else{echo $singlecategory->name;} ?>">
                        </div>
                    </div>
                    <div class="form-horizontal">
                        <div class="form-group">
                            <input type="text" name="ctgslug" class="form-control input-lg" placeholder="enter-slug-here" value="<?php if(old('ctgslug')!=''){echo old('ctgslug');} else{echo $singlecategory->ctgslug;} ?>">
                        </div>
                    </div>
                </div>
                <div class="panel-body page-editor">
                    <div class="form-horizontal">
                        <div class="form-group">
                            <textarea id="maintext" name="description" class="form-control" placeholder="Free Content goes here..."><?php if(old('description')!=''){echo old('description');} else{echo $singlecategory->description;} ?></textarea>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 ">
                <div class="page-editor">
                    <div class="panel">
                        <div class="panel-heading">
                            <div class="panel-title"> <i class="fa fa-pencil"></i> Create Category</div>
                        </div>
                        <div class="panel-body">
                            <div class="form-horizontal">
                                <div class="form-group">
                                    <div class="col-md-12">
                                        <input type="submit" class="btn btn-primary btn-flat" value="Update Category">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    {{ Form::close() }}
@endsection


@section('jscode')
    {{ Html::script('assets/common/js/tinymce/tinymce.min.js') }}
    {{ Html::script('assets/common/js/tags/jquery.validate.min.js') }}
    <script type="text/javascript">
        tinymce.init({
            selector: "#maintext",
            menubar: false,
            theme: "modern",
            relative_urls: false,
            force_div_newlines : true,
            force_h1_newlines : true,
            force_h2_newlines : true,
            force_h3_newlines : true,
            force_h4_newlines : true,
            force_h5_newlines : true,
            force_h6_newlines : true,
            force_p_newlines : true,
            force_ul_newlines : true,
            force_ol_newlines : true,
            force_li_newlines : true,
            force_hr_newlines : true,
            forced_br_newlines : true,
            plugins: [
                "advlist autolink lists link image charmap print preview hr anchor pagebreak",
                "searchreplace wordcount visualblocks visualchars code fullscreen",
                "insertdatetime media nonbreaking save table contextmenu directionality",
                "emoticons template paste textcolor colorpicker textpattern"
            ],
            toolbar1: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent",
            toolbar2: "print preview | forecolor backcolor | code link image mybutton",
            image_advtab: false//,
            // setup : function(ed) {
            //     // Add a custom button
            //     ed.addButton('mybutton', {
            //         title : 'My button',
            //         image : 'http://www.query.com/assets/admin/img/user2-160x160.jpg',
            //         onclick : function() {
            //             // Add you own code to execute something on click
            //             ed.focus();
            //             ed.selection.setContent('<img src="http://www.query.com/assets/admin/img/user2-160x160.jpg">');
            //         }
            //     })
            // }
        })
    </script>
    <!-- tinymce -->
@endsection