@extends('admin.master.master')

@section('title', 'Archived Blog')

@section('headcode')
	{{ Html::style('assets/common/css/pagination.css') }}
	{{ Html::style('assets/common/js/datatables/dataTables.bootstrap.css') }}
@endsection

@section('breadcambs', '<i class="fa fa-dashboard"></i> Archived Blog')

@section('bodycode')
<div class="box admin-table">
    <div class="box-header">
        <a href="{{route('blogmanager')}}" class="btn btn-default btn-flat">Blog Manager</a> <a href="{{route('trashblog')}}" class="btn btn-default btn-flat">Trashed Blogs</a> <a href="{{route('newblog')}}" class="btn btn-default btn-flat">Create Blog</a>
    </div>
    <div class="box-body">
  		<table id="pagetable" class="table table-bordered table-striped">
            <thead>
          		<tr>
                    <th>Slug</th>
                    <th>Name</th>
                    <th>Author</th>
                    <th>Access Level</th>
                    <th>Manage</th>
              	</tr>
            </thead>
            <tbody>
            	@if($pages)
					@foreach($pages as $page)
	              	<tr>
	                    <td>{{$page->slug}}</td>
	                    <td>{{$page->name}}</td>
	                    <td>{{$page->user->username}}</td>
	                    <td>{{accesslevel($page->access_level, 'en')}}</td>
	                    <td>
	                    	<ul class="menu-manager">
	                    		<li><a href="{{route('tempblogdelete', ['id' => $page->id, 'from' => 1])}}" class="confirmation" data-alert="Do You Want To Send This Article To Trash?" data-toggle="tooltip" title="Send This Article to Trash"><i class="fa fa-trash-o"></i></a></li>
	                    		<li><a href="{{route('restorearchiveblog', ['id' => $page->id])}}" class="confirmation" data-alert="Do You Want To Make this blog Live from Archive?" data-toggle="tooltip" title="Make This blog Live from Archive"><i class="fa fa-level-up"></i></a></li>
	                    	</ul>
	                    </td>
	              	</tr>
					@endforeach
				@endif
            </tbody>
            <tfoot>
              	<tr>
                    <th>Slug</th>
                    <th>Name</th>
                    <th>Author</th>
                    <th>Access Level</th>
                    <th>Manage</th>
              	</tr>
            </tfoot>
  		</table>
    </div><!-- /.box-body -->
</div><!-- /.box -->
	<div class="common-pagination">
		<?php 
			$pagifpname = 'First'; $pagippname = 'prev'; $pagilpname = 'Last'; $paginpname = 'Next';
			if($pages->currentPage() == '1'){
				$pagifp = '<span>'.$pagifpname.'</span>'; $pagipp = '<span>'.$pagippname.'</span>';
			}
			else{
				$pagifp = '<a href="'.route('blogmanager').'?';
				foreach($getelements as $key => $val){
	            	$pagifp .= $key.'='.$val.'&';
		        }
				$pagifp .= 'page=1'.'">'.$pagifpname.'</a>'; $pagipp = '<a href="'.$pages->previousPageUrl().'">'.$pagippname.'</a>';
			}
			if($pages->lastPage() == $pages->currentPage()){
				$pagilp = '<span>'.$pagilpname.'</span>'; $paginp = '<span>'.$paginpname.'</span>';
			}
			else{
				$pagilp = '<a href="'.route('blogmanager').'?';
				foreach($getelements as $key => $val){
	            	$pagilp .= $key.'='.$val.'&';
		        }
				$pagilp .= 'page='.$pages->lastPage().'">'.$pagilpname.'</a>'; $paginp = '<a href="'.$pages->nextPageUrl().'">'.$paginpname.'</a>';
			}
		?>
		@if($pages->total()>$pages->count())
			<ul class="prevsec">
				<li>{!!$pagifp!!}</li>
				<li>{!!$pagipp!!}</li>
			</ul>
			{{$pages->links()}}
			<ul class="nextsec">
				<li>{!!$paginp!!}</li>
				<li>{!!$pagilp!!}</li>
			</ul>
			<div style="clear:both"></div>
		@endif
	</div>
</div>
@endsection

@section('jscode')
	{{ Html::script('assets/common/js/datatables/jquery.dataTables.min.js') }}
	{{ Html::script('assets/common/js/datatables/dataTables.bootstrap.min.js') }}
	<script>
	    $(function () {
	      	$("#pagetable").DataTable({
	      		"paging": false,
	      		"info": false,
	      	});
	    });
		$(function () {
		  	$('[data-toggle="tooltip"]').tooltip()
		})
    </script>
@endsection