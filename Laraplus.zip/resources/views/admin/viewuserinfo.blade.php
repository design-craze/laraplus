@extends('admin.master.master')

@section('title', 'User Information')

@section('headcode')
	{{ Html::style('assets/common/css/pagination.css') }}
	{{ Html::style('assets/common/js/datatables/dataTables.bootstrap.css') }}
@endsection

@section('breadcambs', '<i class="fa fa-dashboard"></i> User Information')

@section('bodycode')

<div class="box-header">
    <a href="{{ route('createuser') }}" class="btn btn-default btn-flat">Create a New User</a>
    <a href="{{ route('userlist') }}" class="btn btn-default btn-flat">Users List</a>
</div>

<div class="row">
	@if($dataerror==0)
	<div class="col-md-2">
		<div class="small-box bg-yellow">
        	<div class="inner text-center">
        	@if(isset($userinfo) && !empty($userinfo->avatar) && !is_int($userinfo->avatar))
			<img src="{{ asset(path_profile().$userinfo->avatar) }}" alt="{{$userinfo->avatar}}" class="img-responsive img-circle">
			@elseif($userinfo->sex == 'f')
			<img src="{{ asset(path_profile().'female.jpg') }}" alt="female.jpg" class="img-responsive img-circle">
			@else
			<img src="{{ asset(path_profile().'male.jpg') }}" alt="male.jpg" class="img-responsive img-circle">
			@endif
			</div>
        </div>
	</div>
	<div class="col-md-10">
		<div class="box">
			<div class="box-header with-border">
				<div class="row">
					<div class="col-md-6">
						<h3 class="box-title">User Information</h3>
					</div>
					<div class="col-md-6">
						@if($logged_role > $user->role || $logged_id == $user->id)
						<a href="{{ route('edituserinfo', ['id'=>$user->id]) }}" class="btn btn-primary btn-flat pull-right">Edit This User</a>
						@endif
					</div>
				</div>
            </div><!-- /.box-header -->
            <div class="box-body">
            	<div class="row">
            		<div class="col-md-6">
            			<table class="table table-striped">
							<caption>
								User Login Details
							</caption>
							<tr>
								<td class="col-xs-3 col-sm-6">User ID</td>
								<td>: {{$user->id}}</td>
							</tr>
							<tr>
								<td>Name</td>
								<td>: {{$user->fname}} {{$user->lname}}</td>
							</tr>
							<tr>
								<td>Username</td>
								<td>: {{$user->username}}</td>
							</tr>
							<tr>
								<td>Email</td>
								<td>: <a href="mailto:{{$user->email}}">{{$user->email}}</a></td>
							</tr>
							<tr>
								<td>Role</td>
								<td>: {{roleaccess($user->role)}}</td>
							</tr>
							<tr>
								<td>Email Verification</td>
								<td>: 
									@if($user->verified==1)
				                    	<span class="label label-danger">{{isemailverified($user->verified)}}</span>
				                    @elseif($user->verified==2)
				                    	<span class="label label-success">{{isemailverified($user->verified)}}</span>
				                    @endif
								</td>
							</tr>
							<tr>
								<td>Status</td>
								<td> : 
									@if($user->active==1)
				                    	<span class="label label-danger">{{activelevel($user->active)}}</span>	
				                    @elseif($user->active==2)
				                    	<span class="label label-warning">{{activelevel($user->active)}}</span>	
				                    @elseif($user->active==3)
				                    	<span class="label label-info">{{activelevel($user->active)}}</span>
				                    @elseif($user->active==4)
				                    	<span class="label label-success">{{activelevel($user->active)}}</span>
				                    @endif
								</td>
							</tr>
						</table>
            		</div>
            		@if(isset($userinfo))
            		<div class="col-md-6">
            			<table class="table table-striped">
							<caption>
								User Personal Details
							</caption>
							<tr>
								<td class="col-xs-5 col-sm-6">Addres Line 1</td>
								<td>: {{$userinfo->street1}}</td>
							</tr>
							<tr>
								<td>Addres Line 2</td>
								<td>: {{$userinfo->street2}}</td>
							</tr>
							<tr>
								<td>City</td>
								<td>: {{$userinfo->city}}</td>
							</tr>
							<tr>
								<td>State</td>
								<td>: {{$userinfo->state}}</td>
							</tr>
							<tr>
								<td>Zip</td>
								<td>: {{$userinfo->zip}}</td>
							</tr>
							<tr>
								<td>Country</td>
								<td>: {{country($userinfo->country)}}</td>
							</tr>
							<tr>
								<td>Sex</td>
								<td>: {{gender($userinfo->sex)}}</td>
							</tr>
							<tr>
								<td>Contact No.</td>
								<td>: <a href="tel:{{$userinfo->contact}}">{{$userinfo->contact}}</a></td>
							</tr>
							<tr>
								<td>Description</td>
								<td>: {{$userinfo->description}}</td>
							</tr>
							<tr>
								<td>Date Of Birth</td>
								<td>:
									@if($userinfo->dob)
										{{ getDateFormat($userinfo->dob,'d M, Y') }}
									@else
									Not Defined
									@endif
								</td>
							</tr>
							<tr>
								<td>Joining Date</td>
								<td>: {{ getDateFormat($userinfo->created_at)}}</td>
							</tr>
							<tr>
								<td>Last Update</td>
								<td>: {{ getDateFormat($userinfo->updated_at) }}</td>
							</tr>
						</table>
            		</div>
            		@endif
            	</div>
				
            </div><!-- /.box-body -->
			<div class="box-footer clearfix">
				@if($logged_role > $user->role || $logged_id == $user->id)
				<a href="{{ route('edituserinfo', ['id'=>$user->id]) }}" class="btn btn-primary btn-flat pull-right">Edit This User</a>
				@endif
			</div>
        </div><!-- /.box -->
	</div>
	@else
	<div class="col-md-12">
		<div class="box">
			<div class="box-body">
				<h4 class="text-center">
					No user found to view.
				</h4>
			</div>
		</div>
	</div>
	@endif
</div>

<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
    {{ Form::open(array('route'=>'uloadprofileimage', 'method'=>'post', 'files' => true)) }}
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Change Photo</h4>
      </div>
      <div class="modal-body">
        <div class="form-group">
		    <label for="profileimg">Upload Profile Image</label>
		    <input type="file" name="profileimg" id="profileimg">
		    <p class="help-block">Current profile image will be deleted automatically.</p>
		 </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" name="imageupload" value="Upload">
      </div>
      {{ Form::close() }}
    </div>
  </div>
</div>
@endsection

@section('jscode')