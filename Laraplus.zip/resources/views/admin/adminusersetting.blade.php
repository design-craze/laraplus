@extends('admin.master.master')

@section('title', 'User Setting')

@section('headcode')
	{{ Html::style('assets/admin/css/menu.css') }}
	{{ Html::style('assets/admin/vendor/select2/select2.min.css') }}
@endsection

@section('breadcambs', '<i class="fa fa-dashboard"></i> User Setting')

@section('bodycode')
<div class="row">
	<div class="col-md-6">
        <div class="panel-body page-editor">
        	{{ Form::open(array('route'=>'changepasswordprocess', 'method'=>'post')) }}
			<div class="form-group">
				<label for="old_pass">Enter Old Password</label>
				<input type="password" name="old_pass" class="form-control" id="old_pass" placeholder="Enter Your Old Password">
			</div>
			<div class="form-group">
				<label for="new_pass">Enter New Password</label>
				<input type="password" name="new_pass" class="form-control" id="new_pass" placeholder="Password">
			</div>
			<div class="form-group">
				<label for="new_pass_con">Confirm Password</label>
				<input type="password" name="new_pass_confirmation" class="form-control" id="new_pass_con" placeholder="Confirm New Password">
			</div>
			<div class="form-group">
				<input type="submit" name="change_pass" class="btn btn-primary" value="Change Password">
			</div>
			{{ Form::close() }}
        </div>
    </div>
</div>
@endsection

@section('jscode')
	{{ Html::script('assets/admin/vendor/select2/select2.full.min.js') }}
	{{ Html::script('assets/admin/js/jquery.mjs.nestedSortable.js') }}
	{{ Html::script('assets/admin/js/adminmenuhandler.js') }}

	<script>
		$(function () {
	        //Initialize Select2 Elements
	        $(".select2").select2();
	    })
	</script>
@endsection