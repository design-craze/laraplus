@extends('admin.master.master')


@section('title', 'General Setting')


@section('headcode')
    {{ Html::style('assets/admin/vendor/select2/select2.min.css') }}
@endsection

@section('breadcambs', '<i class="fa fa-dashboard"></i> General Setting')


@section('bodycode')
	<?php 
		$settingitem = [];

		foreach($data as $v)
		{
			$settingitem[$v->slug] = $v->value;
		}
	?>
	@if(Session::has('remove'))
        <div class="alert alert-success alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            {{Session::get('remove')}}
        </div>
    @endif
    @if(Session::has('removeerror'))
        <div class="alert alert-success alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            {{Session::get('removeerror')}}
        </div>
    @endif

	{{ Form::open(array('route'=>'settingprocess', 'method'=>'post', 'files' => true)) }}
	<div class="row">
	    <div class="col-md-8 col-md-offset-2">
	    	<input type="submit" class="btn btn-primary btn-flat" value="Save Settings">
	    	<div class="setting-title panel-title">GENERAL SETTING</div>
	      	<!-- Custom Tabs -->
	      	<div class="nav-tabs-custom dc-nav-tab">
		        <ul class="nav nav-tabs">
					<li class="active"><a href="#tab_1" data-toggle="tab">Primary Setting</a></li>
					<li><a href="#tab_2" data-toggle="tab">Web Structure</a></li>
					<li><a href="#tab_3" data-toggle="tab">Page Setting</a></li>
					<li><a href="#tab_4" data-toggle="tab">Blog Setting</a></li>
					<li><a href="#tab_5" data-toggle="tab">Page Link Setting</a></li>
					<li><a href="#tab_6" data-toggle="tab">Social Media</a></li>
					<li><a href="#tab_7" data-toggle="tab">Contact Setting</a></li>
					<li><a href="#tab_8" data-toggle="tab">Style Setting</a></li>
					<li><a href="#tab_9" data-toggle="tab">SEO Setting</a></li>
					<li><a href="#tab_10" data-toggle="tab">Responsive</a></li>
					<li><a href="#tab_11" data-toggle="tab">Menu</a></li>
		        </ul>
		        <div class="tab-content">
					<div class="tab-pane active" id="tab_1">
						@if(array_key_exists('site_name',$settingitem))
							<div class="panel-title">Site Name</div>
							<input type="text" class="form-control" name="site_name" value="<?php if(old('site_name')!=null){ echo old('site_name');} else{echo $settingitem['site_name'];} ?>">
						@endif
						@if(array_key_exists('logo_img',$settingitem))
							<div class="panel-title">Logo Image</div>
							@if($settingitem['logo_img']!='' && $settingitem['logo_img']!=null)
							<figure>
								<img src="{{ asset(path_logo().$settingitem['logo_img']) }}" alt="{{$settingitem['logo_img']}}" style="max-width: 80px;">
								<figcaption><a class="text-danger small confirmation" data-alert="Do You Want To Delete Logo Image?" data-toggle="tooltip" title="Delete Logo Image" href="{{ route('removlogoimage',['imgval'=>$settingitem['logo_img']]) }}">Remove</a></figcaption>
							</figure>
							@else
							<input type="file" name="logo_img">
							@endif
						@endif
						@if(array_key_exists('logo_type',$settingitem))
							<div class="panel-title">Logo Type</div>
							<select name="logo_type" class="form-control">
								<option value="1" {{ isset($settingitem['logo_type']) && $settingitem['logo_type']==1 ? 'selected' : '' }}>Site Name</option>			
								<option value="2" {{ isset($settingitem['logo_type']) && $settingitem['logo_type']==2 ? 'selected' : '' }}>Logo Image</option>			
							</select>
						@endif
						@if(array_key_exists('favicon',$settingitem))
							<div class="panel-title">Favicon</div>
							
							@if($settingitem['favicon']!='' && $settingitem['favicon']!=null)
							<figure>
								<img src="{{asset(path_favicon().$settingitem['favicon'])}}" alt="{{ $settingitem['favicon'] }}">
								<figcaption><a class="text-danger small confirmation" data-alert="Do You Want To Delete Favicon Image?" data-toggle="tooltip" title="Delete Favicon Image" href="{{ route('removfavimage',['imgval'=>$settingitem['favicon']]) }}">Remove</a></figcaption>
							</figure>
							@else
							<input type="file" name="favicon">
							@endif
						@endif
						@if(array_key_exists('primary_phone',$settingitem))
							<div class="panel-title">Primary Phone</div>
							<input type="text" class="form-control" name="primary_phone" value="<?php if(old('primary_phone')!=null){ echo old('primary_phone');} else{echo $settingitem['primary_phone'];} ?>">
						@endif
						@if(array_key_exists('primary_email',$settingitem))
							<div class="panel-title">Primary Email</div>
							<input type="text" class="form-control" name="primary_email" value="<?php if(old('primary_email')!=null){ echo old('primary_email');} else{echo $settingitem['primary_email'];} ?>">
						@endif
						@if(array_key_exists('signable',$settingitem))
							<div class="panel-title">Signable User</div>
							<select multiple class="form-control select2" name="signable[]" data-placeholder="Select categories" style="width: 100%;">
								<?php $signable = explode(',', $settingitem['signable']); ?>
								@for($i=1; $i<=6; $i++)
	                            	<option value="{{$i}}"<?php if(old('signable')!=null && old('signable') == $i){ echo ' selected';}elseif(old('signable')=='' && in_array($i, $signable)){echo ' selected';} ?>>{{roleaccess($i)}}</option>	
	                            @endfor
	                        </select>
						@endif
						@if(array_key_exists('web_status',$settingitem))
							<div class="panel-title">Website Status</div>
							<select name="web_status" class="form-control">
								<option value="1">Live</option>
								<option value="2"<?php if(old('web_status')=='2'){ echo ' selected';} elseif($settingitem['web_status']=='2'){ echo ' selected';}?>>Coming Soon</option>
								<option value="3"<?php if(old('web_status')=='3'){ echo ' selected';} elseif($settingitem['web_status']=='3'){ echo ' selected';}?>>Under Development</option>
							</select>
						@endif
					</div>
					<div class="tab-pane" id="tab_2">
						@if(array_key_exists('page_header',$settingitem))
							<div class="panel-title">Site Header</div>
							<select name="page_header" class="form-control">
								<option value="1">Show</option>
								<option value="0"<?php if(old('page_header')=='0'){ echo ' selected';} elseif($settingitem['page_header']=='0'){ echo ' selected';}?>>Hide</option>
							</select>
						@endif						
						@if(array_key_exists('header_layout',$settingitem))
							<div class="panel-title">Header Layout</div>
							<select name="header_layout" class="form-control">
								<option value="2">Boxed</option>
								<option value="1"<?php if(old('header_layout')=='1'){ echo ' selected';} elseif($settingitem['header_layout']=='1'){ echo ' selected';}?>>Full Width</option>
							</select>
						@endif
						@if(array_key_exists('page_title',$settingitem))
							<div class="panel-title">Main Titlebar</div>
							<select name="page_title" class="form-control">
								<option value="1">Show</option>
								<option value="0"<?php if(old('page_title')=='0'){ echo ' selected';} elseif($settingitem['page_title']=='0'){ echo ' selected';}?>>Hide</option>
							</select>
						@endif
						@if(array_key_exists('title_layout',$settingitem))
							<div class="panel-title">Titlebar Layout</div>
							<select name="title_layout" class="form-control">
								<option value="2">Boxed</option>
								<option value="1"<?php if(old('title_layout')=='1'){ echo ' selected';} elseif($settingitem['title_layout']=='1'){ echo ' selected';}?>>Full Width</option>
							</select>
						@endif
						@if(array_key_exists('breadcrumbs',$settingitem))
							<div class="panel-title">Breadcrumbs</div>
							<select name="breadcrumbs" class="form-control">
								<option value="2">Show</option>
								<option value="1"<?php if(old('breadcrumbs')=='1'){ echo ' selected';} elseif($settingitem['breadcrumbs']=='1'){ echo ' selected';}?>>Hide</option>
							</select>
						@endif
						@if(array_key_exists('brdcrmb_sep',$settingitem))
							<div class="panel-title">Breadcrumb Seperator</div>
							<input type="text" class="form-control" name="brdcrmb_sep" value="<?php if(old('brdcrmb_sep')!=null){ echo old('brdcrmb_sep');} else{echo $settingitem['brdcrmb_sep'];} ?>">
						@endif
						@if(array_key_exists('body_layout',$settingitem))
							<div class="panel-title">Body Type</div>
							<select name="body_layout" class="form-control">
								<option value="2">Centered</option>
								<option value="1"<?php if(old('body_layout')=='1'){ echo ' selected';} elseif($settingitem['body_layout']=='1'){ echo ' selected';}?>>100%</option>
							</select>
						@endif
						@if(array_key_exists('footer_layout',$settingitem))
							<div class="panel-title">Footer Layout</div>
							<select name="footer_layout" class="form-control">
								<option value="2">Boxed</option>
								<option value="1"<?php if(old('footer_layout')=='1'){ echo ' selected';} elseif($settingitem['footer_layout']=='1'){ echo ' selected';}?>>Full Width</option>
							</select>
						@endif
						@if(array_key_exists('footer',$settingitem))
							<div class="panel-title">Show Widget Footer</div>
							<select name="footer" class="form-control">
								<option value="0">0</option>
								<option value="1"<?php if(old('footer')=='1'){ echo ' selected';} elseif($settingitem['footer']=='1'){ echo ' selected';}?>>1</option>
								<option value="2"<?php if(old('footer')=='2'){ echo ' selected';} elseif($settingitem['footer']=='2'){ echo ' selected';}?>>2</option>
								<option value="3"<?php if(old('footer')=='3'){ echo ' selected';} elseif($settingitem['footer']=='3'){ echo ' selected';}?>>3</option>
								<option value="4"<?php if(old('footer')=='4'){ echo ' selected';} elseif($settingitem['footer']=='4'){ echo ' selected';}?>>4</option>
							</select>
						@endif
						@if(array_key_exists('bottom_footer',$settingitem))
							<div class="panel-title">Copyright Footer</div>
							<select name="bottom_footer" class="form-control">
								<option value="1">Show</option>
								<option value="0"<?php if(old('bottom_footer')=='0'){ echo ' selected';} elseif($settingitem['bottom_footer']=='0'){ echo ' selected';}?>>Hide</option>
							</select>
						@endif
						@if(array_key_exists('copyright_text',$settingitem))
							<div class="panel-title">Copyright Text</div>
							<textarea class="form-control" name="copyright_text"><?php if(old('copyright_text')!=null){ echo old('copyright_text');} else{echo $settingitem['copyright_text'];} ?></textarea>
						@endif
					</div>
					<div class="tab-pane" id="tab_3">
						@if(array_key_exists('page_leftsidebar',$settingitem))
							<div class="panel-title">Left Sidebar</div>
							<select name="page_leftsidebar" class="form-control">
								<option value="none">none</option>
								<?php
                                    $a =widget_area();
                                ?>
                                @foreach($a as $key => $val)
                                    <option value="{{$key}}"<?php if(old('page_leftsidebar')==$key){ echo ' selected';} elseif($settingitem['page_leftsidebar']==$key){ echo ' selected';}?>>{{$val}}</option>
                                @endforeach
							</select>
						@endif
						@if(array_key_exists('page_rightsidebar',$settingitem))
							<div class="panel-title">Right Sidebar</div>
							<select name="page_rightsidebar" class="form-control">
								<option value="none">none</option>
								<?php
                                    $a =widget_area();
                                ?>
                                @foreach($a as $key => $val)
                                    <option value="{{$key}}"<?php if(old('page_rightsidebar')==$key){ echo ' selected';} elseif($settingitem['page_rightsidebar']==$key){ echo ' selected';}?>>{{$val}}</option>
                                @endforeach
							</select>
						@endif
						@if(array_key_exists('page_layout',$settingitem))
							<div class="panel-title">Page Layout</div>
							<select name="page_layout" class="form-control">
								<option value="1">Boxed</option>
								<option value="0"<?php if(old('page_layout')=='0'){ echo ' selected';} elseif($settingitem['page_layout']=='0'){ echo ' selected';}?>>Full Width</option>
							</select>
						@endif
					</div>
					<div class="tab-pane" id="tab_4">
						
							@if(array_key_exists('blog_leftsidebar',$settingitem))
								<div class="panel-title">Left Sidebar</div>
								<select name="blog_leftsidebar" class="form-control">
									<option value="none">none</option>
									<?php
                                        $a =widget_area();
                                    ?>
                                    @foreach($a as $key => $val)
                                        <option value="{{$key}}"<?php if(old('blog_leftsidebar')==$key){ echo ' selected';} elseif($settingitem['blog_leftsidebar']==$key){ echo ' selected';}?>>{{$val}}</option>
                                    @endforeach
								</select>
							@endif
							@if(array_key_exists('blog_rightsidebar',$settingitem))
								<div class="panel-title">Right Sidebar</div>
								<select name="blog_rightsidebar" class="form-control">
									<option value="none">none</option>
									<?php
                                        $a =widget_area();
                                    ?>
                                    @foreach($a as $key => $val)
                                        <option value="{{$key}}"<?php if(old('blog_rightsidebar')==$key){ echo ' selected';} elseif($settingitem['blog_rightsidebar']==$key){ echo ' selected';}?>>{{$val}}</option>
                                    @endforeach
								</select>
							@endif
							@if(array_key_exists('blog_layout',$settingitem))
								<div class="panel-title">Blog Layout</div>
								<select name="blog_layout" class="form-control">
									<option value="1">Boxed</option>
									<option value="0"<?php if(old('blog_layout')=='0'){ echo ' selected';} elseif($settingitem['blog_layout']=='0'){ echo ' selected';}?>>Full Width</option>
								</select>
							@endif
					</div>
					<div class="tab-pane" id="tab_5">
						@if(array_key_exists('login_page',$settingitem))
							<div class="panel-title">Login Page</div>
							<select name="login_page" class="form-control">
								<option value="0">None</option>
								@foreach($pages as $page)
									<option value="{{$page->id}}"<?php if(old('login_page')==$page->id){ echo ' selected';} elseif($settingitem['login_page']==$page->id){ echo ' selected';}?>>{{$page->name}}</option>
								@endforeach
							</select>
						@endif
						@if(array_key_exists('signup_page',$settingitem))
							<div class="panel-title">Signup Page</div>
							<select name="signup_page" class="form-control">
								<option value="0">None</option>
								@foreach($pages as $page)
									<option value="{{$page->id}}"<?php if(old('signup_page')==$page->id){ echo ' selected';} elseif($settingitem['signup_page']==$page->id){ echo ' selected';}?>>{{$page->name}}</option>
								@endforeach
							</select>
						@endif
						@if(array_key_exists('identify_page',$settingitem))
							<div class="panel-title">Identify Page</div>
							<select name="identify_page" class="form-control">
								<option value="0">None</option>
								@foreach($pages as $page)
									<option value="{{$page->id}}"<?php if(old('identify_page')==$page->id){ echo ' selected';} elseif($settingitem['identify_page']==$page->id){ echo ' selected';}?>>{{$page->name}}</option>
								@endforeach
							</select>
						@endif
						@if(array_key_exists('coming_soon',$settingitem))
							<div class="panel-title">Coming Soon Page</div>
							<select name="coming_soon" class="form-control">
								<option value="0">None</option>
								@foreach($pages as $page)
									<option value="{{$page->id}}"<?php if(old('coming_soon')==$page->id){ echo ' selected';} elseif($settingitem['coming_soon']==$page->id){ echo ' selected';}?>>{{$page->name}}</option>
								@endforeach
							</select>
						@endif
						@if(array_key_exists('under_dev',$settingitem))
							<div class="panel-title">Under Construction Page</div>
							<select name="under_dev" class="form-control">
								<option value="0">None</option>
								@foreach($pages as $page)
									<option value="{{$page->id}}"<?php if(old('under_dev')==$page->id){ echo ' selected';} elseif($settingitem['under_dev']==$page->id){ echo ' selected';}?>>{{$page->name}}</option>
								@endforeach
							</select>
						@endif
						@if(array_key_exists('search_page',$settingitem))
							<div class="panel-title">Search Page</div>
							<select name="search_page" class="form-control">
								<option value="0">None</option>
								@foreach($pages as $page)
									<option value="{{$page->id}}"<?php if(old('search_page')==$page->id){ echo ' selected';} elseif($settingitem['search_page']==$page->id){ echo ' selected';}?>>{{$page->name}}</option>
								@endforeach
							</select>
						@endif
						@if(array_key_exists('blogctg_page',$settingitem))
							<div class="panel-title">Blog Category Page</div>
							<select name="blogctg_page" class="form-control">
								<option value="0">None</option>
								@foreach($pages as $page)
									<option value="{{$page->id}}"<?php if(old('blogctg_page')==$page->id){ echo ' selected';} elseif($settingitem['blogctg_page']==$page->id){ echo ' selected';}?>>{{$page->name}}</option>
								@endforeach
							</select>
						@endif
					</div>
					<div class="tab-pane" id="tab_6">
							@if(array_key_exists('facebook',$settingitem))
								<div class="panel-title">Facebook</div>
								<input type="text" class="form-control" name="facebook" value="<?php if(old('facebook')!=null){ echo old('facebook');} else{echo $settingitem['facebook'];} ?>">
							@endif
							@if(array_key_exists('twitter',$settingitem))
								<div class="panel-title">Twitter</div>
								<input type="text" class="form-control" name="twitter" value="<?php if(old('twitter')!=null){ echo old('twitter');} else{echo $settingitem['twitter'];} ?>">
							@endif
							@if(array_key_exists('linkedin',$settingitem))
								<div class="panel-title">LinkedIn</div>
								<input type="text" class="form-control" name="linkedin" value="<?php if(old('linkedin')!=null){ echo old('linkedin');} else{echo $settingitem['linkedin'];} ?>">
							@endif
							@if(array_key_exists('google',$settingitem))
								<div class="panel-title">Google+</div>
								<input type="text" class="form-control" name="google" value="<?php if(old('google')!=null){ echo old('google');} else{echo $settingitem['google'];} ?>">
							@endif
							@if(array_key_exists('skype',$settingitem))
								<div class="panel-title">Skype</div>
								<input type="text" class="form-control" name="skype" value="<?php if(old('skype')!=null){ echo old('skype');} else{echo $settingitem['skype'];} ?>">
							@endif
							@if(array_key_exists('youtube',$settingitem))
								<div class="panel-title">You Tube</div>
								<input type="text" class="form-control" name="youtube" value="<?php if(old('youtube')!=null){ echo old('youtube');} else{echo $settingitem['youtube'];} ?>">
							@endif
							@if(array_key_exists('vimeo',$settingitem))
								<div class="panel-title">Vimeo</div>
								<input type="text" class="form-control" name="vimeo" value="<?php if(old('vimeo')!=null){ echo old('vimeo');} else{echo $settingitem['vimeo'];} ?>">
							@endif
							@if(array_key_exists('pinterest',$settingitem))
								<div class="panel-title">Pinterset</div>
								<input type="text" class="form-control" name="pinterest" value="<?php if(old('pinterest')!=null){ echo old('pinterest');} else{echo $settingitem['pinterest'];} ?>">
							@endif
							@if(array_key_exists('flickr',$settingitem))
								<div class="panel-title">Flickr</div>
								<input type="text" class="form-control" name="flickr" value="<?php if(old('flickr')!=null){ echo old('flickr');} else{echo $settingitem['flickr'];} ?>">
							@endif
							@if(array_key_exists('instagram',$settingitem))
								<div class="panel-title">Instagram</div>
								<input type="text" class="form-control" name="instagram" value="<?php if(old('instagram')!=null){ echo old('instagram');} else{echo $settingitem['instagram'];} ?>">
							@endif
							@if(array_key_exists('rss',$settingitem))
								<div class="panel-title">RSS</div>
								<input type="text" class="form-control" name="rss" value="<?php if(old('rss')!=null){ echo old('rss');} else{echo $settingitem['rss'];} ?>">
							@endif
					</div>
					<div class="tab-pane" id="tab_7">
							@if(array_key_exists('contact_email',$settingitem))
								<div class="panel-title">Contact Email</div>
								<input type="text" class="form-control" name="contact_email" value="<?php if(old('contact_email')!=null){ echo old('contact_email');} else{echo $settingitem['contact_email'];} ?>">
							@endif
							@if(array_key_exists('contact_phone',$settingitem))
								<div class="panel-title">Contact Phone</div>
								<input type="text" class="form-control" name="contact_phone" value="<?php if(old('contact_phone')!=null){ echo old('contact_phone');} else{echo $settingitem['contact_phone'];} ?>">
							@endif
							@if(array_key_exists('contact_company',$settingitem))
								<div class="panel-title">Company Name</div>
								<input type="text" class="form-control" name="contact_company" value="<?php if(old('contact_company')!=null){ echo old('contact_company');} else{echo $settingitem['contact_company'];} ?>">
							@endif
							@if(array_key_exists('contact_address',$settingitem))
								<div class="panel-title">Contact Address</div>
								<input type="text" class="form-control" name="contact_address" value="<?php if(old('contact_address')!=null){ echo old('contact_address');} else{echo $settingitem['contact_address'];} ?>">
							@endif
							@if(array_key_exists('contact_map',$settingitem))
								<div class="panel-title">Google Map Show</div>
								<select name="contact_map" class="form-control">
								<option value="1"<?php if(old('contact_map')!=null && old('contact_map')==1){ echo " selected";} elseif($settingitem['contact_map']==1){echo " selected";} ?>>Yes</option>
								<option value="2" <?php if(old('contact_map')!=null && old('contact_map')==2){ echo " selected";} elseif($settingitem['contact_map']==2){echo " selected";} ?>>No</option>
							</select>
							@endif
							@if(array_key_exists('contact_latlong',$settingitem))
								<div class="panel-title">Google Latitude Longitude <span style="color:#aaa;">(seperate by comma ",")</span></div>
								<input type="text" class="form-control" name="contact_latlong" value="<?php if(old('contact_latlong')!=null){ echo old('contact_latlong');} else{echo $settingitem['contact_latlong'];} ?>">
							@endif
							@if(array_key_exists('contact_map_show_by',$settingitem))
								<div class="panel-title">Google Map Show By</div>
								<select name="contact_map_show_by" class="form-control">
								<option value="1"<?php if(old('contact_map_show_by')!=null && old('contact_map_show_by')==1){ echo " selected";} elseif($settingitem['contact_map_show_by']==1){echo " selected";} ?>>Latitude & Longitude</option>
								<option value="2" <?php if(old('contact_map_show_by')!=null && old('contact_map_show_by')==2){ echo " selected";} elseif($settingitem['contact_map_show_by']==2){echo " selected";} ?>>Contact Address</option>
							</select>
							@endif

							@if(array_key_exists('google_map_zoom',$settingitem))
								<div class="panel-title">Google Map Zoom Level</div>
								<select name="google_map_zoom" class="form-control">
								@for($i=1; $i <= 23; $i++)
									<option value="{{$i}}"<?php if(old('google_map_zoom')!=null && old('google_map_zoom')==1){ echo " selected";} elseif($settingitem['google_map_zoom']==$i){echo " selected";} ?>>{{$i}}</option>
								@endfor
								</select>
							@endif

							@if(array_key_exists('google_map_type',$settingitem))
								<div class="panel-title">Google Map Type</div>
								<select name="google_map_type" class="form-control">
									@foreach(google_map_type() as $val=>$type)
									<option value="{{$val}}"<?php if(old('google_map_type')!=null && old('google_map_type')==$val){ echo " selected";} elseif($settingitem['google_map_type']==$val){echo " selected";} ?>>{{$type}}</option>
									@endforeach
								</select>
							@endif

							@if(array_key_exists('google_map_marker_show',$settingitem))
								<div class="panel-title">Google Map Marker Show</div>
								<select name="google_map_marker_show" class="form-control">
									<option value="1"<?php if(old('google_map_marker_show')!=null && old('google_map_marker_show')==1){ echo " selected";} elseif($settingitem['google_map_marker_show']==1){echo " selected";} ?>>Yes</option>
									<option value="2" <?php if(old('google_map_marker_show')!=null && old('google_map_marker_show')==2){ echo " selected";} elseif($settingitem['google_map_marker_show']==2){echo " selected";} ?>>No</option>
								</select>
							@endif
							@if(array_key_exists('google_mark_icon',$settingitem))
								<div class="panel-title">Google Marker (url here)</div>
								<input type="text" name="google_mark_icon" class="form-control"  value="<?php if(old('google_mark_icon')!=null){ echo old('google_mark_icon');} else{echo $settingitem['google_mark_icon'];} ?>">
							@endif
					</div>
					<div class="tab-pane" id="tab_8">
						@if(array_key_exists('custom_css',$settingitem))
							<div class="panel-title">Custom Style</div>
							<textarea name="custom_css" style="heigh: auto !important; width: 100%; border: 1px solid #D2D6DE; padding: 10px" cols="30" rows="10" placeholder="CSS Gose here">{{ $settingitem['custom_css'] }}</textarea>
						@endif
						@if(array_key_exists('large_min_css',$settingitem))
							<div class="panel-title">Large Screen CSS (Min Width)</div>
							<textarea name="large_min_css" style="heigh: auto !important; width: 100%; border: 1px solid #D2D6DE; padding: 10px" cols="30" rows="10" placeholder="CSS Gose here">{{ $settingitem['large_min_css'] }}</textarea>
						@endif
						@if(array_key_exists('large_max_css',$settingitem))
							<div class="panel-title">Large Screen CSS (Max Width)</div>
							<textarea name="large_max_css" style="heigh: auto !important; width: 100%; border: 1px solid #D2D6DE; padding: 10px" cols="30" rows="10" placeholder="CSS Gose here">{{ $settingitem['large_max_css'] }}</textarea>
						@endif
						@if(array_key_exists('medium_min_css',$settingitem))
							<div class="panel-title">Medium Screen CSS (Min Width)</div>
							<textarea name="medium_min_css" style="heigh: auto !important; width: 100%; border: 1px solid #D2D6DE; padding: 10px" cols="30" rows="10" placeholder="CSS Gose here">{{ $settingitem['medium_min_css'] }}</textarea>
						@endif
						@if(array_key_exists('medium_max_css',$settingitem))
							<div class="panel-title">Medium Screen CSS (Max Width)</div>
							<textarea name="medium_max_css" style="heigh: auto !important; width: 100%; border: 1px solid #D2D6DE; padding: 10px" cols="30" rows="10" placeholder="CSS Gose here">{{ $settingitem['medium_max_css'] }}</textarea>
						@endif
						@if(array_key_exists('small_min_css',$settingitem))
							<div class="panel-title">Small Screen CSS (Min Width)</div>
							<textarea name="small_min_css" style="heigh: auto !important; width: 100%; border: 1px solid #D2D6DE; padding: 10px" cols="30" rows="10" placeholder="CSS Gose here">{{ $settingitem['small_min_css'] }}</textarea>
						@endif
						@if(array_key_exists('small_max_css',$settingitem))
							<div class="panel-title">Small Screen CSS (Max Width)</div>
							<textarea name="small_max_css" style="heigh: auto !important; width: 100%; border: 1px solid #D2D6DE; padding: 10px" cols="30" rows="10" placeholder="CSS Gose here">{{ $settingitem['small_max_css'] }}</textarea>
						@endif
						@if(array_key_exists('user_css',$settingitem))
							<div class="panel-title">CSS for Logged In User</div>
							<textarea name="user_css" style="heigh: auto !important; width: 100%; border: 1px solid #D2D6DE; padding: 10px" cols="30" rows="10" placeholder="CSS Gose here">{{ $settingitem['user_css'] }}</textarea>
						@endif
						@if(array_key_exists('guest_css',$settingitem))
							<div class="panel-title">CSS for Guest User</div>
							<textarea name="guest_css" style="heigh: auto !important; width: 100%; border: 1px solid #D2D6DE; padding: 10px" cols="30" rows="10" placeholder="CSS Gose here">{{ $settingitem['guest_css'] }}</textarea>
						@endif
						@if(array_key_exists('custom_js',$settingitem))
							<div class="panel-title">Custom JS</div>
							<textarea name="custom_js" style="heigh: auto !important; width: 100%; border: 1px solid #D2D6DE; padding: 10px" cols="30" rows="10" placeholder="JS Script Gose here">{{$settingitem['custom_js']}}</textarea>
						@endif
					</div>
					<div class="tab-pane" id="tab_9">
						@if(array_key_exists('meta_title',$settingitem))
							<div class="panel-title">Meta Title</div>
							<input type="text" name="meta_title" class="form-control"  value="<?php if(old('meta_title')!=null){ echo old('meta_title');} else{echo $settingitem['meta_title'];} ?>">					
						@endif
						@if(array_key_exists('meta_tag',$settingitem))
							<div class="panel-title">Meta Keyword</div>
							<input type="text" name="meta_tag" class="form-control"  value="<?php if(old('meta_tag')!=null){ echo old('meta_tag');} else{echo $settingitem['meta_tag'];} ?>">					
						@endif
						@if(array_key_exists('meta_desc',$settingitem))
							<div class="panel-title">Meta Description</div>
							<textarea name="meta_desc" style="heigh: auto !important; width: 100%; border: 1px solid #D2D6DE; padding: 10px" cols="30" rows="5" placeholder="Meta Description Gose here">{{$settingitem['meta_desc']}}</textarea>
						@endif
						@if(array_key_exists('google_vf_code',$settingitem))
							<div class="panel-title">Google Verification Code</div>
							<input type="text" name="google_vf_code" class="form-control"  value="<?php if(old('google_vf_code')!=null){ echo old('google_vf_code');} else{echo $settingitem['google_vf_code'];} ?>">
						@endif
					</div>
					<div class="tab-pane" id="tab_10">
						@if(array_key_exists('large_breakpoint',$settingitem))
							<div class="panel-title">Large Breakpoint <span>(Default:1199. Must be minimum 3px more than medium screen breakpoint)</span></div>
							<input type="number" name="large_breakpoint" class="form-control"  value="<?php if(old('large_breakpoint')!=null){ echo old('large_breakpoint');} else{echo $settingitem['large_breakpoint'];} ?>">					
						@endif
						@if(array_key_exists('container_width_lg',$settingitem))
							<div class="panel-title">Container width For Large Screen <span>(Default:1170. Must be minimum 29px less than large screen Breakpoint and more than Medium screen container width)</span></div>
							<input type="number" name="container_width_lg" class="form-control"  value="<?php if(old('container_width_lg')!=null){ echo old('container_width_lg');} else{echo $settingitem['container_width_lg'];} ?>">					
						@endif
						@if(array_key_exists('medium_breakpoint',$settingitem))
							<div class="panel-title">Meidum Breakpoint <span>(Default:991. Must be minimum 3px more than small screen breakpoint)</span></div>
							<input type="number" name="medium_breakpoint" class="form-control"  value="<?php if(old('medium_breakpoint')!=null){ echo old('medium_breakpoint');} else{echo $settingitem['medium_breakpoint'];} ?>">					
						@endif
						@if(array_key_exists('container_width_md',$settingitem))
							<div class="panel-title">Container width for Medium Screen <span>(Default:962. Must be minimum 29px less than Medium screen Breakpoint and more than Small screen container width)</span></div>
							<input type="number" name="container_width_md" class="form-control"  value="<?php if(old('container_width_md')!=null){ echo old('container_width_md');} else{echo $settingitem['container_width_md'];} ?>">					
						@endif
						@if(array_key_exists('small_breakpoint',$settingitem))
							<div class="panel-title">small Breakpoint <span>(Default:767. Must be minimum 3px less than medium screen)</span></div>
							<input type="number" name="small_breakpoint" class="form-control"  value="<?php if(old('small_breakpoint')!=null){ echo old('small_breakpoint');} else{echo $settingitem['small_breakpoint'];} ?>">					
						@endif
						@if(array_key_exists('container_width_sm',$settingitem))
							<div class="panel-title">Container width for Small Screen <span>(Default:738. Must be minimum 29px less than Small Screen Breakpoint and less than Medium screen container width)</span></div>
							<input type="number" name="container_width_sm" class="form-control"  value="<?php if(old('container_width_sm')!=null){ echo old('container_width_sm');} else{echo $settingitem['container_width_sm'];} ?>">					
						@endif
						<p style="color:#777; margin-top:20px"><strong>N.B.</strong> This section is recommended to evaluate carefully. Any wrong data may cause design problem on frontend</p>
					</div>
					<div class="tab-pane" id="tab_11">
						@if(array_key_exists('mobile_breakpoint',$settingitem))
							<div class="panel-title">Mobile Menu Breakpoint<span>(Default:767)</span></div>
							<input type="number" name="mobile_breakpoint" class="form-control"  value="<?php if(old('mobile_breakpoint')!=null){ echo old('mobile_breakpoint');} else{echo $settingitem['mobile_breakpoint'];} ?>">					
						@endif												
						@if(array_key_exists('menu_type',$settingitem))
							<div class="panel-title">Mobile Menu Style</div>
							<select name="menu_type" class="form-control">
								<option value="classic">Classic</option>
								<option value="modern"<?php if(old('menu_type')=='modern'){ echo ' selected';} elseif($settingitem['menu_type']=='modern'){ echo ' selected';}?>>Modern</option>
							</select>
						@endif						
						@if(array_key_exists('classic_menutext',$settingitem))
							<div class="panel-title">Classic Menutext<span>(Only works in Classic menu)</span></div>
							<input type="text" name="classic_menutext" class="form-control"  value="<?php if(old('classic_menutext')!=null){ echo old('classic_menutext');} else{echo $settingitem['classic_menutext'];} ?>">					
						@endif										
						@if(array_key_exists('sticky_header',$settingitem))
							<div class="panel-title">Sticky Header</div>
							<select name="sticky_header" class="form-control">
								<option value="yes">Yes</option>
								<option value="no"<?php if(old('sticky_header')=='no'){ echo ' selected';} elseif($settingitem['sticky_header']=='no'){ echo ' selected';}?>>No</option>
							</select>
						@endif
						@if(array_key_exists('sticky_top',$settingitem))
							<div class="panel-title">sticky header distance from top<span>(default:300)</span></div>
							<input type="number" name="sticky_top" class="form-control"  value="<?php if(old('sticky_top')!=null){ echo old('sticky_top');} else{echo $settingitem['sticky_top'];} ?>">					
						@endif
					</div>
				</div>
	      	</div>
	      	<input type="submit" class="btn btn-primary btn-flat" value="Save Settings">
	    </div>
	</div>
    {{ Form::close() }}
@endsection


@section('jscode')
{{ Html::script('assets/admin/vendor/select2/select2.full.min.js') }}
<script>

	$(function () {
            //Initialize Select2 Elements
            $(".select2").select2();
        })
</script>
@endsection