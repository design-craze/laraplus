@extends('admin.master.master')

@section('title', 'Dashboard')

@section('headcode')
	{{ Html::style('assets/admin/css/menu.css') }}
	{{ Html::style('assets/admin/vendor/select2/select2.min.css') }}
	<style>
		.small-box .icon{
			font-size: 70px;
			padding-top:8px;
		}
		.small-box:hover .icon{
			font-size: 90px;
			padding-top:0px;
		}
	</style>
@endsection

@section('breadcambs', '<i class="fa fa-dashboard"></i> Dashboard')

@section('bodycode')
	<!-- Small boxes (Stat box) -->
      <div class="row">
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3>{{ $countblogs }}</h3>

              <p>Blogs</p>
            </div>
            <div class="icon">
              <i class="fa fa-book"></i>
            </div>
            <a target="_blank" href="{{ route('blogmanager') }}" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <h3>{{ $countpages }} <sup style="font-size: 20px">%</sup></h3>

              <p>Pages</p>
            </div>
            <div class="icon">
              <i class="fa fa-file-text"></i>
            </div>
            <a target="_blank" href="{{ route('pagemanager') }}" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3>{{ $countusers }}</h3>

              <p>Users</p>
            </div>
            <div class="icon">
              <i class="fa fa-users"></i>
            </div>
            <a target="_blank" href="{{ route('userlist') }}" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
              <h3>{{$countcomments}}</h3>

              <p>Comments</p>
            </div>
            <div class="icon">
              <i class="fa fa-comments"></i>
            </div>
            <a target="_blank" href="{{ route('managecomment') }}" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
      </div>
      <!-- /.row -->

	<div class="row">
		<div class="col-md-4 col-sm-6">
			<div class="box box-primary" style="padding: 0 10px 5px;">
              <div class="box-body">
              	<h4 class="clearfix" style="padding-bottom: 5px">
                  Recent Blogs
                  <a target="_blank" style="margin-top: -7px" class="btn btn-primary pull-right btn-sm" href="{{ route('blogmanager') }}">Blog Manager</a>
                </h4>
              	@foreach($blogs as $rp)
	              	<hr style="margin: 10px 0;">
              		<div class="box-comment">
		                <div class="comment-text">
	                      <h5 style="margin: 0;">
	                        	<a target="_blank" href="{{ route('editblog', ['id'=>$rp->id]) }}"> {{strip_tags($rp->name)}}</a>
	                        	<span class="text-muted pull-right small">{{ time_elapsed_string($rp->updated_at) }}</span>
	                      </h5><!-- /.username -->
		                  {{substr(strip_tags($rp->description), 0, 51)}}...
		                </div>
		                <!-- /.comment-text -->
	              	</div>
				@endforeach
              </div><!-- /.box-body -->
          </div>
		</div>

		<div class="col-md-4 col-sm-6">
			<div class="box box-primary" style="padding: 0 10px 5px;">
              <div class="box-body">
              	<h4 class="clearfix" style="padding-bottom: 5px">
                  Recent Pages
                  <a style="margin-top: -7px" class="btn btn-primary pull-right btn-sm" target="_blank" href="{{ route('pagemanager') }}">Page Manager</a>
                </h4>
              	@foreach($pages as $rp)
	              	<hr style="margin: 10px 0;">
              		<div class="box-comment">
		                <div class="comment-text">
	                      <h5 style="margin: 0;">
	                        	<a target="_blank" href="{{ route('editpage', ['id'=>$rp->id]) }}"> {{strip_tags($rp->name)}}</a>
	                        	<span class="text-muted pull-right small">{{ time_elapsed_string($rp->updated_at) }}</span>
	                      </h5><!-- /.username -->
		                  {{substr(strip_tags($rp->description), 0, 51)}}...
		                </div>
		                <!-- /.comment-text -->
	              	</div>
				@endforeach
              </div><!-- /.box-body -->
          </div>
		</div>

		<div class="col-md-4 col-sm-6">
			<div class="box box-primary" style="padding: 0 10px 5px;">
              <div class="box-body">
              	<h4 class="clearfix" style="padding-bottom: 5px">
					Recent Users
					<a target="_blank" style="margin-top: -7px" class="btn btn-primary pull-right btn-sm" href="{{ route('userlist') }}">User Manager</a>
                </h4>
                @if(isset($users) && !empty($users))
	              	@foreach($users as $rp)
		              	<hr style="margin: 5.5px 0;">
			                <div class="row">
								<div class="col-sm-2">
									@if(isset($rp->userinfo->avatar) && !empty($rp->userinfo->avatar))
									<img src="{{ asset(path_profile(). $rp->userinfo->avatar) }}" alt="{{ $rp->userinfo->avatar }}" class="img-responsive img-circle">
									@elseif(isset($rp->userinfo->sex) &&  $rp->userinfo->sex == 'f')
									<img src="{{ asset(path_profile().'female.jpg') }}" alt="female.jpg" class="img-responsive img-circle">
									@else
									<img src="{{ asset(path_profile().'male.jpg') }}" alt="male.jpg" class="img-responsive img-circle">
									@endif
								</div>
								<div class="col-sm-8">
									<h5 style="margin-top:0; margin-bottom:0px"><a target="_blank" href="{{ route('viewuserinfo',['id'=>$rp->id]) }}">Name: {{ $rp->fname }} {{ $rp->lname }}</a></h5>
									<h6 style="margin-top:5px">EMail: {{ $rp->email }}</h6>
								</div>
							</div>
					@endforeach
				@endif
              </div><!-- /.box-body -->
          </div>
		</div>
		
	</div>
@endsection

@section('jscode')
	{{ Html::script('assets/admin/vendor/select2/select2.full.min.js') }}
	{{ Html::script('assets/admin/js/jquery.mjs.nestedSortable.js') }}
	{{ Html::script('assets/admin/js/adminmenuhandler.js') }}

	<script>
		$(function () {
	        //Initialize Select2 Elements
	        $(".select2").select2();
	    })
	</script>
@endsection