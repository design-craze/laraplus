@extends('admin.master.master')

@section('title', 'Widget Manager')

@section('headcode')
	{{ Html::style('assets/admin/css/menu.css') }}
	<style type="text/css">
		.widget-menu > li {
			line-height: 2.4;
			margin-bottom: 8px;
		}
		.box-body.widget-place {
			padding-bottom: 20px;
			padding-top: 0;
		}
		.innermenuhead, .innermenubody{
			width: 360px;
			max-width: 100% !important;
		}
		textarea.widget-freetext {
			height: 150px !important;
			width: 100% !important;
		}
		.innermenuhead{
			overflow: visible;
		}
		.mymenu .btn.dropdown-toggle {
			background: #ffffff none repeat scroll 0 0;
			border: 1px solid #dddddd;
			border-radius: 0;
			line-height: 14px;
			margin-left: 10px;
			padding: 4px 8px;
		}
		.panel.box.box-primary.zero-border {
			border-top: 1px solid #F2F2F2;
		}
		.box-header.with-border.no-border {
			border-bottom: navy;
		}
		.customhide{
			display: none;
		}
		.widgetli {
			background: #fff;
			margin-top: 9px;
		}
		.innermenu {
			margin-top: 0;
		}
	</style>
@endsection

@section('breadcambs', '<i class="fa fa-dashboard"></i> Widget Manager')

@section('bodycode')
	<div class="row">
		<div class="col-md-4">
			<div class="box box-primary">
	            <div class="box-header with-border">
	            	<h3 class="box-title">Widgets</h3>
	            </div><!-- /.box-header -->
				<div class="box-body">
					<ul class="list-unstyled widget-menu clearfix">
						@foreach(widget() as $widkey => $widget)
							<li class="clearfix">
								<div class="pull-left">{{$widget[1]}}</div>

								<div class="pull-right btn-group dc-widget-button">
									<button type="button" class="btn dropdown-toggle" data-toggle="dropdown">
										<span class="caret"></span>
										<span class="sr-only">Toggle Dropdown</span>
									</button>
									<ul class="dropdown-menu" role="menu">
										@foreach(widget_area() as $key => $val )
										@if($widget[0]=='menu')
											<li><a class="insert-widget" href="#" data-allsec="<?php $mystart=true; foreach(widget_area() as $key2 => $val2){if($mystart==true){echo $key2.','.$val2; $mystart=false;}else{echo ','.$key2.','.$val2;}} ?>" data-widslug="{{$widkey}}" data-widgetname="{{$widget[1]}}" data-widgetarea="{{$key}}" data-widgettype="{{$widget[0]}}" data-menus="<?php $mystart=true; foreach($menu as $val2){if($mystart==true){echo $val2->id.','.$val2->name; $mystart=false;}else{echo ','.$val2->id.','.$val2->name;}} ?>">{{$val}}</a></li>
										@else
											<li><a class="insert-widget" href="#" data-allsec="<?php $mystart=true; foreach(widget_area() as $key2 => $val2){if($mystart==true){echo $key2.','.$val2; $mystart=false;}else{echo ','.$key2.','.$val2;}} ?>" data-widslug="{{$widkey}}" data-widgetname="{{$widget[1]}}" data-widgetarea="{{$key}}" data-widgettype="{{$widget[0]}}">{{$val}}</a></li>
										@endif
										@endforeach
									</ul>
								</div>
							</li>
						@endforeach
					</ul>
				</div><!-- /.box-body -->
				<div class="box-body">
					{{ Form::open(array('route'=>'widgetsave', 'method'=>'post', 'role' => 'form')) }}
						<input type="hidden" id="inputid" name="inputid">
						<input type="hidden" id="inputslug"  name="inputslug">
						<input type="hidden" id="inputwidslug"  name="inputwidslug">
						<input type="hidden" id="inputtype"  name="inputtype">
						<input type="hidden" id="inputname"  name="inputname">
						<input type="hidden" id="inputcontent"  name="inputcontent">
						<input type="hidden" id="inputserial"  name="inputserial">
						<input type="hidden" id="inputdisabled"  name="inputdisabled">
						<input type="hidden" id="inputdelete"  name="inputdelete">
						<input type="submit" value="Save Widgets" name="savewid" class="btn btn-primary">
					{{ Form::close() }}
				</div>
	        </div>
		</div>
		<div class="col-md-8">
			<div class="row">
				@foreach(widget_area() as $key => $val )
					<div class="col-sm-6">
						<div class="box-body widget-place">
			              <div class="box-group" id="accordion-{{$key}}">
			                <!-- we are adding the .panel class so bootstrap.js collapse plugin detects it -->
			                <div class="panel box box-primary">
			                  <div class="box-header with-border">
			                    <h4 class="box-title">
			                      <a data-toggle="collapse" data-parent="#accordion-{{$key}}" href="#{{$key}}">
			                        {{$val}}
			                      </a>
			                    </h4>
			                  </div>
			                  <div id="{{$key}}" class="panel-collapse collapse in">
			                    <div class="box-body">
			                      <ol id="mywid-{{$key}}" class="mymenu" data-section="{{$key}}">
			                      	@if($data)	
			                      		@foreach($data as $field)
			                      			@if($field->slug == $key && $field->disabled ==0)		                      	
							                  <li class="widgetli" data-id="{{$field->id}}" data-slug="{{$field->slug}}" data-widgetslug="{{$field->widget_slug}}" data-type="{{$field->type}}" data-serial="{{$field->serial}}" data-disabled="0">
							                  	<div class="innermenu">
							                  		<div class="innermenuhead">
							                  			<div class="title">
							                  				{{widget($field->widget_slug)[1]}}
						                  				</div>
						                  				<div class="btn-group dc-widget-button">
															<button type="button" class="btn dropdown-toggle" data-toggle="dropdown">
																<span class="caret"></span>
																<span class="sr-only">Toggle Dropdown</span>
															</button>
															<ul class="dropdown-menu" role="menu">
																@foreach(widget_area() as $keychange => $valchange )
																@if($keychange != $key)
																<li><a class="changewidget" href="#" data-widgetarea="{{$keychange}}">{{$valchange}}</a></li>
																@else
																<li class="customhide"><a class="changewidget" href="#" data-widgetarea="{{$keychange}}">{{$valchange}}</a></li>
																@endif
																@endforeach
																<li><a class="changewidget" href="#" data-widgetarea="disabled">Disable Widget</a></li>
															</ul>
														</div>
							                  			<div class="type">
							                  				<span class="arrow-icon">Widget <i class="fa fa-caret-right"></i></span>
						                  				</div>
					                  				</div>
					              					<div class="innermenubody" style="display: none;">
					              						<p><label>Widget Name<br></label><input type="text" value="{{$field->name}}" class="name widget-name"></p>
					              						@if($field->type == widget_type(0))
					              							<p>
						              							<label>Show Data<br></label>
						              							<select class="form-control widget-content widget-dropdown">
						              								@for($i=1; $i<=15; $i++)
						              									<option value="{{$i}}"<?php if($field->content==$i){echo ' selected';}?>>{{$i}}</option>
						              								@endfor
						              							</select>
					              							</p>
					              						@elseif($field->type == widget_type(1))
					              							<p>
						              							<label>Content<br></label>
						              							<textarea class="form-control widget-freetext widget-content">{{$field->content}}</textarea>
					              							</p>
														@elseif($field->type == widget_type(2))
															<p>
						              							<label>Show Menu<br></label>
						              							<select class="form-control widget-content widget-dropdown">
						              								@foreach($menu as $valmenu)
						              									<option value="{{$valmenu->id}}"<?php if($field->content==$valmenu->id){echo ' selected';}?>>{{$valmenu->name}}</option>
						              								@endforeach
						              							</select>
					              							</p>					              						
														@elseif($field->type == widget_type(3) || $field->type == widget_type(4) || $field->type == widget_type(5))
															<input type="hidden" value="{{$field->content}}" class="widget-content">
					              						@endif
					              						<hr class="myhrborder">
					              						<button class="deletebutton">Remove</button>
					          						</div>
					      						</div>
							                  </li>
							                @endif
				                		@endforeach
			                		@endif
			                      </ol>
			                    </div>
			                  </div>
			                </div>
			              </div>
						</div><!-- /.box-body -->
					</div>
				@endforeach
			</div>
		</div>
    </div>
    <div class="row" style="margin-bottom: 100px">
    	<div class="col-sm-12">
    		<div class="box-body widget-place">
	          	<div class="box-group" id="accordion">
		            <!-- we are adding the .panel class so bootstrap.js collapse plugin detects it -->
		            <div class="panel box box-primary">
		              <div class="box-header with-border no-border">
		                <h4 class="box-title">
		                  Disabled Widgets
		                </h4>
		              </div>

						<div class="box-body widget-place">
			              <div class="box-group" id="disabled">
			                <!-- we are adding the .panel class so bootstrap.js collapse plugin detects it -->
			                <div class="panel box box-primary zero-border">
			                  <div id="{{$key}}" class="panel-collapse collapse in">
			                    <div class="box-body">
			                      <ol id="mywid-disabled" class="mymenu">
			                      	@if($data)	
			                      		@foreach($data as $field)
			                      			@if($field->disabled ==1)		                      	
							                  <li class="widgetli" data-id="{{$field->id}}" data-slug="{{$field->slug}}" data-widgetslug="{{$field->widget_slug}}" data-type="{{$field->type}}" data-serial="{{$field->serial}}" data-disabled="1">
							                  	<div class="innermenu">
							                  		<div class="innermenuhead">
							                  			<div class="title">
							                  				{{widget($field->widget_slug)[1]}}
						                  				</div>
						                  				<div class="btn-group dc-widget-button">
															<button type="button" class="btn dropdown-toggle" data-toggle="dropdown">
																<span class="caret"></span>
																<span class="sr-only">Toggle Dropdown</span>
															</button>
															<ul class="dropdown-menu" role="menu">
																@foreach(widget_area() as $keychange => $valchange )
																<li><a class="changewidget" href="#" data-widgetarea="{{$keychange}}">{{$valchange}}</a></li>
																@endforeach
																<li class="customhide"><a class="changewidget" href="#" data-widgetarea="disabled">Disable Widget</a></li>
															</ul>
														</div>
							                  			<div class="type">
							                  				<span class="arrow-icon">Widget <i class="fa fa-caret-right"></i></span>
						                  				</div>
					                  				</div>
					              					<div class="innermenubody" style="display: none;">
					              						<p><label>Widget Name<br></label><input type="text" value="{{$field->name}}" class="name widget-name"></p>
					              						@if($field->type == widget_type(0))
					              							<p>
						              							<label>Show Data<br></label>
						              							<select class="form-control widget-content widget-dropdown">
						              								@for($i=1; $i<=15; $i++)
						              									<option value="{{$i}}"<?php if($field->content==$i){echo ' selected';}?>>{{$i}}</option>
						              								@endfor
						              							</select>
					              							</p>
					              						@elseif($field->type == widget_type(1))
					              							<p>
						              							<label>Content<br></label>
						              							<textarea class="form-control widget-freetext widget-content">{{$field->content}}</textarea>
					              							</p>
														@elseif($field->type == widget_type(2))
															<p>
						              							<label>Show Menu<br></label>
						              							<select class="form-control widget-content widget-dropdown">
						              								@foreach($menu as $valmenu)
						              									<option value="{{$valmenu->id}}"<?php if($field->content==$valmenu->id){echo ' selected';}?>>{{$valmenu->name}}</option>
						              								@endforeach
						              							</select>
					              							</p>
														@elseif($field->type == widget_type(3) || $field->type == widget_type(4) || $field->type == widget_type(5))
															<input type="hidden" value="{{$field->content}}" class="widget-content">
														@endif
					              						<hr class="myhrborder">
					              						<button class="deletebutton">Remove</button>
					          						</div>
					      						</div>
							                  </li>
							                @endif
				                		@endforeach
			                		@endif
			                      </ol>
			                    </div>
			                  </div>
			                </div>
			              </div>
						</div><!-- /.box-body -->

		            </div>
	          	</div>
			</div><!-- /.box-body -->
    	</div>
    </div>
@endsection

@section('jscode')
	{{ Html::script('assets/admin/vendor/select2/select2.full.min.js') }}
	{{ Html::script('assets/admin/js/jquery.mjs.nestedSortable.js') }}
	<script>
		$(document).ready(function(){
			firstload();
			myAutoOrder();

			//Insert Widget
			$('.insert-widget').each(function(){
				var $this = $(this);
				var areas = $this.attr('data-allsec')
					areas = areas.split(',')
				var menugroups = '';
				var widgettitle='';
				var option1 = 	'<select class="form-control widget-content widget-dropdown">'+
									'<option value="1">1</option>'+
									'<option value="2">2</option>'+
									'<option value="3">3</option>'+
									'<option value="4">4</option>'+
									'<option value="5">5</option>'+
									'<option value="6">6</option>'+
									'<option value="7">7</option>'+
									'<option value="8">8</option>'+
									'<option value="9">9</option>'+
									'<option value="10">10</option>'+
									'<option value="11">11</option>'+
									'<option value="12">12</option>'+
									'<option value="13">13</option>'+
									'<option value="14">14</option>'+
									'<option value="15">15</option>'+
								'</select>';

				var option2 = 	'<textarea class="form-control widget-freetext widget-content"></textarea>';

				var option3 = 	'<select class="form-control widget-content widget-dropdown">';
					if($this.attr('data-menus')){
						menugroups = $this.attr('data-menus');
						menugroups = menugroups.split(',');
						for(var i=0; i<menugroups.length; i++){
							option3 = option3 + '<option value="'+ menugroups[i] +'">' + menugroups[i+1] + '</option>'
							i++
						}
					}
					option3 =	option3 + '</select>';
				var option4 = '<input type="hidden" value="searchblog" class="widget-content">';
				var option5 = '<input type="hidden" value="login" class="widget-content">';
				var option6 = '<input type="hidden" value="metakeys" class="widget-content">';

				var output;
					if($this.attr('data-widgettype')=='item'){
						output = option1;
						widgettitle = 'Show Data';
					}
					else if($this.attr('data-widgettype')=='detail'){
						output = option2;
						widgettitle = 'Content';
					}
					else if($this.attr('data-widgettype')=='menu'){
						widgettitle = 'Show Menu';
						output = option3
					}
					else if($this.attr('data-widgettype')=='searchblog'){
						widgettitle = '';
						output = option4;
					}
					else if($this.attr('data-widgettype')=='loginuser'){
						widgettitle = '';
						output = option5;
					}
					else if($this.attr('data-widgettype')=='metatag'){
						widgettitle = '';
						output = option6;
					}
				var output2='<div class="btn-group dc-widget-button">'+
								'<button type="button" class="btn dropdown-toggle" data-toggle="dropdown">'+
									'<span class="caret"></span>'+
									'<span class="sr-only">Toggle Dropdown</span>'+
								'</button>'+
								'<ul class="dropdown-menu" role="menu">';

								for(var i=0; i<areas.length; i++){
									if($this.attr('data-widgetarea')== areas[i]){
										classname='customhide'
									}
									else{
										classname='';
									}
				output2 = output2 +	'<li class="'+classname+'"><a class="changewidget" href="#" data-widgetarea="'+ areas[i] +'">'+ areas[i+1] +'</a></li>'
									i++;
								}

					output2= output2 + '<li><a class="changewidget" href="#" data-widgetarea="disabled">Disable Widget</a></li>'+
								'</ul>'+
							'</div>';

				$this.on('click',function(e){
					e.preventDefault();
					$('#mywid-'+ $this.attr('data-widgetarea')).append(
						'<li data-disabled="0" data-serial="" data-type="'+ $this.attr('data-widgettype') +'" data-widgetslug="'+$this.attr('data-widslug')+'" data-slug="' + $this.attr('data-widgetarea') + '" data-id="" class="widgetli">'+
						  	'<div class="innermenu">'+
						  		'<div class="innermenuhead">'+
						  			'<div class="title ui-sortable-handle">'+
						  				$this.attr('data-widgetname') +
									'</div>'+
									output2 +
						  			'<div class="type">'+
						  				'<span class="arrow-icon">Widget <i class="fa fa-caret-down"></i></span>'+
									'</div>'+
								'</div>'+
								'<div style="display: block;" class="innermenubody">'+
									'<p><label>Widget Name<br></label><input type="text" class="name widget-name" value=""></p>'+
										'<p>'+
											'<label>'+ widgettitle +'<br></label>'+
											output +
										'</p>'+
										'<hr class="myhrborder">'+
									'<button class="deletebutton">Remove</button>'+
								'</div>'+
							'</div>'+
						'</li>'
					)
					myAutoOrder();
				})
			})

			//Transfer widget
			$(document).on('click', '.changewidget', function(e){
				e.preventDefault();
				$(this).parent().addClass('customhide');
				$(this).parent().siblings().removeClass('customhide');
				$(this).closest('.widgetli').attr('data-slug', $(this).attr('data-widgetarea'));
				
				if($(this).attr('data-widgetarea')=='disabled'){
					$(this).closest('.widgetli').attr('data-disabled', '1');
				}
				else{
					$(this).closest('.widgetli').attr('data-disabled', '0');
				}
				$('#mywid-'+ $(this).attr('data-widgetarea')).append($(this).closest('.widgetli'));
				myAutoOrder();
			})
			//Delete widget
			$(document).on('click', '.deletebutton', function(e) {
				e.preventDefault();
				var delval = $('#inputdelete').val();
				var delcurr = $(this).closest('.widgetli').attr('data-id');
				if(delcurr !=''){
					if(delval==''){
						$('#inputdelete').val(delcurr)
					}
					else{
						$('#inputdelete').val(delval + '<>' + delcurr)
					}
				}
				$(this).closest('.widgetli').remove();
				myAutoOrder();
			}) ;

			//Toggle Action
			$(document).on('click', '.innermenuhead .arrow-icon', function() {
				$(this).parent().parent().next().slideToggle(300);
				if($(this).find('i').hasClass('fa-caret-right')){
					$(this).find('i').removeClass('fa-caret-right').addClass('fa-caret-down');
				}
				else{
					$(this).find('i').removeClass('fa-caret-down').addClass('fa-caret-right');
				}
			}) ;

			//name action
			$(document).on('keyup', '.widget-name', function() {
				myAutoOrder();
			})

			//textarea action
			$(document).on('keyup', '.widget-freetext', function() {
				myAutoOrder();
			})

			//Dropdown action
			$(document).on('change', '.widget-dropdown', function() {
				myAutoOrder();
			})

			//Sortable Nesting
		    $('.mymenu').nestedSortable({
		    	disableParentChange: false,
		        handle: '.title',
		        items: '.widgetli',
		        protectRoot: true,
		        toleranceElement: '> div',
		        relocate: function(){
		        	myAutoOrder();
		        	// return true;
		        }
		    });

		    function myAutoOrder(){
		    	var mymenus = $('body').find('.mymenu');
	        	var mysign = '';
	        	var inputid='';
	        	var inputslug='';
	        	var inputwidslug='';
	        	var inputtype='';
	        	var inputname='';
	        	var inputcontent='';
	        	var inputserial='';
	        	var inputdisabled='';
		    	for(var x=0; x<mymenus.length; x++){
		    		var mymenu = $(mymenus[x]).find('.widgetli');
		        	var mymenulength = mymenu.length;
		    		for(var i=0; i<mymenulength; i++){

	    				var checkid = $(mymenu[i]).attr('data-id');
	    				if(checkid){
	        				inputid = inputid + mysign + $(mymenu[i]).attr('data-id');
	    				}
	    				else{
	        				inputid = inputid + mysign + '';
	    				}

						inputslug = inputslug + mysign + $(mymenu[i]).attr('data-slug');

						inputwidslug = inputwidslug + mysign + $(mymenu[i]).attr('data-widgetslug');

						inputtype = inputtype + mysign + $(mymenu[i]).attr('data-type');

						inputdisabled = inputdisabled + mysign + $(mymenu[i]).attr('data-disabled');

	        			$(mymenu[i]).attr('data-serial', (i+1));
	        			inputserial= inputserial + mysign + (i+1);

						inputname = inputname + mysign + $(mymenu[i]).find('.widget-name').eq(0).val();

						inputcontent = inputcontent + mysign + $(mymenu[i]).find('.widget-content').eq(0).val();

	        			mysign = '<>';
		    		}
		    	}
				$('#inputid').val(inputid);
				$('#inputslug').val(inputslug);
				$('#inputwidslug').val(inputwidslug);
				$('#inputtype').val(inputtype);
				$('#inputname').val(inputname);
				$('#inputcontent').val(inputcontent);
				$('#inputserial').val(inputserial);
				$('#inputdisabled').val(inputdisabled);
		    }

		    function firstload(){
		    	$('#inputdelete').val('');
		    }

		    //remove special character
		    function trimChar(string, charToRemove) {
			    if (charToRemove === "") {
			    	return string;
			    }
			    else{
				    var countit = string.split(charToRemove).length-1
				    for(var i=0; i<countit; i++){
				    	string = string.replace(charToRemove, '')
				    }
				    return string;
			    }
			}
		})
	</script>
@endsection