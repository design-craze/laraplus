@extends('admin.master.master')

@section('title', 'Mulitilingual Page list')

@section('headcode')
	{{ Html::style('assets/common/css/pagination.css') }}
	{{ Html::style('assets/common/js/datatables/dataTables.bootstrap.css') }}
@endsection

@section('breadcambs', '<i class="fa fa-dashboard"></i> Mulitilingual Page list')

@section('bodycode')
<div class="box admin-table">
    <div class="box-header">
        <a href="{{route('pagemanager')}}" class="btn btn-default btn-flat">Page Manager</a> <a href="{{route('trashpage')}}" class="btn btn-default btn-flat">Trashed Pages</a> <a href="{{route('newpage')}}" class="btn btn-default btn-flat">Create Page</a>
    </div>
    <div class="box-body">
  		<table id="pagetable" class="table table-bordered table-striped">
            <thead>
          		<tr>
                    <th>Language</th>
                    <th>Name</th>
                    <th>Access Level</th>
                    <th>Manage</th>
              	</tr>
            </thead>
            <tbody>
            	@if($pages)
					@foreach($pages as $page)
	              	<tr>
	                    <td>{{language($page->lang)}}</span></td>
	                    <td>{{$page->name}}</td>
	                    <td>{{accesslevel($page->access_level, 'en')}}</td>
	                    <td>
	                    	<ul class="menu-manager">
	                    		<li><a href="{{route('editpage', ['id' => $page->id])}}" data-toggle="tooltip" title="Edit This Page"><i class="fa fa-pencil-square-o"></i></a></li>
                    		</ul>
	                    </td>
	              	</tr>
					@endforeach
				@endif
            </tbody>
            <tfoot>
              	<tr>
                    <th>Language</th>
                    <th>Name</th>
                    <th>Access Level</th>
                    <th>Manage</th>
              	</tr>
            </tfoot>
  		</table>
    </div><!-- /.box-body -->
</div><!-- /.box -->
	<div class="common-pagination">
		<?php 
			$pagifpname = 'First'; $pagippname = 'prev'; $pagilpname = 'Last'; $paginpname = 'Next';
			if($pages->currentPage() == '1'){
				$pagifp = '<span>'.$pagifpname.'</span>'; $pagipp = '<span>'.$pagippname.'</span>';
			}
			else{
				$pagifp = '<a href="'.route('pagemanager').'?';
				foreach($getelements as $key => $val){
	            	$pagifp .= $key.'='.$val.'&';
		        }
				$pagifp .= 'page=1'.'">'.$pagifpname.'</a>'; $pagipp = '<a href="'.$pages->previousPageUrl().'">'.$pagippname.'</a>';
			}
			if($pages->lastPage() == $pages->currentPage()){
				$pagilp = '<span>'.$pagilpname.'</span>'; $paginp = '<span>'.$paginpname.'</span>';
			}
			else{
				$pagilp = '<a href="'.route('pagemanager').'?';
				foreach($getelements as $key => $val){
	            	$pagilp .= $key.'='.$val.'&';
		        }
				$pagilp .= 'page='.$pages->lastPage().'">'.$pagilpname.'</a>'; $paginp = '<a href="'.$pages->nextPageUrl().'">'.$paginpname.'</a>';
			}
		?>
		@if($pages->total()>$pages->count())
			<ul class="prevsec">
				<li>{!!$pagifp!!}</li>
				<li>{!!$pagipp!!}</li>
			</ul>
			{{$pages->links()}}
			<ul class="nextsec">
				<li>{!!$paginp!!}</li>
				<li>{!!$pagilp!!}</li>
			</ul>
			<div style="clear:both"></div>
		@endif
	</div>
</div>
@endsection

@section('jscode')
	{{ Html::script('assets/common/js/datatables/jquery.dataTables.min.js') }}
	{{ Html::script('assets/common/js/datatables/dataTables.bootstrap.min.js') }}
	<script>
	    $(function () {
	      	$("#pagetable").DataTable({
	      		"paging": false,
	      		"info": false,
	      	});
	    });
		$(function () {
		  	$('[data-toggle="tooltip"]').tooltip()
		})
    </script>
@endsection