@extends('admin.master.master')

@section('title', 'Menu')

@section('headcode')
	{{ Html::style('assets/admin/css/menu.css') }}
	{{ Html::style('assets/admin/vendor/select2/select2.min.css') }}
@endsection

@section('breadcambs', '<i class="fa fa-dashboard"></i> Menu')

@section('bodycode')

	<div class="row">
		<div class="col-md-4">
	        <div class="box box-primary">
	            <div class="box-header with-border">
	            	<h3 class="box-title">Select Menu</h3>
	            </div><!-- /.box-header -->
	            <!-- form start -->
	            {{ Form::open(array('route'=>'savenav', 'method'=>'post', 'role' => 'form')) }}
					<div class="box-body">
						<div class="form-group">
						    <select class="form-control select2" style="width: 100%;" name="getmenu">
						    	@foreach($selectnavs as $selectitem)
									<option value="{{$selectitem->id}}"<?php if($selectitem->selected==1){echo ' selected';} ?>>{{$selectitem->name}}</option>
								@endforeach
						    </select>
						</div>
					</div><!-- /.box-body -->

	                <div class="box-footer">
	                	<input class="btn btn-primary" type="submit"  name="changemenu" value="Select Menu">
	                </div>
	            {{ Form::close() }}
	        </div>

	        <div class="box box-primary">
	            <div class="box-header with-border">
	            	<h3 class="box-title">Add PAGE</h3>
	            </div><!-- /.box-header -->
	            <!-- form start -->
	            <div id="allpages" class="box-body" style="overflow-y: scroll; max-height: 150px;">
					@if($getpage)
						@foreach($getpage as $singlepage)
							<div class="checkbox" style="margin:3px 0;">
								<label>
									<input type="checkbox" class="pagecheckbox" data-id="" data-parentid="0" data-menuid="{{$mainmenuid}}" data-name="{{$singlepage->name}}" data-pageid="{{$singlepage->id}}" data-blogid="0" data-link="" data-class="" data-newtab="0" data-megamenu="0" data-serial="0"> {{$singlepage->name}}
								</label>
							</div>
						@endforeach
					@endif
				</div>
				<div class="box-footer">
					<button class="btn btn-primary" id="addpage">Add Page</button>
				</div>
	        </div>

	        <div class="box box-primary">
	            <div class="box-header with-border">
	            	<h3 class="box-title">Add BLOG</h3>
	            </div><!-- /.box-header -->
	            <!-- form start -->
	            <div id="allblogs" class="box-body" style="overflow-y: scroll; max-height: 150px;">
					@if($getblog)
						@foreach($getblog as $singleblog)
							<div class="checkbox" style="margin:3px 0;">
								<label>
									<input type="checkbox" class="blogcheckbox" data-id="" data-parentid="0" data-menuid="{{$mainmenuid}}" data-name="{{$singleblog->name}}" data-pageid="0" data-blogid="{{$singleblog->id}}" data-link="" data-class="" data-newtab="0" data-megamenu="0" data-serial="0"> {{$singleblog->name}}
								</label>
							</div>
						@endforeach
					@endif
				</div>
				<div class="box-footer">
					<button class="btn btn-primary" id="addblog">Add Blog</button>
				</div>
	        </div>

	        <div class="box box-primary">
	            <div class="box-header with-border">
	            	<h3 class="box-title">Add LINK</h3>
	            </div><!-- /.box-header -->
	            <!-- form start -->
	            <div class="box-body">	            	
		            <div class="form-group">
	                    <label for="alllinks">Link</label>
		            	<input type="text" id="alllinks" placeholder="Enter url" class="form-control" data-id="" data-parentid="0" data-menuid="{{$mainmenuid}}" data-pageid="0" data-blogid="0" data-link="#" data-class="" data-newtab="0" data-megamenu="0" data-serial="0">
	                </div>
		            <div class="form-group">
						<input type="text" id="alllinkname" placeholder="Enter Menu Item Name" class="form-control" data-name="customlink">
		            </div>
	            </div>
				<div class="box-footer">
					<button class="btn btn-primary" id="addlink">Add A custom Link</button>
				</div>
	        </div>
	    </div>
		<div class="col-md-8">
			<div class="box box-primary" style="min-height: 836px;">
				<div class="box-header with-border">
	            	<h3 class="box-title">Menu ITEMS</h3>
	            </div>
				{{ Form::open(array('route'=>'savenav', 'method'=>'post')) }}
					<div class="box-header with-border">
						<input type="submit" class="btn btn-primary" name="savemenu" value="Save Menu">
					</div>
					<div class="box-body">
						<div style="overflow:hidden; width100%;">
							{!! $menu !!}
						</div>
					</div>
					{!!  $menuinputs !!}
					<div class="box-footer">
						<input type="submit" class="btn btn-primary" name="savemenu" value="Save Menu">
					</div>
				{{ Form::close() }}
			</div>
		</div>
    </div>
@endsection

@section('jscode')
	{{ Html::script('assets/admin/vendor/select2/select2.full.min.js') }}
	{{ Html::script('assets/admin/js/jquery.mjs.nestedSortable.js') }}
	{{ Html::script('assets/admin/js/adminmenuhandler.js') }}

	<script>
		$(function () {
	        //Initialize Select2 Elements
	        $(".select2").select2();
	    })
	</script>
@endsection