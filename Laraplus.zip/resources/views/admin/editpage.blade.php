@extends('admin.master.master')

@section('title', 'Edit Page')

@section('headcode')
    {{ Html::style('assets/common/js/tags/tagmanager.css') }}
    {{ Html::style('assets/common/js/dropzone/dropzone.min.css') }}
    {{ Html::style('assets/admin/css/mediamanager.css') }}
    <style>
        .space-remover{padding:5px 10px;}
    </style>
@endsection

@section('breadcambs', '<i class="fa fa-dashboard"></i> Edit Page')

@section('bodycode')
    <div class="row">
        <div class="col-md-12">
            <a href="{{route('pagemanager')}}" class="btn btn-default btn-flat">Go To page lists</a>
        </div>
    </div>
    <!-- <strong>Show Page : </strong> <a href="" target="_blank">Pagelink</a> -->
    
    {{ Form::open(array('route'=>['pageeditprocess', 'id' => $singlepage->id], 'method'=>'post')) }}
        <div class="row">
            <div class="col-md-8">
                <div class="panel-body page-editor">
                    <div class="form-horizontal">
                        <div class="form-group">
                            <input type="text" name="name" class="form-control input-lg" placeholder="Enter Title Here" value="<?php if(old('name')!=''){echo old('name');} else{echo $singlepage->name;} ?>">
                        </div>
                    </div>
                    @if($singlepage->parent==0)
                    <div class="form-horizontal">
                        <div class="form-group">
                            <input type="text" name="slug" class="form-control input-lg" placeholder="enter-slug-here" value="<?php if(old('slug')!=''){echo old('slug');} else{echo $singlepage->slug;} ?>">
                        </div>
                    </div>
                    @endif
                </div>
                <div class="panel-body page-editor">
                    <div class="form-horizontal">
                        <div class="form-group">
                            <textarea id="maintext" name="description" class="form-control" placeholder="Free Content goes here..."><?php if(old('description')!=''){echo old('description');} else{echo $singlepage->description;} ?></textarea>
                        </div>
                    </div>
                </div>
                <div class="row marg-top-15">
                    <div class="col-sm-4">
                        <div class="panel">
                            <div class="panel-heading">
                                <div class="panel-title"> <i class="fa fa-pencil"></i> Header Layout</div>
                            </div>
                            <div class="panel-body space-remover">
                                <div class="form-horizontal">
                                    <div class="form-group">
                                        <div class="col-md-12">
                                            <select class="form-control" style="width: 100%;" name="hdrlayout">
                                                <option value="-1"<?php if(old('hdrlayout')== '-1'){ echo ' selected';} else if($singlepage->hdrlayout== '-1'){ echo ' selected';}?>>Default</option>
                                                <option value="2"<?php if(old('hdrlayout')== '2'){ echo ' selected';} else if($singlepage->hdrlayout== '2'){ echo ' selected';}?>>Boxed</option>
                                                <option value="1"<?php if(old('hdrlayout')== '1'){ echo ' selected';} else if($singlepage->hdrlayout== '1'){ echo ' selected';}?>>Fullwidth</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="panel">
                            <div class="panel-heading">
                                <div class="panel-title"> <i class="fa fa-pencil"></i> Header</div>
                            </div>
                            <div class="panel-body space-remover">
                                <div class="form-horizontal">
                                    <div class="form-group">
                                        <div class="col-md-12">
                                            <select class="form-control" style="width: 100%;" name="header">
                                                <option value="-1"<?php if(old('header')== '-1'){ echo ' selected';} else if($singlepage->header== '-1'){ echo ' selected';}?>>Default</option>
                                                <option value="1"<?php if(old('header')== '1'){ echo ' selected';} else if($singlepage->header== '1'){ echo ' selected';}?>>Show</option>
                                                <option value="0"<?php if(old('header')== '0'){ echo ' selected';} else if($singlepage->header== '0'){ echo ' selected';}?>>Hide</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="panel">
                            <div class="panel-heading">
                                <div class="panel-title"> <i class="fa fa-pencil"></i> Main Body Type</div>
                            </div>
                            <div class="panel-body space-remover">
                                <div class="form-horizontal">
                                    <div class="form-group">
                                        <div class="col-md-12">
                                            <select class="form-control" style="width: 100%;" name="bodystyle">
                                                <option value="-1"<?php if(old('bodystyle')== '-1'){ echo ' selected';} else if($singlepage->bodystyle== '-1'){ echo ' selected';}?>>Default</option>
                                                <option value="2"<?php if(old('bodystyle')== '2'){ echo ' selected';} else if($singlepage->bodystyle== '2'){ echo ' selected';}?>>Boxed</option>
                                                <option value="1"<?php if(old('bodystyle')== '1'){ echo ' selected';} else if($singlepage->bodystyle== '1'){ echo ' selected';}?>>Fullwidth</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-4">
                        <div class="panel">
                            <div class="panel-heading">
                                <div class="panel-title"> <i class="fa fa-pencil"></i> Title Bar Layout</div>
                            </div>
                            <div class="panel-body space-remover">
                                <div class="form-horizontal">
                                    <div class="form-group">
                                        <div class="col-md-12">
                                            <select class="form-control" style="width: 100%;" name="titlelayout">
                                                <option value="-1"<?php if(old('titlelayout')== '-1'){ echo ' selected';} else if($singlepage->titlelayout== '-1'){ echo ' selected';}?>>Default</option>
                                                <option value="2"<?php if(old('titlelayout')== '2'){ echo ' selected';} else if($singlepage->titlelayout== '2'){ echo ' selected';}?>>Boxed</option>
                                                <option value="1"<?php if(old('titlelayout')== '1'){ echo ' selected';} else if($singlepage->titlelayout== '1'){ echo ' selected';}?>>Fullwidth</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="panel">
                            <div class="panel-heading">
                                <div class="panel-title"> <i class="fa fa-pencil"></i> Title Bar</div>
                            </div>
                            <div class="panel-body space-remover">
                                <div class="form-horizontal">
                                    <div class="form-group">
                                        <div class="col-md-12">
                                            <select class="form-control" style="width: 100%;" name="title">
                                                <option value="-1"<?php if(old('title')== '-1'){ echo ' selected';} else if($singlepage->title== '-1'){ echo ' selected';}?>>Default</option>
                                                <option value="1"<?php if(old('title')== '1'){ echo ' selected';} else if($singlepage->title== '1'){ echo ' selected';}?>>Show</option>
                                                <option value="0"<?php if(old('title')== '0'){ echo ' selected';} else if($singlepage->title== '0'){ echo ' selected';}?>>Hide</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="panel">
                            <div class="panel-heading">
                                <div class="panel-title"> <i class="fa fa-pencil"></i> Breadcrumbs</div>
                            </div>
                            <div class="panel-body space-remover">
                                <div class="form-horizontal">
                                    <div class="form-group">
                                        <div class="col-md-12">
                                            <select class="form-control" style="width: 100%;" name="breadcrumbs">
                                                <option value="-1"<?php if(old('breadcrumbs')== '-1'){ echo ' selected';} else if($singlepage->breadcrumbs== '-1'){ echo ' selected';}?>>Default</option>
                                                <option value="2"<?php if(old('breadcrumbs')== '2'){ echo ' selected';} else if($singlepage->breadcrumbs== '2'){ echo ' selected';}?>>Show</option>
                                                <option value="1"<?php if(old('breadcrumbs')== '1'){ echo ' selected';} else if($singlepage->breadcrumbs== '1'){ echo ' selected';}?>>Hide</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-4">
                        <div class="panel">
                            <div class="panel-heading">
                                <div class="panel-title"> <i class="fa fa-pencil"></i> Left Sidebar</div>
                            </div>
                            <div class="panel-body space-remover">
                                <div class="form-horizontal">
                                    <div class="form-group">
                                        <div class="col-md-12">
                                            <select class="form-control" style="width: 100%;" name="leftside">
                                                <option value="default"<?php if(old('leftside')=='default'){ echo ' selected';} else if($singlepage->leftside=='default'){ echo ' selected';}?>>Default</option>
                                                <option value="none"<?php if(old('leftside')=='none'){ echo ' selected';} else if($singlepage->leftside=='none'){ echo ' selected';}?>>none</option>
                                                <?php
                                                    $a =widget_area();
                                                ?>
                                                @foreach($a as $key => $val)
                                                    <option value="{{$key}}"<?php if(old('leftside')==$key){ echo ' selected';} else if($singlepage->leftside==$key){ echo ' selected';}?>>{{$val}}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="panel">
                            <div class="panel-heading">
                                <div class="panel-title"> <i class="fa fa-pencil"></i> Page Layout</div>
                            </div>
                            <div class="panel-body space-remover">
                                <div class="form-horizontal">
                                    <div class="form-group">
                                        <div class="col-md-12">
                                            <select class="form-control" style="width: 100%;" name="layout">
                                                <option value="-1"<?php if(old('layout')== '-1'){ echo ' selected';} else if($singlepage->layout== '-1'){ echo ' selected';}?>>Default</option>
                                                <option value="1"<?php if(old('layout')== '1'){ echo ' selected';} else if($singlepage->layout== '1'){ echo ' selected';}?>>Boxed</option>
                                                <option value="0"<?php if(old('layout')== '0'){ echo ' selected';} else if($singlepage->layout== '0'){ echo ' selected';}?>>Full Width</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="panel">
                            <div class="panel-heading">
                                <div class="panel-title"> <i class="fa fa-pencil"></i> Right Sidebar</div>
                            </div>
                            <div class="panel-body space-remover">
                                <div class="form-horizontal">
                                    <div class="form-group">
                                        <div class="col-md-12">
                                            <select class="form-control" style="width: 100%;" name="rightside">
                                                <option value="default"<?php if(old('rightside')=='default'){ echo ' selected';}  else if($singlepage->rightside=='default'){ echo ' selected';}?>>Default</option>
                                                <option value="none"<?php if(old('rightside')=='none'){ echo ' selected';}  else if($singlepage->rightside=='none'){ echo ' selected';}?>>none</option>
                                                <?php
                                                    $a =widget_area();
                                                ?>
                                                @foreach($a as $key => $val)
                                                    <option value="{{$key}}"<?php if(old('rightside')==$key){ echo ' selected';} else if($singlepage->rightside==$key){ echo ' selected';}?>>{{$val}}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-4">
                        <div class="panel">
                            <div class="panel-heading">
                                <div class="panel-title"> <i class="fa fa-pencil"></i> Footer Layout</div>
                            </div>
                            <div class="panel-body space-remover">
                                <div class="form-horizontal">
                                    <div class="form-group">
                                        <div class="col-md-12">
                                            <select class="form-control" style="width: 100%;" name="ftrlayout">
                                                <option value="-1"<?php if(old('ftrlayout')== '-1'){ echo ' selected';} else if($singlepage->ftrlayout== '-1'){ echo ' selected';}?>>Default</option>
                                                <option value="2"<?php if(old('ftrlayout')== '2'){ echo ' selected';} else if($singlepage->ftrlayout== '2'){ echo ' selected';}?>>Boxed</option>
                                                <option value="1"<?php if(old('ftrlayout')== '1'){ echo ' selected';} else if($singlepage->ftrlayout== '1'){ echo ' selected';}?>>Fullwidth</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="panel">
                            <div class="panel-heading">
                                <div class="panel-title"> <i class="fa fa-pencil"></i> Footer Widget</div>
                            </div>
                            <div class="panel-body space-remover">
                                <div class="form-horizontal">
                                    <div class="form-group">
                                        <div class="col-md-12">
                                            <select class="form-control" style="width: 100%;" name="ftrwid">
                                                <option value="-1"<?php if(old('ftrwid')== -1-1){ echo ' selected';} else if($singlepage->ftrwid== -1-1){ echo ' selected';}?>>Default</option>
                                                <option value="0"<?php if(old('ftrwid')=='0'){ echo ' selected';} else if($singlepage->ftrwid== '0'){ echo ' selected';}?>>0</option>
                                                <option value="1"<?php if(old('ftrwid')=='1'){ echo ' selected';} else if($singlepage->ftrwid== '1'){ echo ' selected';}?>>1</option>
                                                <option value="2"<?php if(old('ftrwid')=='2'){ echo ' selected';} else if($singlepage->ftrwid== '2'){ echo ' selected';}?>>2</option>
                                                <option value="3"<?php if(old('ftrwid')=='3'){ echo ' selected';} else if($singlepage->ftrwid== '3'){ echo ' selected';}?>>3</option>
                                                <option value="4"<?php if(old('ftrwid')=='4'){ echo ' selected';} else if($singlepage->ftrwid== '4'){ echo ' selected';}?>>4</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="panel">
                            <div class="panel-heading">
                                <div class="panel-title"> <i class="fa fa-pencil"></i> Bottom Footer</div>
                            </div>
                            <div class="panel-body space-remover">
                                <div class="form-horizontal">
                                    <div class="form-group">
                                        <div class="col-md-12">
                                            <select class="form-control" style="width: 100%;" name="btmftr">
                                                <option value="-1"<?php if(old('btmftr')== '-1'){ echo ' selected';} else if($singlepage->btmftr== '-1'){ echo ' selected';}?>>Default</option>
                                                <option value="1"<?php if(old('btmftr')=='1'){ echo ' selected';} else if($singlepage->btmftr== '1'){ echo ' selected';}?>>Show</option>
                                                <option value="0"<?php if(old('btmftr')=='0'){ echo ' selected';} else if($singlepage->btmftr== '0'){ echo ' selected';}?>>Hide</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="panel-body page-editor page-editor-2">
                    <div class="form-horizontal">
                        <div class="form-group">
                            <label for="meta-desc"><h4>Meta Title</h4></label>
                            <input type="text" name="metatitle" class="form-control" rows="10" placeholder="Meta Title" value="<?php if(old('metatitle')!=''){echo old('metatitle');} else{echo $singlepage->metatitle;} ?>">
                        </div>
                        <div class="form-group">
                            <label for="meta-desc"><h4>Meta Description</h4></label>
                            <textarea name="metadesc" class="form-control mytextarea" rows="10" placeholder="Meta Desc"><?php if(old('metadesc')!=''){echo old('metadesc');} else{echo $singlepage->metadesc;} ?></textarea>
                        </div>
                        <div class="form-group">
                            <label for="meta-desc"><h4>Extra CSS</h4></label>
                            <textarea name="css" class="form-control mytextarea" rows="20" placeholder="Extra css"><?php if(old('css')!=''){echo old('css');} else{echo $singlepage->css;} ?></textarea>
                        </div>
                        <div class="form-group">
                            <label for="meta-desc"><h4>Extra JS Code</h4></label>
                            <textarea name="js" class="form-control mytextarea" rows="20" placeholder="Extra js"><?php if(old('js')!=''){echo old('js');} else{echo $singlepage->js;} ?></textarea>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 ">
                <div class="page-editor">

                    <div class="panel">
                        <div class="panel-heading">
                            <div class="panel-title"> <i class="fa fa-pencil"></i> Tags</div>
                        </div>
                        <div class="panel-body">
                            <div class="form-horizontal">
                                <div class="form-group">
                                        <div class="col-md-12">
                                            <input type="text" placeholder="Add a new tag.." class="form-control tm-input" id="tagmanager">
                                            <div class="tag-container"></div>
                                        </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="panel">
                        <div class="panel-heading">
                            <div class="panel-title"> <i class="fa fa-pencil"></i> User Level</div>
                        </div>
                        <div class="panel-body">
                            <div class="form-horizontal">
                                <div class="form-group">
                                        <div class="col-md-12">
                                            <select class="form-control" style="width: 100%;" name="access_level">
                                                <?php
                                                    $a =role($lang='en');
                                                ?>
                                                @foreach($a as $key => $val)
                                                    <option value="{{$key}}"<?php if(old('access_level')==$key){ echo ' selected';}else if($singlepage->access_level==$key){ echo ' selected';}?>>{{$val}}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="panel">
                        <div class="panel-heading">
                            <div class="panel-title"> <i class="fa fa-pencil"></i> Page Template</div>
                        </div>
                        <div class="panel-body">
                            <div class="form-horizontal">
                                <div class="form-group">
                                    <div class="col-md-12">
                                        <select class="form-control" style="width: 100%;" name="template">
                                            <?php
                                                $a =pagetemplates();
                                            ?>
                                            @foreach($a as $key => $val)
                                                <option value="{{$key}}"<?php if(old('template')==$key){ echo ' selected';}else if($singlepage->template==$key){ echo ' selected';}?>>{{$val}}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="panel">
                        <div class="panel-heading">
                            <div class="panel-title"> <i class="fa fa-pencil"></i> Save Page</div>
                        </div>
                        <div class="panel-body">
                            <div class="form-horizontal">
                                <div class="form-group">
                                    <div class="col-md-12">
                                        <input type="submit" class="btn btn-primary btn-flat" value="Update Page">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="panel">
                        <div class="panel-heading">
                            <div class="panel-title"> <i class="fa fa-pencil"></i> Menu Setting</div>
                        </div>
                        <div class="panel-body">
                            <div class="form-horizontal">
                                <div class="form-group">
                                    <div class="col-md-12" id="menu-control">
                                        @foreach($menuplace as $val)
                                            <label for="meta-desc"><h4>{{$val->slug}}</h4></label>
                                            <select class="form-control menu-control" style="width: 100%;" data-menuplace="{{$val->slug}}">
                                                    <option value="0">None</option>
                                                @foreach($menu as $val1)
                                                    <?php 
                                                        $a='';
                                                        if(old('menu')!=''){ 
                                                            $b = pagemenuplace(old('menu'));
                                                            if($b[$val->slug] == $val1->id){
                                                                $a = ' selected';
                                                            }
                                                            else{
                                                                $a='';
                                                            }
                                                        }
                                                        else if($singlepage->menu!=''){
                                                            $b = pagemenuplace($singlepage->menu);
                                                            if($b[$val->slug] == $val1->id){
                                                                $a = ' selected';
                                                            }
                                                            else{
                                                                $a='';
                                                            }
                                                        }
                                                    ?>
                                                    <option value="{{$val1->id}}"{{$a}}>{{$val1->name}}</option>
                                                @endforeach
                                            </select>
                                        @endforeach
                                        <input type="hidden" value="<?php if(old('menu')!=''){echo old('menu');} else{echo $singlepage->menu;} ?>" name="menu" id="menuplace">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    {{ Form::close() }}

    <!-- start: model -->
    <div id="mediapopup" data-backdrop="false" data-keyboard="false" class="modal bs-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                  <div class="modal-header">
                    <button id="mymediacancletbutton" type="button" class="btn btn-default pull-right" data-dismiss="modal">Close</button>
                    <h4 class="modal-title" id="myModalLabel">Media Manager</h4>
                  </div>
                  <div class="modal-body">
                    <div class="nav-tabs-custom">
                        <ul class="nav nav-tabs">
                          <li class="active"><a href="#tab_1" data-toggle="tab">Upload</a></li>
                          <li><a href="#tab_2" data-toggle="tab">Images</a></li>
                        </ul>
                        <div class="tab-content">
                          <div class="tab-pane active" id="tab_1">
                            {{ Form::open(array('route'=>['mediauploadprocess'], 'class'=> 'dropzone', 'id' => 'addImages', 'method'=>'post')) }}
                            {{Form::close()}}
                          </div><!-- /.tab-pane -->
                          <div class="tab-pane" id="tab_2">
                            <form action="#" method="post">
                             <div class="row">
                                 <div class="col-md-8">
                                    <ul class="listrap list-inline" id="medialibraryul" data-libraryimage="">
                                        @if(isset($mymedia) && $mymedia!='')
                                            @foreach($mymedia as $mysinglemedia)
                                                <li class="medialibraryli" data-libraryimage="{{route('home')}}/{{$mysinglemedia->filepath}}{{$mysinglemedia->filename}}">
                                                    <div class="listrap-toggle">
                                                        <span></span>
                                                        <img src="{{route('home')}}/{{$mysinglemedia->filepath}}thumbs/{{$mysinglemedia->filename}}" />
                                                    </div>
                                                </li>
                                            @endforeach
                                        @endif
                                    </ul>
                                 </div>
                                 <div class="col-md-4" style="border-left: 1px solid #eeeeee;">
                                     <h4>Attachment Details</h4>
                                     <hr>
                                     <div class="form-horizontal">
                                        <div class="form-group">
                                            <div class="col-sm-12 clearfix">
                                                <button id="mymediaselectbutton" class="btn btn-primary btn-sm pull-right">Add Image</button>
                                            </div>
                                        </div>
                                     </div>
                                     <img id="mediaimagepreview" src="https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcTPojpzonCfH7DzKVrniwYFN1NDo5ypcABz_S-13xRgeehz4c8CE33koAw" alt="IMG" class="img-responsive">
                                     <hr>
                                     <div class="form-horizontal">
                                        <div class="form-group">
                                            <label for="inputEmail3" class="col-sm-4">URL</label>
                                            <div class="col-sm-8">
                                                <input id="mediaimageurl" type="url" class="form-control input-sm" placeholder="URL">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="inputEmail3" class="col-sm-4">ALT TEXT</label>
                                            <div class="col-sm-8">
                                                <input id="mediaimagealttext" type="text" class="form-control input-sm" placeholder="Enter ALT Text">
                                            </div>
                                        </div>

                                    </div>
                                     
                                 </div>
                             </div>
                             </form>
                          </div><!-- /.tab-pane -->
                        </div><!-- /.tab-content -->
                      </div><!-- nav-tabs-custom -->
                  </div>
                </div>
        </div>
    </div>
@endsection


@section('jscode')
    {{ Html::script('assets/common/js/tinymce/tinymce.min.js') }}
    {{ Html::script('assets/common/js/tags/jquery.validate.min.js') }}
    {{ Html::script('assets/common/js/tags/tagmanager.js') }}
    {{ Html::script('assets/common/js/dropzone/dropzone.min.js') }}
    {{ Html::script('assets/admin/js/admintinymceintegration.js') }}

    <script>
        //Init jquery Date Picker
        // $('.datepicker').datepicker({
        //      format: 'dd/mm/yyyy',
        //      autoclose: true,
        //      orientation: 'bottom'
        //  });

        //Init jquery Tags Manager 
        $(".tm-input").tagsManager({
        tagsContainer: '.tag-container',
                prefilled: [
                    <?php
                        if(old('metatag')!=null){
                            $meta= explode(',', old('metatag'));
                            foreach($meta as $tag){
                                echo '"'.$tag.'",';
                            }
                        }
                        else{
                            if($singlepage->metatag!=null){
                            $meta= explode(',', $singlepage->metatag);
                            foreach($meta as $tag){
                                echo '"'.$tag.'",';
                            }
                        }
                        }
                    ?>
                ],
                tagClass: 'tm-tag-info',
                hiddenTagListName: 'metatag',
                hiddenTagListId: null
        });
        $(function(){
            pagemenudata();
            $('#menuplace').val(pagemenudata());
            $('#menu-control').find('.menu-control').each(function(){
                var $this=$(this);
                $this.on('change', function(){
                    $('#menuplace').val(pagemenudata());
                })
            })

            function pagemenudata(){
                var menu = $('#menu-control').find('.menu-control');
                var menulength = menu.length;
                var a='';
                for(var i=0; i < menu.length; i++){
                    if(i==0){
                        a = $(menu[i]).attr('data-menuplace') + '>' + $(menu[i]).val();
                    }
                    else{
                        a = a + ',' + $(menu[i]).attr('data-menuplace') + '>' + $(menu[i]).val();
                    }
                }
                return a;
            }
        })
    </script>
    {{ Html::script('assets/admin/js/adminmedialibraryintegration.js') }}
@endsection