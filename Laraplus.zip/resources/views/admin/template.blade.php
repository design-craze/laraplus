@extends('admin.master.master')


@section('title', 'Template')

@section('breadcambs', '<i class="fa fa-dashboard"></i> Template')


@section('bodycode')
	<div class="row">
		@foreach(templates() as $template)
			<div class="col-md-4">
				<div>
					<img src="{{route('home')}}/assets/template/{{$template}}/template-thumb.jpg" alt="">
				</div>
				<div>
					<h4>{{$template}}@if($settinghelper['template']==$template) - Active @endif</h4>
					@if($settinghelper['template']!=$template)
					<a href="{{route('changetemplate', ['name'=>$template])}}">Active This Template</a> 
					@endif
				</div>

			</div>
		@endforeach
	</div>
@endsection