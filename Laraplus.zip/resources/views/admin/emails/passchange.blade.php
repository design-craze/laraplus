<h5>Hello {{ $data->fname }} {{$data->lname}}</h5>
<p>
Recenlty You have changed your password. Here are your new credintials - 
</p>
<ul>
	<li>User Name: {{$data->username}}</li>
	<li>Email : {{$data->email}}</li>
	<li>password : {{$new_pass}}</li>
	
</ul>

<p>If you did not change it contact us for help!</p>

<p>
    Thanks a lot for being with us. <br />
    Design Craze
</p>