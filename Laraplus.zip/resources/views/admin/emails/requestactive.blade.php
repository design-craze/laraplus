<h5>Hello {{ $admin->fname }} {{$admin->lname}}</h5>
<p>
You have got a request of account activation. Below is the user's account
</p>
<ul>
	<li>User ID: {{$user->id}}</li>
	<li>User Name: {{$user->username}}</li>
	<li>Email : {{$user->email}}</li>
	<li>Email Verificaton : {{isemailverified($user->verified)}}</li>
	<li>Account Status : {{activelevel($user->active)}}</li>
	<li>User Role : {{roleaccess($user->role)}}</li>
</ul>

<h5>User's Message</h5>
<p>
	{{$usermessage}}
</p>