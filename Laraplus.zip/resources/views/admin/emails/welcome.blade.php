<h5>Hello {{ $data->fname }} {{$data->lname}}</h5>
<p>
Welcom to our familty and thank you for joining us by providing us your information. Your account has been successfully created by Admin of Desig Craze comprising following crediential, Please login to manage your account - 
</p>
<ul>
	<li>User Name: {{$data->username}}</li>
	<li>Email : {{$data->email}}</li>
	<li>password : {{$data->password}}</li>
	
</ul>

<p>Let Us know If you need any kind of help.</p>

<p>
    Thanks a lot for being with us. <br />
    Design Craze
</p>