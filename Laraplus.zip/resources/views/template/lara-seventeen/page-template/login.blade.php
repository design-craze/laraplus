@include('template.'.$settinghelper['template'].'.includes.header')
@section('templatesection')
	@if($userlevel == 0)
		<div class="row">
			<div class="col-md-12">
				<div class="access-form">
					<div class="access-form-top">
						<div class="access-form-top-left bg-default">
							<h2>WELCOME BACK</h2>
							<p>Get logged in to access your account</p>
						</div>
						<div class="access-form-top-right bg-second">
							<h4>New Here? Create An Account</h4>
							<a href="<?php 
							if($settinghelper['signup_page']!=''){echo route('page',['slug'=>getpage($settinghelper['signup_page'])]);}
							?>" class="btn btn-default">Sign Up</a>
						</div>
					</div>
					<div class="access-form-bottom">
					{{ Form::open(array('route'=>'adminloginprocess', 'method'=>'post')) }}
				        <input type="text" placeholder="Email or Username" name="user" value="{{old('user')}}">
				    	<input type="password" placeholder="Password" name="password" value="{{old('password')}}">
					    <div class="form-group clearfix">
					    	<div class="widget-label checkbox-inline pull-left" >
							    <label>
							      	<input type="checkbox" name="remember_me"> Remember Me
							    </label>
							</div>
							<div class="widget-forget checkbox-inline pull-right">
							    <a href="{{route('page', ['slug'=>getpage($settinghelper['identify_page'])])}}">
							    	Forgotten Account?
							    </a>
							</div>
					    </div>
					    <button type="submit" class="btn btn-primary dc-btn" name="login">Login</button>
					{{ Form::close() }}
					</div>
				</div>
			</div>
		</div>
	@endif
@show
@include('template.'.$settinghelper['template'].'.includes.footer')