@section('pagetop')
 @if(Mapper::render() && isset($settinghelper['contact_map']) && $settinghelper['contact_map']==1)
  {!! Mapper::render() !!}
 @endif
@endsection
@include('template.'.$settinghelper['template'].'.includes.header')
@section('templatesection')
	<div class="row">
		<div class="col-md-12">
			<h2>Send Us a Message</h2>
		</div>
	</div>
	{{ Form::open(array('route'=>'contactusprocess', 'method'=>'post')) }}
	<div class="row">
		<div class="col-md-12">
			<div class="form-group">
				<label for="name">Name</label>
				<input type="text" name="name" id="name" placeholder="Name">
			</div>
			<div class="form-group">
				<label for="email">Email</label>
				<input type="email" name="email" id="email" placeholder="Email">
			</div>
			<div class="form-group">
				<label for="subject">Subject</label>
				<input type="text" name="subject" id="subject" placeholder="Subject">
			</div>
			<div class="form-group">
				<label for="message">Message</label>
				<textarea name="message" id="message" cols="30" rows="5"></textarea>
			</div>
			<div class="form-group">
				{!! app('captcha')->display(); !!}
			</div>
			<div class="form-group">
				<button type="submit" name="contact_us" class="btn dc-btn">Submit</button>
			</div>
		</div>
	</div>
	{{ Form::close() }}
@show
@include('template.'.$settinghelper['template'].'.includes.footer')