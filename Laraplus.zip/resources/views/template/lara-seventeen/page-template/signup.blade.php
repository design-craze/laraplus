@include('template.'.$settinghelper['template'].'.includes.header')
@section('templatesection')
	@if($userlevel == 0)
		<div class="row">
			<div class="col-md-12">
				<div class="access-form">
					<div class="access-form-top">
						<div class="access-form-top-left bg-default">
							<h2>WELCOME !!!</h2>
							<p>Sign Up to Have Your Own Account</p>
						</div>
						<div class="access-form-top-right bg-second">
							<h4>Have an Account? Log In</h4>
							<a href="<?php 
							if($settinghelper['login_page']!=''){echo route('page',['slug'=>getpage($settinghelper['login_page'])]);}
							?>" class="btn btn-default">Log In</a>
						</div>
					</div>
					<div class="access-form-bottom">
					{{ Form::open(array('route'=>'signupprocess', 'method'=>'post')) }}
					    <input type="text" name="fname" id="fname" placeholder="Enter Your First Name" value="{{old('fname')}}">
				    	<input type="text" name="lname" id="lname" placeholder="Enter Your Last Name" value="{{old('lname')}}">
					    <input type="text" name="username" id="username" placeholder="Choose a Username" value="{{old('username')}}">
					    <input type="text" name="email" id="email" placeholder="Enter Your Email Address" value="{{old('email')}}">
					    <input type="text" name="email_confirmation" id="email_confirmation" placeholder="Confirm Email" value="{{old('email_confirmation')}}">
					    <input type="password" name="password" id="password" placeholder="password" value="{{old('password')}}">
					    <input type="password" name="password_confirmation" id="password" placeholder="Confirm Password" value="{{old('password_confirmation')}}">
					    @if(isset($settinghelper['signable']) && !empty($settinghelper['signable']))
				    	<?php
					    	$signable = explode(',', $settinghelper['signable']);
					    	$maxsignable = count($signable);
					    ?>
					    @if($maxsignable > 0)
					        <select name="role" class="select">
					        	<option value="">Select Role</option>
					        	@foreach($signable as $val)
					        	<option value="{{ $val }}" {{ old('role') != null && old('role') == $val ? 'selected="selected"' : '' }}>{{roleaccess($val)}}</option>
					        	@endforeach
					        </select>
					    @endif
					    @endif
					    <button type="submit" class="btn dc-btn" name="create_account">Create Account</button>
					{{ Form::close() }}
					</div>
				</div>
			</div>
		</div>
	@endif
@show
@include('template.'.$settinghelper['template'].'.includes.footer')