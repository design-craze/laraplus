/* start: header top responsive style */
.dc-social {
    text-align: center;
}
.hdr-top-left {
    border-bottom: 1px solid #e0e0e0;
    border-right: medium none;
    text-align: center;
}
.hdr-top-right .credential-box {
    float: none !important;
}
.hdr-top-right {
    text-align: center;
}
.hdr-top-left{
	border-right: none;
}
/* end: header top responsive style */

/* start: logo style */
.logo {
	display: table;
	float: none;
	margin: 0 auto;
}
/* end: logo style */