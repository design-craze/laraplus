<h5>Hello {{ $data->fname }} {{$data->lname}}</h5>
<p>
Welcom to our Larapress CMS. Your account has been successfully. We need to verify your email address, in order to verfiy your account please click on the following link or paste the link on address bar of your browser and hit -   
</p>

<p>
	<a href="{{route('verify',['vfcode'=>$data->vfcode])}}">{{route('verify',['vfcode'=>$data->vfcode])}}</a>
</p>

<p>
    Thanks a lot for being with us. <br />
    Design Craze
</p>