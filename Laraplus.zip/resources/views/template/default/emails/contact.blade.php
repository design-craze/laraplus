<h5>Hello {{ $data->contact_company }}</h5>
<p>
	This is a new contact from the following User -
</p>

<ul style="list-style: none;">
	<li>Name: {{ $data->username }}</li>
	<li>Email: {{ $data->useremail }}</li>
	<li>Subject: {{ $data->subject }}</li>
</ul>

<p>
    <strong>Message:</strong> <br />
    {!! $data->msg !!}
</p>