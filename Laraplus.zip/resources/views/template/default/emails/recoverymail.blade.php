<h5>Hello {{ $data->fname }} {{$data->lname}}</h5>
<p>
Please click on the following link to recovery your password.
</p>

<p>
	<a href="{{route('recovery',['vfcode'=>$data->vfcode])}}">{{route('recovery',['vfcode'=>$data->vfcode])}}</a>
</p>

<p>
    Thanks a lot for being with us. <br />
    Design Craze
</p>