@section('headcode')
	{{ Html::style('assets/template/default/css/sunflower.css') }}
	<style>
		body{
			background:#20222B;
			}
			#main{
			margin:0;
			padding:0;
			background:#20222B;
			}
			#page-content{
				display: none;
			}
	</style>
@endsection
@include('template.'.$settinghelper['template'].'.includes.header')
@section('templatesection')
	<section id="parent" class="animsition">
        <div id="rightSide" class="visible img-only">
	        <div class="scene">
				<div class="wing-left"></div>
				<div class="wing-right"></div>
				<div class="exhaust"></div>
				<div class="capsule">
	            	<div class="top">
	              		<div class="shadow"></div>
	            	</div>
	            	<div class="base"></div>
	          	</div>
	          	<div class="window-big"></div>
				<div class="window-small"></div>
				<div class="fire-1"></div>
				<div class="fire-2"></div>
				<div class="fire-3"></div>
				<div class="fire-4"></div>
				<div class="spark-1"></div>
				<div class="spark-2"></div>
				<div class="spark-3"></div>
				<div class="spark-4"></div>
				<div class="star star--1"></div>
				<div class="star star--2"></div>
				<div class="star star--3"></div>
				<div class="star star--4"></div>
				<div class="star star--5"></div>
				<div class="star star--6"></div>
				<div class="star star--7"></div>
				<div class="star star--8"></div>
				<div class="star star--9"></div>
				<div class="star star--10"></div>
				<div class="star star--11"></div>
				<div class="star star--12"></div>
				<div class="star star--13"></div>
				<div class="star star--14"></div>
				<div class="star star--15"></div>
				<div class="star star--16"></div>
	        </div>
        </div>
	</section>
	<div class="row">
		<div class="col-md-12">
			<h2 style="color:#fff; font-size:24px;font-weight: bold; text-align: center;margin-top: -90px;">STAY TUNED!<br>WE ARE LAUNCHING SOON</h2>
			<p style="color:#fff; text-align: center;">Meanwhile you can contact us anytime.</p>
			<img src="{{asset('assets/template/default/logo.png')}}" alt=""; style="display: table;margin: 15px auto; max-width: 200px;">
		</div>
	</div>
	<div class="row">
		<div class="col-sm-4 col-md-offset-4">
	{{ Form::open(array('route'=>'contactusprocess', 'method'=>'post')) }}

				<label for="name" style="color:#fff">Name</label>
				<input type="text" name="name" id="name" placeholder="Name">

				<label for="email" style="color:#fff">Email</label>
				<input type="email" name="email" id="email" placeholder="Email">

				<label for="subject" style="color:#fff">Subject</label>
				<input type="text" name="subject" id="subject" placeholder="Subject">

				<label for="message" style="color:#fff">Message</label>
				<textarea name="message" id="message" cols="30" rows="5" style="width: 100%"></textarea>
				<div style="margin: 15px 0;">
				{!! app('captcha')->display(); !!}
				</div>
				<button type="submit" name="contact_us" class="btn btn-primary btn-lg">Submit</button>
			</div>
	{{ Form::close() }}
		</div>
	</div>
@show
@include('template.'.$settinghelper['template'].'.includes.footer')