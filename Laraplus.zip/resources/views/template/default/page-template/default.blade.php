@include('template.'.$settinghelper['template'].'.includes.header')
<!-- start extra coding here but without container - Only Row and column if needed. but it's already in row. so better to just use div for design-->
@include('template.'.$settinghelper['template'].'.includes.footer')
