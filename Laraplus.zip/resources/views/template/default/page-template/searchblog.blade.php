@include('template.'.$settinghelper['template'].'.includes.header')
@section('templatesection')
	@if($dataerror==0)
	@if(Auth::user() && $logged_role > 6)
	<div class="row">
        <div class="col-md-12">
        	<ul class="list-unstyled list-inline">
        		<li><a href="{{ route('blogs') }}" class="btn btn-lg btn-primary">View All Posts</a></li>
        		<li><a href="{{ route('createblog') }}" class="btn btn-lg btn-primary">Create Post</a></li>
        		<li><a href="{{ route('myblogs') }}" class="btn btn-lg btn-primary">My Posts</a></li>
        	</ul>
        </div>
    </div>
	@endif

   	<div class="row">
        <div class="col-md-12">
        	@if(isset($myposts) && !empty($myposts))
        	@foreach($myposts as $mypost)
			@if((isset($mypost) && !empty($mypost) && $mypost->access_level == 0) || 
        		(Auth::user() && $mypost->access_level == Auth::user()->role) || (isset($mypost) && !empty($mypost) && Auth::user() && $mypost->user_id == Auth::user()->id) || (isset($mypost) && !empty($mypost) && Auth::user() && Auth::user()->role == 12))
            <div class="row" style="margin-top: 40px;">
            	@if(isset($mypost->thumb) && !empty($mypost->thumb))
                <div class="col-md-3">
                	<img src="{{$mypost->thumb}}" alt="{{$mypost->thumb}}" class="img-responsive">
                </div>
                @endif
                <div class="col-md-{{(isset($mypost->thumb) && !empty($mypost->thumb)) ? 9 : 12}}">
					<h2 style="margin-top:0;">
						@if(isset($mypost->name) && !empty($mypost->name))
							<a href="{{ route('blog',['slug'=>$mypost->slug]) }}">{{$mypost->name}}</a>
						@endif
					</h2>
					<p class="small">
						 Post by : <a href="{{ route('profile',['logcode'=>$mypost->user->logcode]) }}">{{$mypost->user->fname}} {{$mypost->user->lname}}</a> | Posted At : {{ getDateFormat($mypost->created_at)}} | comments : 0
					</p>
					<div>
						@if(isset($mypost->description) && !empty($mypost->description))
							{!!substr(strip_tags($mypost->description), 0, 200)!!}
						@endif

					</div>
					<div class="small">
						<a href="{{ route('blog',['slug'=>$mypost->slug]) }}">
							Read More
						</a>
						@if((Auth::user() && Auth::user()->id == $mypost->user_id && Auth::user()->role > 6) || (Auth::user() && Auth::user()->role > 7 && Auth::user()->role > $mypost->user->role))
						|
						<a href="{{ route('editpost',['id'=>$mypost->id]) }}">
							Edit Post
						</a>
						@endif
					</div>
					<hr>
					<div class="small">
						<span class="pull-left">
						@if(count($mypost->categories) > 0)
						Posted In:
						@foreach($mypost->categories as $cat)
	                		<a href="{{route('blogcategory', ['slug'=>$cat->ctgslug])}}">{{$cat->name}}</a> |
						@endforeach
						@endif
						</span>
						
						@if($mypost->metatag != null)
						<span class="pull-right">
							Tags:
							<?php $meta = explode(',', $mypost->metatag); ?>
							@foreach($meta as $tag)
	                		<a href="{{taglink($tag)}}">{{$tag}}</a> |
							@endforeach
						</span>
						@endif
					</div>              
                </div>
            </div>
			@endif
            @endforeach
            <div class="common-pagination">
				<?php 
					$pagifpname = 'First'; $pagippname = 'prev'; $pagilpname = 'Last'; $paginpname = 'Next';
					if($myposts->currentPage() == '1'){
						$pagifp = '<span>'.$pagifpname.'</span>'; $pagipp = '<span>'.$pagippname.'</span>';
					}
					else{
						$pagifp = '<a href="'.route('blogmanager').'?';
						foreach($getelements as $key => $val){
			            	$pagifp .= $key.'='.$val.'&';
				        }
						$pagifp .= 'page=1'.'">'.$pagifpname.'</a>'; $pagipp = '<a href="'.$myposts->previousPageUrl().'">'.$pagippname.'</a>';
					}
					if($myposts->lastPage() == $myposts->currentPage()){
						$pagilp = '<span>'.$pagilpname.'</span>'; $paginp = '<span>'.$paginpname.'</span>';
					}
					else{
						$pagilp = '<a href="'.route('blogmanager').'?';
						foreach($getelements as $key => $val){
			            	$pagilp .= $key.'='.$val.'&';
				        }
						$pagilp .= 'page='.$myposts->lastPage().'">'.$pagilpname.'</a>'; $paginp = '<a href="'.$myposts->nextPageUrl().'">'.$paginpname.'</a>';
					}
				?>
				@if($myposts->total()>$myposts->count())
					<ul class="prevsec">
						<li>{!!$pagifp!!}</li>
						<li>{!!$pagipp!!}</li>
					</ul>
					{{$myposts->links()}}
					<ul class="nextsec">
						<li>{!!$paginp!!}</li>
						<li>{!!$pagilp!!}</li>
					</ul>
					<div style="clear:both"></div>
				@endif
			</div>
            @endif
		</div>
    </div>    
    @else
	<div class="col-md-12">
		<div class="panel panel-default custom-panel">
            <div class="panel-body">
				<h4 class="text-center">
					No blog found to view.
				</h4>
			</div>
		</div>
	</div>
	@endif

@show
@include('template.'.$settinghelper['template'].'.includes.footer')