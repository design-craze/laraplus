@include('template.'.$settinghelper['template'].'.includes.header')
@section('templatesection')
	@if($dataerror==0)
		@if(isset($urlslug) && $urlslug !='')
        	@if(isset($myposts) && !empty($myposts))
<?php
    $pageleft = 0;
    $pageright = 0;
    if(isset($data->leftside) && !isset($data->user_id) && $data->leftside != 'default' && $data->leftside != 'none'){
        $pageleft = 1;
    }
    else if(isset($data->leftside) && !isset($data->user_id) && $data->leftside == 'default' && $settinghelper['page_leftsidebar']!='' && $settinghelper['page_leftsidebar']!='none'){
        $pageleft = 1;
    }
    else if(!isset($data->leftside) && isset($data->user_id) && $settinghelper['blog_leftsidebar']!='' && $settinghelper['blog_leftsidebar']!='none'){
        $pageleft = 1;
    }
    else if(!isset($data->leftside) && !isset($data->user_id) && $settinghelper['page_leftsidebar']!='' && $settinghelper['page_leftsidebar']!='none'){
        $pageleft = 1;
    }
    
    if(isset($data->rightside) && !isset($data->user_id) && $data->rightside != 'default' && $data->rightside != 'none'){
        $pageright = 1;
    }
    else if(isset($data->rightside) && !isset($data->user_id) && $data->rightside == 'default' && $settinghelper['page_rightsidebar']!='' && $settinghelper['page_rightsidebar']!='none'){
        $pageright = 1;
    }
    else if(!isset($data->rightside) && isset($data->user_id) && $settinghelper['blog_rightsidebar']!='' && $settinghelper['blog_rightsidebar']!='none'){
        $pageright = 1;
    }
    else if(!isset($data->rightside) && !isset($data->user_id) && $settinghelper['page_rightsidebar']!='' && $settinghelper['page_rightsidebar']!='none'){
        $pageright = 1;
    }
    $sidebar = $pageleft + $pageright;
    if($sidebar==1){$class= 'col-md-4';}
    elseif($sidebar==2){$class= 'col-md-6';}
    else{$class= 'col-md-3 col-sm-6';}
?>
				<div class="row dc-clear">
	        	@foreach($myposts as $mypost)
					@if((isset($mypost) && !empty($mypost) && $mypost->access_level == 0) || 
		        		(Auth::user() && $mypost->access_level == Auth::user()->role) || (isset($mypost) && !empty($mypost) && Auth::user() && $mypost->user_id == Auth::user()->id) || (isset($mypost) && !empty($mypost) && Auth::user() && Auth::user()->role == 12))
		                <div class="{{$class}} blog-thumb-big-section">
		                	<div class="blog-thumb-big-image">
				            		@if(isset($mypost->thumb) && !empty($mypost->thumb))
				                		<img src="{{$mypost->thumb}}" alt="{{$mypost->thumb}}" class="img-responsive">
				                	@else
				                		<img src="{{asset('assets/common/images/no-thumb-big.jpg')}}" alt="" class="img-responsive">
				                	@endif
							</div>
							<h4 class="blog-thumb-big-title">
								@if(isset($mypost->name) && !empty($mypost->name))
									<a href="{{ route('blog',['slug'=>$mypost->slug]) }}">{{$mypost->name}}</a>
								@endif
							</h4>
							<div class="blog-thumb-big-info small">
								<div class="blog-thumb-big-author pull-left">
				                	<i class="fa fa-user"></i> <a href="{{ route('profile',['logcode'=>$mypost->user->logcode]) }}"> {{$mypost->user->fname}} {{$mypost->user->lname}}</a>
								</div>
								<div style="clear: both;"></div>
								<div>
									<div>
									@if(count($mypost->categories) > 0)
									<i class="fa fa-folder-open"></i> 
									<?php $a=''; ?>
									@foreach($mypost->categories as $cat)
				                		{{$a}}<a href="{{route('blogcategory', ['slug'=>$cat->ctgslug])}}">{{$cat->name}}</a>
				                		<?php $a='|'; ?>
									@endforeach
									@endif
									</div>
									
									@if($mypost->metatag != null)
									<div>
										<i class="fa fa-tags"></i> 
										<?php $meta = explode(',', $mypost->metatag); $a=''?>
										@foreach($meta as $tag)
				                		{{$a}}<a href="{{taglink($tag)}}">{{$tag}}</a>
				                		<?php $a='|'; ?>
										@endforeach
									</div>
									@endif
								</div>							
							</div>
							<div class="blog-thumb-big-desc">
								@if(isset($mypost->description) && !empty($mypost->description))
									{!!substr(strip_tags($mypost->description), 0, 200)!!}
								@endif
							</div>							
							<div class="small blog-thumb-big-info">
								<a href="{{ route('blog',['slug'=>$mypost->slug]) }}">
									Read More
								</a>
								@if((Auth::user() && Auth::user()->id == $mypost->user_id && Auth::user()->role > 6) || (Auth::user() && Auth::user()->role > 7 && Auth::user()->role > $mypost->user->role))
								|
								<a href="{{ route('editpost',['id'=>$mypost->id]) }}">
									Edit Post
								</a>
								@endif
								|
								<span class="blog-thumb-big-comment">
									<i class="fa fa-comment"></i> {{count($mypost->comments)}}
								</span>
							</div>
		                </div>
					@endif
	            @endforeach
		    	</div>
		    	<div class="row"> 
		    		<div class="col-md-12">
			            <?php
			            	$pagination = array(
			            		'route'=>'blogcategory',
			            		'routeslug'=>['slug'=>$urlslug],
			            		'first'=>'<i class="fa fa-angle-double-left"></i>',
			            		'last'=> '<i class="fa fa-angle-double-right"></i>',
			            		'prev'=>'<i class="fa fa-angle-left"></i>',
			            		'next'=>'<i class="fa fa-angle-right"></i>'
			            	);
			            	pagination($myposts, $getelements, $pagination);
			            ?>
					</div>
				</div>
            @endif   
		@else
		<div class="row">
	        <div class="col-md-12">
	        	@if(isset($categories) && !empty($categories))
				<table class="post-categories">
					<thead>
						<tr>
							<th>Category Name</th>
							<th>Description</th>
							<th>Posts</th>
							<th>Created Date</th>
						</tr>
					</thead>
					<tbody>
	        		@foreach($categories as $category)
						<tr>
							<td><a href="{{route('blogcategory', ['slug'=>$category->ctgslug])}}">{{ $category->name }}</a></td> 
							<td>{!! $category->description !!}</td>
							<td>
								{{ count($category->blogs) }}
							</td>
							<td>{{ getDateFormat($category->created_at) }}</td>
						</tr>
	            	@endforeach
					</tbody>
					<tfoot>
						<tr>
							<th>Category Name</th>
							<th>Description</th>
							<th>Posts</th>
							<th>Created Date</th>
						</tr>
					</tfoot>
				</table>
					
				
	            <div class="common-pagination">
					<?php 
						$pagifpname = 'First'; $pagippname = 'prev'; $pagilpname = 'Last'; $paginpname = 'Next';
						if($categories->currentPage() == '1'){
							$pagifp = '<span>'.$pagifpname.'</span>'; $pagipp = '<span>'.$pagippname.'</span>';
						}
						else{
							$pagifp = '<a href="'.route('blogmanager').'?';
							foreach($getelements as $key => $val){
				            	$pagifp .= $key.'='.$val.'&';
					        }
							$pagifp .= 'page=1'.'">'.$pagifpname.'</a>'; $pagipp = '<a href="'.$categories->previousPageUrl().'">'.$pagippname.'</a>';
						}
						if($categories->lastPage() == $categories->currentPage()){
							$pagilp = '<span>'.$pagilpname.'</span>'; $paginp = '<span>'.$paginpname.'</span>';
						}
						else{
							$pagilp = '<a href="'.route('blogmanager').'?';
							foreach($getelements as $key => $val){
				            	$pagilp .= $key.'='.$val.'&';
					        }
							$pagilp .= 'page='.$categories->lastPage().'">'.$pagilpname.'</a>'; $paginp = '<a href="'.$categories->nextPageUrl().'">'.$paginpname.'</a>';
						}
					?>
					@if($categories->total()>$categories->count())
						<ul class="prevsec">
							<li>{!!$pagifp!!}</li>
							<li>{!!$pagipp!!}</li>
						</ul>
						{{$categories->links()}}
						<ul class="nextsec">
							<li>{!!$paginp!!}</li>
							<li>{!!$pagilp!!}</li>
						</ul>
						<div style="clear:both"></div>
					@endif
				</div>
	            @endif
			</div>
	    </div> 
		@endif   
    @else
	<div class="col-md-12">
		<div class="panel panel-default custom-panel">
            <div class="panel-body">
				<h4 class="text-center">
					No Category found to view.
				</h4>
			</div>
		</div>
	</div>
	@endif

@show
@include('template.'.$settinghelper['template'].'.includes.footer')