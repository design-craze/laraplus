@include('template.'.$settinghelper['template'].'.includes.header')
@section('templatesection')
	<div class="row">
		<div class="col-sm-6">
			<img src="{{asset('assets/template/default/images/cube.png')}}" alt="" class="img-responsive">
		</div>
		<div class="col-sm-6">
			<h2 style="font-weight: 400;text-align:center; font-size:36px; padding-bottom: 30px;border-bottom:1px solid #cfcfcf;margin-bottom:30px">SORRY! <span style="font-weight: 700">LINK BROKEN</span></h2>
			<div style="display: table;margin: 0 auto;">
				<div style="display: table-cell; vertical-align: middle;font-size: 80px;padding-right:10px;font-weight:700;">
					404
				</div>
				<div style="display: table-cell; vertical-align: middle;padding-left: 10px;margin-bottom: 60px;">
					<p style="font-size: 36px;margin:0;line-height: 1; color:#555; font-weight: 700;">ERROR</p>
					<p style="font-size: 18px;margin:0;">Page Not Found</p>
				</div>
			</div>
			<div style="text-align: center;margin-top: 20px;"><p style=" font-size:14px;">The Page You Are Looking For Might Be Changed, Removed Or Doesn't Exists. Go Back And Try Other Links</p><p><a href="{{route('home')}}" class="btn btn-primary btn-lg">HOME</a></p></div>
			
		</div>
	</div>
@show
@include('template.'.$settinghelper['template'].'.includes.footer')