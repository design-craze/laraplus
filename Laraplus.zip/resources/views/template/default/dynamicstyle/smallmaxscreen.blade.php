.header-top::after {
    width: 0 !important;
}
.header-top::before {
    width: 100%;
}
.top-left {
    display: table;
    float: none;
    margin: 0 auto;
}
.top-right {
    display: table;
    float: none;
    margin: 10px auto 0;
}