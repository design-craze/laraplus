.logo {
    display: table;
    float: none;
    margin: 0 auto;
}
.clearfix.main-head-right {
    display: table;
    float: none;
    margin: 0 auto;
}