@include('template.'.$settinghelper['template'].'.includes.header')
@section('templatesection')
	
@show
@include('template.'.$settinghelper['template'].'.includes.footer')