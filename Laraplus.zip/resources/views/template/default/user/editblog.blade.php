@section('headcode')
    {{ Html::style('assets/common/js/tags/tagmanager.css') }}
@endsection
@include('template.'.$settinghelper['template'].'.includes.header')
@section('templatesection')
 @if($logged_role > 6)
	@if($dataerror==0)
			@if(Auth::user()->active == 3 && Auth::user()->role != 12)
			<div class="row">
		        <div class="col-md-12">
					<div class="panel panel-default custom-panel">
			            <div class="panel-body">
							<h4 class="text-center">
								You can not edit blog at inactive mode. To make your profile active please contact to our help center. 
							</h4>
						</div>
					</div>
				</div>
			</div>
	        @else
	        	@if((isset($singleblog) && !empty($singleblog) && $singleblog->access_level == 0) || 
        		(Auth::user() && $singleblog->access_level == Auth::user()->role) || (isset($singleblog) && !empty($singleblog) && Auth::user() && $singleblog->user_id == Auth::user()->id) || (isset($singleblog) && !empty($singleblog) && Auth::user() && Auth::user()->role == 12))

		         <div class="row">   
		            <div class="col-md-12 profile-aside">
		            	<ul class="list-unstyled list-inline">
			        		<li><a href="{{ route('blogs') }}">View All Posts</a></li>
			        		@if(Auth::user() && $logged_role > 6)
			        		<li><a href="{{ route('createblog') }}">Create Post</a></li>
			        		<li><a href="{{ route('myblogs') }}">My Posts</a></li>
			        		@endif
			        	</ul>
			        </div>
		        </div>
	        	{{ Form::open(array('route'=>['editblogprocess','id'=>$singleblog->id], 'method'=>'post')) }}
		        <div class="row">
	            	<div class="col-md-8">
	                    <div class="form-group">
							<label for="title">Title</label>
							<input type="text" name="name" placeholder="Enter Title Here" value="<?php if(old('name')!=''){echo old('name');} elseif(!empty($singleblog->name)){echo $singleblog->name;} ?>">
						</div>
						<div class="form-group">
							<label for="description">Description</label>
							<textarea id="maintext" name="description" class="form-control" rows="8" placeholder="Free Content goes here..."><?php if(old('description')!=''){echo old('description');} elseif(!empty($singleblog->description)){echo $singleblog->description;} ?></textarea>
						</div>						
						<button type="submit" class="btn btn-primary btn-lg">Update</button>
	                </div>
	                <div class="col-md-4">
	                	<div class="form-group">
							<label for="title">Select Category</label>
							<select class="select" name="category[]">
							@if($categories != null)
							@foreach($categories as $cat)
								<?php $singlecat=''; ?>
								@if(old('category')!=null)
									@foreach(old('category') as $scat)
									@if($cat->id==$scat)
	                                    <?php  $singlecat= ' selected'; ?>
	                                @endif
									@endforeach
								@elseif($dbcategory!=null)
									@foreach($dbcategory as $scat)
									@if($cat->id==$scat->id)
	                                    <?php  $singlecat= ' selected'; ?>
	                                @endif
									@endforeach
								@endif
								
									<option value="{{ $cat->id }}"{{$singlecat}}>{{ $cat->name }}</option>
								
	                        @endforeach
	                        @endif
	                        </select>
						</div>
						<div class="form-group">
							<label for="title">Allow Comment</label>
							<select class="select" name="commentable">
	                            <option value="1"<?php if(old('commentable')=='1'){echo ' selected';} elseif($singleblog->commentable=='1'){echo ' selected';}?>>Yes</option>
	                            <option value="0" <?php if(old('commentable')=='0'){echo ' selected';} elseif($singleblog->commentable=='0'){echo ' selected';}?>>No</option>
		                    </select>
						</div>
						<div class="form-group">
							<label for="title">Thumbnail</label>
							<input type="text" name="thumb" placeholder="image link for thumbnail" value="<?php if(old('thumb')!=''){echo old('thumb');} elseif(!empty($singleblog->thumb)){echo $singleblog->thumb;} ?>">
						</div>
						<div class="form-group">
							<label for="title">Tags</label>
							<input type="text" placeholder="Add a new tag.." class="tm-input" id="tagmanager">
							<div class="tag-container"></div>
						</div>
	                </div>
	            </div>
                {{ Form::close() }}
                @else
                <div class="panel panel-default custom-panel">
	            	<div class="panel-body">
						<h4 class="text-center">
							This post is only for certain users. You are not eligable to edit this post.
						</h4>
					</div>
				</div>
                @endif
			@endif
    @else
	<div class="col-md-12">
		<div class="panel panel-default custom-panel">
            <div class="panel-body">
				<h4 class="text-center">
					No post found to edit.
				</h4>
			</div>
		</div>
	</div>
	@endif

 @else
 <div class="col-md-12">
	<div class="panel panel-default custom-panel">
        <div class="panel-body">
			<h4 class="text-center">
				You are not eligable to view this page.
			</h4>
		</div>
	</div>
 </div>
 @endif
@show

@section('jscode')
{{ Html::script('assets/common/js/tinymce/tinymce.min.js') }}
{{ Html::script('assets/common/js/tags/tagmanager.js') }}
{{ Html::script('assets/admin/js/usertinymceintegration.js') }}

<script>
	$(".tm-input").tagsManager({
        tagsContainer: '.tag-container',
            prefilled: [
                    <?php
                        if(old('metatag')!=null)
                        {
                            $meta= explode(',', old('metatag'));
                            foreach($meta as $tag){
                                echo '"'.$tag.'",';
                            }
                        }elseif(isset($singleblog->metatag) && $singleblog->metatag!=null)
                        {
                            $meta= explode(',', $singleblog->metatag);
                            foreach($meta as $tag){
                                echo '"'.$tag.'",';
                            }
                        }
                    ?>
                ],
            tagClass: 'tm-tag-info',
            hiddenTagListName: 'metatag',
            hiddenTagListId: null
    });
</script>
@endsection
@include('template.'.$settinghelper['template'].'.includes.footer')