@include('template.'.$settinghelper['template'].'.includes.header')
@section('templatesection')
	<div class="row">
		<div class="alert alert-danger text-center" role="alert">
			<h3><i class="icon fa fa-ban"></i> Account Suspended!</h3>
		</div>
		<div class="col-md-12">
			<div class="access-form">
				<div class="access-form-top">
					<div class="access-form-top-left bg-default">
						<h2>ACCOUNT SUSPENDED</h2>
						<p>Your account is suspended. Please use the following form to contact us if you need any help.</p>
					</div>
				</div>
				<div class="access-form-bottom">
				{{ Form::open(array('route'=>'suspendedmessageprocess', 'method'=>'post')) }}
				<div class="form-group">
				    <label for="exampleInputEmail1">Your Message</label>
				    <textarea name="usermessage" id="" cols="30" rows="10" class="form-control"></textarea>
				</div>
				<button type="submit" class="btn btn-primary btn-lg">Contact</button>
				{{ Form::close() }}
				</div>
			</div>
		</div>
	</div>
@show
@include('template.'.$settinghelper['template'].'.includes.footer')