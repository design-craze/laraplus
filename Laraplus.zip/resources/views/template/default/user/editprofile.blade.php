@include('template.'.$settinghelper['template'].'.includes.header')
@section('templatesection')
	@if($dataerror==0)
		@if($logged_role > $user->role || $logged_id == $user->id)
		<div class="row">
			@if(Auth::user()->active == 3 && Auth::user()->role != 12)
	        <div class="col-md-12">
				<div class="panel panel-default custom-panel">
		            <div class="panel-body">
						<h4 class="text-center">
							You can not edit your profile at inactive mode. To make your profile active please contact to our help center. 
						</h4>
					</div>
				</div>
			</div>
	        @else
            <div class="col-md-12 profile-aside">
	            <div class="row">
	            	<div class="col-md-4">
	                    <div class="panel panel-default custom-panel">
	                        <div class="panel-heading">Verification</div>
	                        <div class="panel-body">
	                        	<ul class="list-group">
	                        		<li class="list-group-item">
	                        			Email Address :
	                        			@if($user->verified==1)
					                    	<span class="label label-danger">{{isemailverified($user->verified)}}</span>
					                    @elseif($user->verified==2)
					                    	<span class="label label-success">{{isemailverified($user->verified)}}</span>
					                    @endif
	                        		</li>
	                        		<li class="list-group-item">
	                        			Account Status: 
	                        			@if($user->active==1)
					                    	<span class="label label-danger">{{activelevel($user->active)}}</span>	
					                    @elseif($user->active==2)
					                    	<span class="label label-warning">{{activelevel($user->active)}}</span>	
					                    @elseif($user->active==3)
					                    	<span class="label label-info">{{activelevel($user->active)}}</span>
					                    @elseif($user->active==4)
					                    	<span class="label label-success">{{activelevel($user->active)}}</span>
					                    @endif
	                        		</li>
	                        	</ul>
	                        </div>
	                    </div>
	                </div>

	                <div class="col-md-4">
	                    <div class="inner text-center">
			        	@if(isset($userinfo) && !empty($userinfo->avatar) && !is_int($userinfo->avatar))
						<img src="{{ asset(path_profile().$userinfo->avatar) }}" alt="{{$userinfo->avatar}}" class="img-responsive img-rounded">
						@elseif($userinfo->sex == 'f')
						<img src="{{ asset(path_profile().'female.jpg') }}" alt="female.jpg" class="img-responsive img-rounded">
						@else
						<img src="{{ asset(path_profile().'male.jpg') }}" alt="male.jpg" class="img-responsive img-rounded">
						@endif
						</div>
			            <!-- Button trigger modal -->
			            @if(isset($user) && $user->id == Auth::user()->id)
			            <div class="small-box-footer">
			            	<ul class="list-unstyled list-inline">
			            		<li>
			            			<a href="#" class="text-info" data-toggle="modal" data-target="#myModal">Change Avatar <i class="fa fa-edit"></i></a>
			            		</li>
			            		@if(!empty($userinfo->avatar) && $user->id == Auth::user()->id)
			            		<li>
			            			<a href="{{ route('removprofileimage',['imgval'=>$userinfo->avatar]) }}" class="text-danger confirmation" data-alert="Do You Want To Remove This Avatar?" data-toggle="tooltip" title="Remove This Avatar">remove</a>
			            		</li>
			            		@endif
			            	</ul>
			            </div>
						@endif
	                </div>
	                
	            </div>
	        </div>
	        
	        <div class="col-md-12">
	            <div class="row">
	                <div class="col-md-12">
	                    @if($logged_id == $user->id)
	                    <p><a href="{{ route('dashboard') }}" class="text-info small"> <i class="fa fa-pencil"></i> View Profile</a></p>
	                    @endif
	                </div>
	            </div>
	            <div class="row">
	                <div class="col-md-12">
	                	{{ Form::open(array('route'=>'editprofileprocess','method'=>'post')) }}
	                    <div class="panel panel-default custom-panel">
	                        <div class="panel-heading">Details</div>
	                        <div class="panel-body">
	                            <table class="table table-striped">
									<tr>
										<td>First Name</td>
										<td>
											<input type="text" name="fname" placeholder="Enter First Name" value="<?php if(old('fname')!=''){echo old('fname');} else{ echo $user->fname;} ?>">
										</td>
									</tr>
									<tr>
										<td>Last Name</td>
										<td>
											<input type="text" name="lname" placeholder="Enter Last Name" value="<?php if(old('lname')!=''){echo old('lname');} else{ echo $user->lname;} ?>">
										</td>
									</tr>
									 @if($logged_id == $user->id)
									<tr>
										<td>Username</td>
										<td>: {{$user->username}}</td>
									</tr>
									@endif
									<tr>
										<td>Email</td>
										<td>: <a href="mailto:{{$user->email}}">{{$user->email}}</a></td>
									</tr>
									<tr>
										<td>Role</td>
										<td>: {{roleaccess($user->role)}}</td>
									</tr>
									<tr>
										<td class="col-xs-5 col-sm-6">Addres Line 1</td>
										<td>
											<input type="text" name="street1" placeholder="Enter Address Line 1" value="<?php if(old('street1')!=''){echo old('street1');} elseif(old('street1')=='' && isset($userinfo)){ echo $userinfo->street1;} ?>">
										</td>
									</tr>
									<tr>
										<td>Addres Line 2</td>
										<td>
											<input type="text" name="street2" placeholder="Enter Address Line 2" value="<?php if(old('street2')!=''){echo old('street2');} elseif(old('street2')=='' && isset($userinfo)){ echo $userinfo->street2;} ?>">
										</td>
									</tr>
									<tr>
										<td>City</td>
										<td>
											<input type="text" name="city" placeholder="Enter City" value="<?php if(old('city')!=''){echo old('city');} elseif(old('city')=='' && isset($userinfo)){ echo $userinfo->city;} ?>">
										</td>
									</tr>
									<tr>
										<td>State</td>
										<td>
											<input type="text" name="state" placeholder="Enter State" value="<?php if(old('state')!=''){echo old('state');} elseif(old('state')=='' && isset($userinfo)){ echo $userinfo->state;} ?>">
										</td>
									</tr>
									<tr>
										<td>Zip</td>
										<td>
											<input type="text" name="zip" placeholder="Enter Zip" value="<?php if(old('zip')!=''){echo old('zip');} elseif(old('zip')=='' && isset($userinfo)){ echo $userinfo->zip;} ?>">
										</td>
									</tr>
									<tr>
										<td>Country</td>
										<td>
											<select class="select" name="country">
	                                            <?php
	                                                $a = country(null,'en');
	                                            ?>
	                                            @foreach($a as $key => $val)
	                                                <option value="{{$key}}" <?php if(old('country')!= '' && old('country')==$key){
	                                                	echo ' selected';
	                                                	}elseif(old('country')== '' && isset($userinfo) && $userinfo->country == $key){ echo ' selected';}?>>{{$val}}</option>
	                                            @endforeach
	                                        </select>
										</td>
									</tr>
									<tr>
										<td>Sex</td>
										<td>
											<select class="select" name="sex">
	                                            <?php
	                                                $a = gender(null,'en');
	                                            ?>
	                                            @foreach($a as $key => $val)
	                                                <option value="{{$key}}" <?php if(old('sex')!= '' && old('sex')==$key){
	                                                	echo ' selected';
	                                                	}elseif(old('sex')== '' && isset($userinfo) && $userinfo->sex == $key){ echo ' selected';}?>>{{$val}}</option>
	                                            @endforeach
	                                        </select>
										</td>
									</tr>
									<tr>
										<td>Contact No.</td>
										<td>
											<input type="tel" name="contact" placeholder="Enter Contact No" value="<?php if(old('contact')!=''){echo old('contact');} elseif(old('contact')=='' && isset($userinfo)){ echo $userinfo->contact;} ?>">
										</td>
									</tr>
									<tr>
										<td>Description</td>
										<td>
											<textarea name="description" rows="3" class="form-control" placeholder="Enter Description"><?php if(old('description')!=''){echo old('description');} elseif(old('description')=='' && isset($userinfo)){ echo $userinfo->description;} ?></textarea>
										</td>
									</tr>
									<tr>
										<td>Date Of Birth</td>
										<td>
											<input type="tel" name="dob" placeholder="Enter Date of Birth" value="<?php if(old('dob')!=''){echo old('dob');} elseif(old('dob')=='' && isset($userinfo)){ echo $userinfo->dob;} ?>">
										</td>
									</tr>
								</table>
		            		</div>
		            		<div class="panel-footer"><button type="submit" class="btn btn-primary btn-lg" name="update_profile">Update Profile</button></div>
	                    </div>
						{{ Form::close() }}
	                </div>
	            </div>
	        </div>
			@endif
	    </div>
	    @else
		<div class="col-md-12">
			<div class="panel panel-default custom-panel">
	            <div class="panel-body">
					<h4 class="text-center">
						You are not eligable to edit this profile.
					</h4>
				</div>
			</div>
		</div>
		@endif    
    @else
	<div class="col-md-12">
		<div class="panel panel-default custom-panel">
            <div class="panel-body">
				<h4 class="text-center">
					No user found to edit.
				</h4>
			</div>
		</div>
	</div>
	@endif
	<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
    {{ Form::open(array('route'=>'uloadprofileimage', 'method'=>'post', 'files' => true)) }}
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Change Photo</h4>
      </div>
      <div class="modal-body">
        <div class="form-group">
		    <label for="profileimg">Upload Profile Image</label>
		    <input type="file" name="profileimg" id="profileimg">
		    <p class="help-block">Current profile image will be deleted automatically.</p>
		 </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" name="imageupload" value="Upload">
      </div>
      {{ Form::close() }}
    </div>
  </div>
</div>
@show
@include('template.'.$settinghelper['template'].'.includes.footer')