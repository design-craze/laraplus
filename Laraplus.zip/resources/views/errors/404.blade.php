<?php 
	$settinghelper =allsetting(); 
	$webtitle = 'Error 404';
    $breadcrumb = breadcrumb(
        array(
            [$webtitle,'home']
        ),
        $settinghelper['brdcrmb_sep']
    );
?>
@include('template.'.$settinghelper['template'].'.error404')